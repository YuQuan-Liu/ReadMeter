/*  1:   */ package org.apache.mina.example.chat;
/*  2:   */ 
/*  3:   */ public class ChatCommand
/*  4:   */ {
/*  5:   */   public static final int LOGIN = 0;
/*  6:   */   public static final int QUIT = 1;
/*  7:   */   public static final int BROADCAST = 2;
/*  8:   */   private final int num;
/*  9:   */   
/* 10:   */   private ChatCommand(int num)
/* 11:   */   {
/* 12:38 */     this.num = num;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public int toInt()
/* 16:   */   {
/* 17:42 */     return this.num;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public static ChatCommand valueOf(String s)
/* 21:   */   {
/* 22:46 */     s = s.toUpperCase();
/* 23:47 */     if ("LOGIN".equals(s)) {
/* 24:48 */       return new ChatCommand(0);
/* 25:   */     }
/* 26:50 */     if ("QUIT".equals(s)) {
/* 27:51 */       return new ChatCommand(1);
/* 28:   */     }
/* 29:53 */     if ("BROADCAST".equals(s)) {
/* 30:54 */       return new ChatCommand(2);
/* 31:   */     }
/* 32:57 */     throw new IllegalArgumentException("Unrecognized command: " + s);
/* 33:   */   }
/* 34:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.chat.ChatCommand
 * JD-Core Version:    0.7.0.1
 */