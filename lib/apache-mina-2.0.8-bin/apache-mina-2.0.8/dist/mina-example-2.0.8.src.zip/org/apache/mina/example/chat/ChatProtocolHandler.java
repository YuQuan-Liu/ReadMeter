/*   1:    */ package org.apache.mina.example.chat;
/*   2:    */ 
/*   3:    */ import java.util.Collections;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.apache.mina.core.service.IoHandlerAdapter;
/*   7:    */ import org.apache.mina.core.session.IoSession;
/*   8:    */ import org.apache.mina.filter.logging.MdcInjectionFilter;
/*   9:    */ import org.slf4j.Logger;
/*  10:    */ import org.slf4j.LoggerFactory;
/*  11:    */ 
/*  12:    */ public class ChatProtocolHandler
/*  13:    */   extends IoHandlerAdapter
/*  14:    */ {
/*  15: 39 */   private static final Logger LOGGER = LoggerFactory.getLogger(ChatProtocolHandler.class);
/*  16: 41 */   private final Set<IoSession> sessions = Collections.synchronizedSet(new HashSet());
/*  17: 44 */   private final Set<String> users = Collections.synchronizedSet(new HashSet());
/*  18:    */   
/*  19:    */   public void exceptionCaught(IoSession session, Throwable cause)
/*  20:    */   {
/*  21: 49 */     LOGGER.warn("Unexpected exception.", cause);
/*  22:    */     
/*  23: 51 */     session.close(true);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public void messageReceived(IoSession session, Object message)
/*  27:    */   {
/*  28: 56 */     Logger log = LoggerFactory.getLogger(ChatProtocolHandler.class);
/*  29: 57 */     log.info("received: " + message);
/*  30: 58 */     String theMessage = (String)message;
/*  31: 59 */     String[] result = theMessage.split(" ", 2);
/*  32: 60 */     String theCommand = result[0];
/*  33:    */     try
/*  34:    */     {
/*  35: 64 */       ChatCommand command = ChatCommand.valueOf(theCommand);
/*  36: 65 */       String user = (String)session.getAttribute("user");
/*  37: 67 */       switch (command.toInt())
/*  38:    */       {
/*  39:    */       case 1: 
/*  40: 70 */         session.write("QUIT OK");
/*  41: 71 */         session.close(true);
/*  42: 72 */         break;
/*  43:    */       case 0: 
/*  44: 75 */         if (user != null)
/*  45:    */         {
/*  46: 76 */           session.write("LOGIN ERROR user " + user + " already logged in.");
/*  47:    */           
/*  48: 78 */           return;
/*  49:    */         }
/*  50: 81 */         if (result.length == 2)
/*  51:    */         {
/*  52: 82 */           user = result[1];
/*  53:    */         }
/*  54:    */         else
/*  55:    */         {
/*  56: 84 */           session.write("LOGIN ERROR invalid login command.");
/*  57: 85 */           return;
/*  58:    */         }
/*  59: 89 */         if (this.users.contains(user))
/*  60:    */         {
/*  61: 90 */           session.write("LOGIN ERROR the name " + user + " is already used.");
/*  62:    */           
/*  63: 92 */           return;
/*  64:    */         }
/*  65: 95 */         this.sessions.add(session);
/*  66: 96 */         session.setAttribute("user", user);
/*  67: 97 */         MdcInjectionFilter.setProperty(session, "user", user);
/*  68:    */         
/*  69:    */ 
/*  70:100 */         this.users.add(user);
/*  71:101 */         session.write("LOGIN OK");
/*  72:102 */         broadcast("The user " + user + " has joined the chat session.");
/*  73:103 */         break;
/*  74:    */       case 2: 
/*  75:107 */         if (result.length == 2) {
/*  76:108 */           broadcast(user + ": " + result[1]);
/*  77:    */         }
/*  78:    */         break;
/*  79:    */       default: 
/*  80:112 */         LOGGER.info("Unhandled command: " + command);
/*  81:    */       }
/*  82:    */     }
/*  83:    */     catch (IllegalArgumentException e)
/*  84:    */     {
/*  85:117 */       LOGGER.debug("Illegal argument", e);
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void broadcast(String message)
/*  90:    */   {
/*  91:122 */     synchronized (this.sessions)
/*  92:    */     {
/*  93:123 */       for (IoSession session : this.sessions) {
/*  94:124 */         if (session.isConnected()) {
/*  95:125 */           session.write("BROADCAST OK " + message);
/*  96:    */         }
/*  97:    */       }
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   public void sessionClosed(IoSession session)
/* 102:    */     throws Exception
/* 103:    */   {
/* 104:133 */     String user = (String)session.getAttribute("user");
/* 105:134 */     this.users.remove(user);
/* 106:135 */     this.sessions.remove(session);
/* 107:136 */     broadcast("The user " + user + " has left the chat session.");
/* 108:    */   }
/* 109:    */   
/* 110:    */   public boolean isChatUser(String name)
/* 111:    */   {
/* 112:140 */     return this.users.contains(name);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public int getNumberOfUsers()
/* 116:    */   {
/* 117:144 */     return this.users.size();
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void kick(String name)
/* 121:    */   {
/* 122:148 */     synchronized (this.sessions)
/* 123:    */     {
/* 124:149 */       for (IoSession session : this.sessions) {
/* 125:150 */         if (name.equals(session.getAttribute("user")))
/* 126:    */         {
/* 127:151 */           session.close(true);
/* 128:152 */           break;
/* 129:    */         }
/* 130:    */       }
/* 131:    */     }
/* 132:    */   }
/* 133:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.chat.ChatProtocolHandler
 * JD-Core Version:    0.7.0.1
 */