/*  1:   */ package org.apache.mina.example.chat;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import java.net.InetSocketAddress;
/*  5:   */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*  6:   */ import org.apache.mina.example.echoserver.ssl.BogusSslContextFactory;
/*  7:   */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/*  8:   */ import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
/*  9:   */ import org.apache.mina.filter.logging.LoggingFilter;
/* 10:   */ import org.apache.mina.filter.logging.MdcInjectionFilter;
/* 11:   */ import org.apache.mina.filter.ssl.SslFilter;
/* 12:   */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
/* 13:   */ 
/* 14:   */ public class Main
/* 15:   */ {
/* 16:   */   private static final int PORT = 1234;
/* 17:   */   private static final boolean USE_SSL = false;
/* 18:   */   
/* 19:   */   public static void main(String[] args)
/* 20:   */     throws Exception
/* 21:   */   {
/* 22:46 */     NioSocketAcceptor acceptor = new NioSocketAcceptor();
/* 23:47 */     DefaultIoFilterChainBuilder chain = acceptor.getFilterChain();
/* 24:   */     
/* 25:49 */     MdcInjectionFilter mdcInjectionFilter = new MdcInjectionFilter();
/* 26:50 */     chain.addLast("mdc", mdcInjectionFilter);
/* 27:   */     
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:57 */     chain.addLast("codec", new ProtocolCodecFilter(new TextLineCodecFactory()));
/* 34:   */     
/* 35:   */ 
/* 36:60 */     addLogger(chain);
/* 37:   */     
/* 38:   */ 
/* 39:63 */     acceptor.setHandler(new ChatProtocolHandler());
/* 40:64 */     acceptor.bind(new InetSocketAddress(1234));
/* 41:   */     
/* 42:66 */     System.out.println("Listening on port 1234");
/* 43:   */   }
/* 44:   */   
/* 45:   */   private static void addSSLSupport(DefaultIoFilterChainBuilder chain)
/* 46:   */     throws Exception
/* 47:   */   {
/* 48:71 */     SslFilter sslFilter = new SslFilter(BogusSslContextFactory.getInstance(true));
/* 49:   */     
/* 50:73 */     chain.addLast("sslFilter", sslFilter);
/* 51:74 */     System.out.println("SSL ON");
/* 52:   */   }
/* 53:   */   
/* 54:   */   private static void addLogger(DefaultIoFilterChainBuilder chain)
/* 55:   */     throws Exception
/* 56:   */   {
/* 57:79 */     chain.addLast("logger", new LoggingFilter());
/* 58:80 */     System.out.println("Logging ON");
/* 59:   */   }
/* 60:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.chat.Main
 * JD-Core Version:    0.7.0.1
 */