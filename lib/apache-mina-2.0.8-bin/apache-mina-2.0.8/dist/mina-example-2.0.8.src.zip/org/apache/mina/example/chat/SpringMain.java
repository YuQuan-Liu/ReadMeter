/*  1:   */ package org.apache.mina.example.chat;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import org.springframework.context.ConfigurableApplicationContext;
/*  5:   */ import org.springframework.context.support.ClassPathXmlApplicationContext;
/*  6:   */ 
/*  7:   */ public class SpringMain
/*  8:   */ {
/*  9:   */   public static void main(String[] args)
/* 10:   */     throws Exception
/* 11:   */   {
/* 12:34 */     if (System.getProperty("com.sun.management.jmxremote") != null) {
/* 13:35 */       System.out.println("JMX enabled.");
/* 14:   */     } else {
/* 15:37 */       System.out.println("JMX disabled. Please set the 'com.sun.management.jmxremote' system property to enable JMX.");
/* 16:   */     }
/* 17:41 */     getApplicationContext();
/* 18:42 */     System.out.println("Listening ...");
/* 19:   */   }
/* 20:   */   
/* 21:   */   public static ConfigurableApplicationContext getApplicationContext()
/* 22:   */   {
/* 23:46 */     return new ClassPathXmlApplicationContext("org/apache/mina/example/chat/serverContext.xml");
/* 24:   */   }
/* 25:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.chat.SpringMain
 * JD-Core Version:    0.7.0.1
 */