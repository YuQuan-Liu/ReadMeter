/*   1:    */ package org.apache.mina.example.chat.client;
/*   2:    */ 
/*   3:    */ import java.net.SocketAddress;
/*   4:    */ import javax.net.ssl.SSLContext;
/*   5:    */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*   6:    */ import org.apache.mina.core.filterchain.IoFilter;
/*   7:    */ import org.apache.mina.core.future.CloseFuture;
/*   8:    */ import org.apache.mina.core.future.ConnectFuture;
/*   9:    */ import org.apache.mina.core.service.IoHandler;
/*  10:    */ import org.apache.mina.core.session.IoSession;
/*  11:    */ import org.apache.mina.example.echoserver.ssl.BogusSslContextFactory;
/*  12:    */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/*  13:    */ import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
/*  14:    */ import org.apache.mina.filter.logging.LoggingFilter;
/*  15:    */ import org.apache.mina.filter.logging.MdcInjectionFilter;
/*  16:    */ import org.apache.mina.filter.ssl.SslFilter;
/*  17:    */ import org.apache.mina.transport.socket.nio.NioSocketConnector;
/*  18:    */ 
/*  19:    */ public class ChatClientSupport
/*  20:    */ {
/*  21:    */   private final IoHandler handler;
/*  22:    */   private final String name;
/*  23:    */   private IoSession session;
/*  24:    */   
/*  25:    */   public ChatClientSupport(String name, IoHandler handler)
/*  26:    */   {
/*  27: 51 */     if (name == null) {
/*  28: 52 */       throw new IllegalArgumentException("Name can not be null");
/*  29:    */     }
/*  30: 54 */     this.name = name;
/*  31: 55 */     this.handler = handler;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public boolean connect(NioSocketConnector connector, SocketAddress address, boolean useSsl)
/*  35:    */   {
/*  36: 60 */     if ((this.session != null) && (this.session.isConnected())) {
/*  37: 61 */       throw new IllegalStateException("Already connected. Disconnect first.");
/*  38:    */     }
/*  39:    */     try
/*  40:    */     {
/*  41: 66 */       IoFilter LOGGING_FILTER = new LoggingFilter();
/*  42:    */       
/*  43: 68 */       IoFilter CODEC_FILTER = new ProtocolCodecFilter(new TextLineCodecFactory());
/*  44:    */       
/*  45:    */ 
/*  46: 71 */       connector.getFilterChain().addLast("mdc", new MdcInjectionFilter());
/*  47: 72 */       connector.getFilterChain().addLast("codec", CODEC_FILTER);
/*  48: 73 */       connector.getFilterChain().addLast("logger", LOGGING_FILTER);
/*  49: 75 */       if (useSsl)
/*  50:    */       {
/*  51: 76 */         SSLContext sslContext = BogusSslContextFactory.getInstance(false);
/*  52:    */         
/*  53: 78 */         SslFilter sslFilter = new SslFilter(sslContext);
/*  54: 79 */         sslFilter.setUseClientMode(true);
/*  55: 80 */         connector.getFilterChain().addFirst("sslFilter", sslFilter);
/*  56:    */       }
/*  57: 83 */       connector.setHandler(this.handler);
/*  58: 84 */       ConnectFuture future1 = connector.connect(address);
/*  59: 85 */       future1.awaitUninterruptibly();
/*  60: 86 */       if (!future1.isConnected()) {
/*  61: 87 */         return false;
/*  62:    */       }
/*  63: 89 */       this.session = future1.getSession();
/*  64: 90 */       login();
/*  65:    */       
/*  66: 92 */       return true;
/*  67:    */     }
/*  68:    */     catch (Exception e) {}
/*  69: 94 */     return false;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void login()
/*  73:    */   {
/*  74: 99 */     this.session.write("LOGIN " + this.name);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void broadcast(String message)
/*  78:    */   {
/*  79:103 */     this.session.write("BROADCAST " + message);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void quit()
/*  83:    */   {
/*  84:107 */     if (this.session != null)
/*  85:    */     {
/*  86:108 */       if (this.session.isConnected())
/*  87:    */       {
/*  88:109 */         this.session.write("QUIT");
/*  89:    */         
/*  90:111 */         this.session.getCloseFuture().awaitUninterruptibly();
/*  91:    */       }
/*  92:113 */       this.session.close(true);
/*  93:    */     }
/*  94:    */   }
/*  95:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.chat.client.ChatClientSupport
 * JD-Core Version:    0.7.0.1
 */