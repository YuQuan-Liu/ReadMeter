/*   1:    */ package org.apache.mina.example.chat.client;
/*   2:    */ 
/*   3:    */ import java.awt.Container;
/*   4:    */ import java.awt.Frame;
/*   5:    */ import java.awt.HeadlessException;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import javax.swing.AbstractAction;
/*   8:    */ import javax.swing.BoxLayout;
/*   9:    */ import javax.swing.JButton;
/*  10:    */ import javax.swing.JCheckBox;
/*  11:    */ import javax.swing.JDialog;
/*  12:    */ import javax.swing.JLabel;
/*  13:    */ import javax.swing.JPanel;
/*  14:    */ import javax.swing.JTextField;
/*  15:    */ 
/*  16:    */ public class ConnectDialog
/*  17:    */   extends JDialog
/*  18:    */ {
/*  19:    */   private static final long serialVersionUID = 2009384520250666216L;
/*  20:    */   private String serverAddress;
/*  21:    */   private String username;
/*  22:    */   private boolean useSsl;
/*  23: 51 */   private boolean cancelled = false;
/*  24:    */   
/*  25:    */   public ConnectDialog(Frame owner)
/*  26:    */     throws HeadlessException
/*  27:    */   {
/*  28: 54 */     super(owner, "Connect", true);
/*  29:    */     
/*  30: 56 */     this.serverAddress = "localhost:1234";
/*  31: 57 */     this.username = ("user" + Math.round(Math.random() * 10.0D));
/*  32:    */     
/*  33: 59 */     final JTextField serverAddressField = new JTextField(this.serverAddress);
/*  34: 60 */     final JTextField usernameField = new JTextField(this.username);
/*  35: 61 */     final JCheckBox useSslCheckBox = new JCheckBox("Use SSL", false);
/*  36:    */     
/*  37: 63 */     JPanel content = new JPanel();
/*  38: 64 */     content.setLayout(new BoxLayout(content, 3));
/*  39: 65 */     content.add(new JLabel("Server address"));
/*  40: 66 */     content.add(serverAddressField);
/*  41: 67 */     content.add(new JLabel("Username"));
/*  42: 68 */     content.add(usernameField);
/*  43: 69 */     content.add(useSslCheckBox);
/*  44:    */     
/*  45: 71 */     JButton okButton = new JButton();
/*  46: 72 */     okButton.setAction(new AbstractAction("OK")
/*  47:    */     {
/*  48:    */       private static final long serialVersionUID = -2292183622613960604L;
/*  49:    */       
/*  50:    */       public void actionPerformed(ActionEvent e)
/*  51:    */       {
/*  52: 76 */         ConnectDialog.this.serverAddress = serverAddressField.getText();
/*  53: 77 */         ConnectDialog.this.username = usernameField.getText();
/*  54: 78 */         ConnectDialog.this.useSsl = useSslCheckBox.isSelected();
/*  55: 79 */         ConnectDialog.this.dispose();
/*  56:    */       }
/*  57: 82 */     });
/*  58: 83 */     JButton cancelButton = new JButton();
/*  59: 84 */     cancelButton.setAction(new AbstractAction("Cancel")
/*  60:    */     {
/*  61:    */       private static final long serialVersionUID = 6122393546173723305L;
/*  62:    */       
/*  63:    */       public void actionPerformed(ActionEvent e)
/*  64:    */       {
/*  65: 88 */         ConnectDialog.this.cancelled = true;
/*  66: 89 */         ConnectDialog.this.dispose();
/*  67:    */       }
/*  68: 92 */     });
/*  69: 93 */     JPanel buttons = new JPanel();
/*  70: 94 */     buttons.add(okButton);
/*  71: 95 */     buttons.add(cancelButton);
/*  72:    */     
/*  73: 97 */     getContentPane().add(content, "Center");
/*  74: 98 */     getContentPane().add(buttons, "South");
/*  75:    */   }
/*  76:    */   
/*  77:    */   public boolean isCancelled()
/*  78:    */   {
/*  79:102 */     return this.cancelled;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public String getServerAddress()
/*  83:    */   {
/*  84:106 */     return this.serverAddress;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public String getUsername()
/*  88:    */   {
/*  89:110 */     return this.username;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public boolean isUseSsl()
/*  93:    */   {
/*  94:114 */     return this.useSsl;
/*  95:    */   }
/*  96:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.chat.client.ConnectDialog
 * JD-Core Version:    0.7.0.1
 */