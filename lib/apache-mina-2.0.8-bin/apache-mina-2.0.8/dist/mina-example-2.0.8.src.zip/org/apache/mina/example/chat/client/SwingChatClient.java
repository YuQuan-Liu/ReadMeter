/*   1:    */ package org.apache.mina.example.chat.client;
/*   2:    */ 
/*   3:    */ import java.awt.Container;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.awt.event.ActionEvent;
/*   6:    */ import java.awt.event.ActionListener;
/*   7:    */ import java.net.InetSocketAddress;
/*   8:    */ import java.net.SocketAddress;
/*   9:    */ import javax.swing.AbstractAction;
/*  10:    */ import javax.swing.BorderFactory;
/*  11:    */ import javax.swing.Box;
/*  12:    */ import javax.swing.BoxLayout;
/*  13:    */ import javax.swing.JButton;
/*  14:    */ import javax.swing.JFrame;
/*  15:    */ import javax.swing.JLabel;
/*  16:    */ import javax.swing.JOptionPane;
/*  17:    */ import javax.swing.JPanel;
/*  18:    */ import javax.swing.JScrollBar;
/*  19:    */ import javax.swing.JTextArea;
/*  20:    */ import javax.swing.JTextField;
/*  21:    */ import javax.swing.border.EmptyBorder;
/*  22:    */ import org.apache.mina.transport.socket.nio.NioSocketConnector;
/*  23:    */ 
/*  24:    */ public class SwingChatClient
/*  25:    */   extends JFrame
/*  26:    */   implements SwingChatClientHandler.Callback
/*  27:    */ {
/*  28:    */   private static final long serialVersionUID = 1538675161745436968L;
/*  29:    */   private JTextField inputText;
/*  30:    */   private JButton loginButton;
/*  31:    */   private JButton quitButton;
/*  32:    */   private JButton closeButton;
/*  33:    */   private JTextField serverField;
/*  34:    */   private JTextField nameField;
/*  35:    */   private JTextArea area;
/*  36:    */   private JScrollBar scroll;
/*  37:    */   private ChatClientSupport client;
/*  38:    */   private SwingChatClientHandler handler;
/*  39:    */   private NioSocketConnector connector;
/*  40:    */   
/*  41:    */   public SwingChatClient()
/*  42:    */   {
/*  43: 77 */     super("Chat Client based on Apache MINA");
/*  44:    */     
/*  45: 79 */     this.connector = new NioSocketConnector();
/*  46:    */     
/*  47: 81 */     this.loginButton = new JButton(new LoginAction());
/*  48: 82 */     this.loginButton.setText("Connect");
/*  49: 83 */     this.quitButton = new JButton(new LogoutAction(null));
/*  50: 84 */     this.quitButton.setText("Disconnect");
/*  51: 85 */     this.closeButton = new JButton(new QuitAction(null));
/*  52: 86 */     this.closeButton.setText("Quit");
/*  53: 87 */     this.inputText = new JTextField(30);
/*  54: 88 */     this.inputText.setAction(new BroadcastAction(null));
/*  55: 89 */     this.area = new JTextArea(10, 50);
/*  56: 90 */     this.area.setLineWrap(true);
/*  57: 91 */     this.area.setEditable(false);
/*  58: 92 */     this.scroll = new JScrollBar();
/*  59: 93 */     this.scroll.add(this.area);
/*  60: 94 */     this.nameField = new JTextField(10);
/*  61: 95 */     this.nameField.setEditable(false);
/*  62: 96 */     this.serverField = new JTextField(10);
/*  63: 97 */     this.serverField.setEditable(false);
/*  64:    */     
/*  65: 99 */     JPanel h = new JPanel();
/*  66:100 */     h.setLayout(new BoxLayout(h, 2));
/*  67:101 */     h.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
/*  68:102 */     JLabel nameLabel = new JLabel("Name: ");
/*  69:103 */     JLabel serverLabel = new JLabel("Server: ");
/*  70:104 */     h.add(nameLabel);
/*  71:105 */     h.add(Box.createRigidArea(new Dimension(10, 0)));
/*  72:106 */     h.add(this.nameField);
/*  73:107 */     h.add(Box.createRigidArea(new Dimension(10, 0)));
/*  74:108 */     h.add(Box.createHorizontalGlue());
/*  75:109 */     h.add(Box.createRigidArea(new Dimension(10, 0)));
/*  76:110 */     h.add(serverLabel);
/*  77:111 */     h.add(Box.createRigidArea(new Dimension(10, 0)));
/*  78:112 */     h.add(this.serverField);
/*  79:    */     
/*  80:114 */     JPanel p = new JPanel();
/*  81:115 */     p.setLayout(new BoxLayout(p, 2));
/*  82:116 */     p.setBorder(new EmptyBorder(10, 10, 10, 10));
/*  83:    */     
/*  84:118 */     JPanel left = new JPanel();
/*  85:119 */     left.setLayout(new BoxLayout(left, 3));
/*  86:120 */     left.add(this.area);
/*  87:121 */     left.add(Box.createRigidArea(new Dimension(0, 5)));
/*  88:122 */     left.add(Box.createHorizontalGlue());
/*  89:123 */     left.add(this.inputText);
/*  90:    */     
/*  91:125 */     JPanel right = new JPanel();
/*  92:126 */     right.setLayout(new BoxLayout(right, 3));
/*  93:127 */     right.add(this.loginButton);
/*  94:128 */     right.add(Box.createRigidArea(new Dimension(0, 5)));
/*  95:129 */     right.add(this.quitButton);
/*  96:130 */     right.add(Box.createHorizontalGlue());
/*  97:131 */     right.add(Box.createRigidArea(new Dimension(0, 25)));
/*  98:132 */     right.add(this.closeButton);
/*  99:    */     
/* 100:134 */     p.add(left);
/* 101:135 */     p.add(Box.createRigidArea(new Dimension(10, 0)));
/* 102:136 */     p.add(right);
/* 103:    */     
/* 104:138 */     getContentPane().add(h, "North");
/* 105:139 */     getContentPane().add(p);
/* 106:    */     
/* 107:141 */     this.closeButton.addActionListener(new ActionListener()
/* 108:    */     {
/* 109:    */       public void actionPerformed(ActionEvent e)
/* 110:    */       {
/* 111:143 */         SwingChatClient.this.client.quit();
/* 112:144 */         SwingChatClient.this.connector.dispose();
/* 113:145 */         SwingChatClient.this.dispose();
/* 114:    */       }
/* 115:147 */     });
/* 116:148 */     setLoggedOut();
/* 117:149 */     setDefaultCloseOperation(3);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public class LoginAction
/* 121:    */     extends AbstractAction
/* 122:    */   {
/* 123:    */     private static final long serialVersionUID = 3596719854773863244L;
/* 124:    */     
/* 125:    */     public LoginAction() {}
/* 126:    */     
/* 127:    */     public void actionPerformed(ActionEvent e)
/* 128:    */     {
/* 129:157 */       ConnectDialog dialog = new ConnectDialog(SwingChatClient.this);
/* 130:158 */       dialog.pack();
/* 131:159 */       dialog.setVisible(true);
/* 132:161 */       if (dialog.isCancelled()) {
/* 133:162 */         return;
/* 134:    */       }
/* 135:165 */       SocketAddress address = SwingChatClient.this.parseSocketAddress(dialog.getServerAddress());
/* 136:    */       
/* 137:167 */       String name = dialog.getUsername();
/* 138:    */       
/* 139:169 */       SwingChatClient.this.handler = new SwingChatClientHandler(SwingChatClient.this);
/* 140:170 */       SwingChatClient.this.client = new ChatClientSupport(name, SwingChatClient.this.handler);
/* 141:171 */       SwingChatClient.this.nameField.setText(name);
/* 142:172 */       SwingChatClient.this.serverField.setText(dialog.getServerAddress());
/* 143:174 */       if (!SwingChatClient.this.client.connect(SwingChatClient.this.connector, address, dialog.isUseSsl())) {
/* 144:175 */         JOptionPane.showMessageDialog(SwingChatClient.this, "Could not connect to " + dialog.getServerAddress() + ". ");
/* 145:    */       }
/* 146:    */     }
/* 147:    */   }
/* 148:    */   
/* 149:    */   private class LogoutAction
/* 150:    */     extends AbstractAction
/* 151:    */   {
/* 152:    */     private static final long serialVersionUID = 1655297424639924560L;
/* 153:    */     
/* 154:    */     private LogoutAction() {}
/* 155:    */     
/* 156:    */     public void actionPerformed(ActionEvent e)
/* 157:    */     {
/* 158:    */       try
/* 159:    */       {
/* 160:187 */         SwingChatClient.this.client.quit();
/* 161:188 */         SwingChatClient.this.setLoggedOut();
/* 162:    */       }
/* 163:    */       catch (Exception e1)
/* 164:    */       {
/* 165:190 */         JOptionPane.showMessageDialog(SwingChatClient.this, "Session could not be closed.");
/* 166:    */       }
/* 167:    */     }
/* 168:    */   }
/* 169:    */   
/* 170:    */   private class BroadcastAction
/* 171:    */     extends AbstractAction
/* 172:    */   {
/* 173:    */     private static final long serialVersionUID = -6276019615521905411L;
/* 174:    */     
/* 175:    */     private BroadcastAction() {}
/* 176:    */     
/* 177:    */     public void actionPerformed(ActionEvent e)
/* 178:    */     {
/* 179:203 */       SwingChatClient.this.client.broadcast(SwingChatClient.this.inputText.getText());
/* 180:204 */       SwingChatClient.this.inputText.setText("");
/* 181:    */     }
/* 182:    */   }
/* 183:    */   
/* 184:    */   private class QuitAction
/* 185:    */     extends AbstractAction
/* 186:    */   {
/* 187:    */     private static final long serialVersionUID = -6389802816912005370L;
/* 188:    */     
/* 189:    */     private QuitAction() {}
/* 190:    */     
/* 191:    */     public void actionPerformed(ActionEvent e)
/* 192:    */     {
/* 193:212 */       if (SwingChatClient.this.client != null) {
/* 194:213 */         SwingChatClient.this.client.quit();
/* 195:    */       }
/* 196:215 */       SwingChatClient.this.dispose();
/* 197:    */     }
/* 198:    */   }
/* 199:    */   
/* 200:    */   private void setLoggedOut()
/* 201:    */   {
/* 202:220 */     this.inputText.setEnabled(false);
/* 203:221 */     this.quitButton.setEnabled(false);
/* 204:222 */     this.loginButton.setEnabled(true);
/* 205:    */   }
/* 206:    */   
/* 207:    */   private void setLoggedIn()
/* 208:    */   {
/* 209:226 */     this.area.setText("");
/* 210:227 */     this.inputText.setEnabled(true);
/* 211:228 */     this.quitButton.setEnabled(true);
/* 212:229 */     this.loginButton.setEnabled(false);
/* 213:    */   }
/* 214:    */   
/* 215:    */   private void append(String text)
/* 216:    */   {
/* 217:233 */     this.area.append(text);
/* 218:    */   }
/* 219:    */   
/* 220:    */   private void notifyError(String message)
/* 221:    */   {
/* 222:237 */     JOptionPane.showMessageDialog(this, message);
/* 223:    */   }
/* 224:    */   
/* 225:    */   private SocketAddress parseSocketAddress(String s)
/* 226:    */   {
/* 227:241 */     s = s.trim();
/* 228:242 */     int colonIndex = s.indexOf(":");
/* 229:243 */     if (colonIndex > 0)
/* 230:    */     {
/* 231:244 */       String host = s.substring(0, colonIndex);
/* 232:245 */       int port = parsePort(s.substring(colonIndex + 1));
/* 233:246 */       return new InetSocketAddress(host, port);
/* 234:    */     }
/* 235:248 */     int port = parsePort(s.substring(colonIndex + 1));
/* 236:249 */     return new InetSocketAddress(port);
/* 237:    */   }
/* 238:    */   
/* 239:    */   private int parsePort(String s)
/* 240:    */   {
/* 241:    */     try
/* 242:    */     {
/* 243:255 */       return Integer.parseInt(s);
/* 244:    */     }
/* 245:    */     catch (NumberFormatException nfe)
/* 246:    */     {
/* 247:257 */       throw new IllegalArgumentException("Illegal port number: " + s);
/* 248:    */     }
/* 249:    */   }
/* 250:    */   
/* 251:    */   public void connected() {}
/* 252:    */   
/* 253:    */   public void disconnected()
/* 254:    */   {
/* 255:265 */     append("Connection closed.\n");
/* 256:266 */     setLoggedOut();
/* 257:    */   }
/* 258:    */   
/* 259:    */   public void error(String message)
/* 260:    */   {
/* 261:270 */     notifyError(message + "\n");
/* 262:    */   }
/* 263:    */   
/* 264:    */   public void loggedIn()
/* 265:    */   {
/* 266:274 */     setLoggedIn();
/* 267:275 */     append("You have joined the chat session.\n");
/* 268:    */   }
/* 269:    */   
/* 270:    */   public void loggedOut()
/* 271:    */   {
/* 272:279 */     append("You have left the chat session.\n");
/* 273:280 */     setLoggedOut();
/* 274:    */   }
/* 275:    */   
/* 276:    */   public void messageReceived(String message)
/* 277:    */   {
/* 278:284 */     append(message + "\n");
/* 279:    */   }
/* 280:    */   
/* 281:    */   public static void main(String[] args)
/* 282:    */   {
/* 283:288 */     SwingChatClient client = new SwingChatClient();
/* 284:289 */     client.pack();
/* 285:290 */     client.setVisible(true);
/* 286:    */   }
/* 287:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.chat.client.SwingChatClient
 * JD-Core Version:    0.7.0.1
 */