/*  1:   */ package org.apache.mina.example.chat.client;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.service.IoHandlerAdapter;
/*  4:   */ import org.apache.mina.core.session.IoSession;
/*  5:   */ import org.apache.mina.example.chat.ChatCommand;
/*  6:   */ 
/*  7:   */ public class SwingChatClientHandler
/*  8:   */   extends IoHandlerAdapter
/*  9:   */ {
/* 10:   */   private final Callback callback;
/* 11:   */   
/* 12:   */   public SwingChatClientHandler(Callback callback)
/* 13:   */   {
/* 14:51 */     this.callback = callback;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void sessionOpened(IoSession session)
/* 18:   */     throws Exception
/* 19:   */   {
/* 20:56 */     this.callback.connected();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void messageReceived(IoSession session, Object message)
/* 24:   */     throws Exception
/* 25:   */   {
/* 26:62 */     String theMessage = (String)message;
/* 27:63 */     String[] result = theMessage.split(" ", 3);
/* 28:64 */     String status = result[1];
/* 29:65 */     String theCommand = result[0];
/* 30:66 */     ChatCommand command = ChatCommand.valueOf(theCommand);
/* 31:68 */     if ("OK".equals(status)) {
/* 32:70 */       switch (command.toInt())
/* 33:   */       {
/* 34:   */       case 2: 
/* 35:73 */         if (result.length == 3) {
/* 36:74 */           this.callback.messageReceived(result[2]);
/* 37:   */         }
/* 38:   */         break;
/* 39:   */       case 0: 
/* 40:78 */         this.callback.loggedIn();
/* 41:79 */         break;
/* 42:   */       case 1: 
/* 43:82 */         this.callback.loggedOut();
/* 44:   */       }
/* 45:87 */     } else if (result.length == 3) {
/* 46:88 */       this.callback.error(result[2]);
/* 47:   */     }
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void sessionClosed(IoSession session)
/* 51:   */     throws Exception
/* 52:   */   {
/* 53:95 */     this.callback.disconnected();
/* 54:   */   }
/* 55:   */   
/* 56:   */   public static abstract interface Callback
/* 57:   */   {
/* 58:   */     public abstract void connected();
/* 59:   */     
/* 60:   */     public abstract void loggedIn();
/* 61:   */     
/* 62:   */     public abstract void loggedOut();
/* 63:   */     
/* 64:   */     public abstract void disconnected();
/* 65:   */     
/* 66:   */     public abstract void messageReceived(String paramString);
/* 67:   */     
/* 68:   */     public abstract void error(String paramString);
/* 69:   */   }
/* 70:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.chat.client.SwingChatClientHandler
 * JD-Core Version:    0.7.0.1
 */