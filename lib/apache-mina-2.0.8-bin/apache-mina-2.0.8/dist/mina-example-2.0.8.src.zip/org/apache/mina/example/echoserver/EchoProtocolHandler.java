/*  1:   */ package org.apache.mina.example.echoserver;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  4:   */ import org.apache.mina.core.service.IoHandlerAdapter;
/*  5:   */ import org.apache.mina.core.session.IdleStatus;
/*  6:   */ import org.apache.mina.core.session.IoSession;
/*  7:   */ import org.apache.mina.core.session.IoSessionConfig;
/*  8:   */ import org.apache.mina.filter.ssl.SslFilter;
/*  9:   */ import org.slf4j.Logger;
/* 10:   */ import org.slf4j.LoggerFactory;
/* 11:   */ 
/* 12:   */ public class EchoProtocolHandler
/* 13:   */   extends IoHandlerAdapter
/* 14:   */ {
/* 15:37 */   private static final Logger LOGGER = LoggerFactory.getLogger(EchoProtocolHandler.class);
/* 16:   */   
/* 17:   */   public void sessionCreated(IoSession session)
/* 18:   */   {
/* 19:41 */     session.getConfig().setIdleTime(IdleStatus.BOTH_IDLE, 10);
/* 20:   */     
/* 21:   */ 
/* 22:44 */     session.setAttribute(SslFilter.USE_NOTIFICATION);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void sessionClosed(IoSession session)
/* 26:   */     throws Exception
/* 27:   */   {
/* 28:49 */     LOGGER.info("CLOSED");
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void sessionOpened(IoSession session)
/* 32:   */     throws Exception
/* 33:   */   {
/* 34:54 */     LOGGER.info("OPENED");
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void sessionIdle(IoSession session, IdleStatus status)
/* 38:   */   {
/* 39:59 */     LOGGER.info("*** IDLE #" + session.getIdleCount(IdleStatus.BOTH_IDLE) + " ***");
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void exceptionCaught(IoSession session, Throwable cause)
/* 43:   */   {
/* 44:64 */     session.close(true);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void messageReceived(IoSession session, Object message)
/* 48:   */     throws Exception
/* 49:   */   {
/* 50:70 */     LOGGER.info("Received : " + message);
/* 51:   */     
/* 52:72 */     session.write(((IoBuffer)message).duplicate());
/* 53:   */   }
/* 54:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.echoserver.EchoProtocolHandler
 * JD-Core Version:    0.7.0.1
 */