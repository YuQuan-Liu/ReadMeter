/*  1:   */ package org.apache.mina.example.echoserver;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import java.net.InetSocketAddress;
/*  5:   */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*  6:   */ import org.apache.mina.core.service.IoServiceStatistics;
/*  7:   */ import org.apache.mina.example.echoserver.ssl.BogusSslContextFactory;
/*  8:   */ import org.apache.mina.filter.ssl.SslFilter;
/*  9:   */ import org.apache.mina.transport.socket.SocketAcceptor;
/* 10:   */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
/* 11:   */ 
/* 12:   */ public class Main
/* 13:   */ {
/* 14:   */   private static final int PORT = 8080;
/* 15:   */   private static final boolean USE_SSL = false;
/* 16:   */   
/* 17:   */   public static void main(String[] args)
/* 18:   */     throws Exception
/* 19:   */   {
/* 20:43 */     SocketAcceptor acceptor = new NioSocketAcceptor();
/* 21:44 */     acceptor.setReuseAddress(true);
/* 22:45 */     DefaultIoFilterChainBuilder chain = acceptor.getFilterChain();
/* 23:   */     
/* 24:   */ 
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:53 */     acceptor.setHandler(new EchoProtocolHandler());
/* 31:54 */     acceptor.bind(new InetSocketAddress(8080));
/* 32:   */     
/* 33:56 */     System.out.println("Listening on port 8080");
/* 34:   */     for (;;)
/* 35:   */     {
/* 36:59 */       System.out.println("R: " + acceptor.getStatistics().getReadBytesThroughput() + ", W: " + acceptor.getStatistics().getWrittenBytesThroughput());
/* 37:   */       
/* 38:61 */       Thread.sleep(3000L);
/* 39:   */     }
/* 40:   */   }
/* 41:   */   
/* 42:   */   private static void addSSLSupport(DefaultIoFilterChainBuilder chain)
/* 43:   */     throws Exception
/* 44:   */   {
/* 45:67 */     SslFilter sslFilter = new SslFilter(BogusSslContextFactory.getInstance(true));
/* 46:   */     
/* 47:69 */     chain.addLast("sslFilter", sslFilter);
/* 48:70 */     System.out.println("SSL ON");
/* 49:   */   }
/* 50:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.echoserver.Main
 * JD-Core Version:    0.7.0.1
 */