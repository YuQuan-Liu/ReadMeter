/*   1:    */ package org.apache.mina.example.echoserver.ssl;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.InputStream;
/*   5:    */ import java.security.GeneralSecurityException;
/*   6:    */ import java.security.KeyStore;
/*   7:    */ import java.security.Security;
/*   8:    */ import javax.net.ssl.KeyManagerFactory;
/*   9:    */ import javax.net.ssl.SSLContext;
/*  10:    */ 
/*  11:    */ public class BogusSslContextFactory
/*  12:    */ {
/*  13:    */   private static final String PROTOCOL = "TLS";
/*  14:    */   private static final String KEY_MANAGER_FACTORY_ALGORITHM;
/*  15:    */   private static final String BOGUS_KEYSTORE = "bogus.cert";
/*  16:    */   
/*  17:    */   static
/*  18:    */   {
/*  19: 46 */     String algorithm = Security.getProperty("ssl.KeyManagerFactory.algorithm");
/*  20: 48 */     if (algorithm == null) {
/*  21: 49 */       algorithm = KeyManagerFactory.getDefaultAlgorithm();
/*  22:    */     }
/*  23: 52 */     KEY_MANAGER_FACTORY_ALGORITHM = algorithm;
/*  24:    */   }
/*  25:    */   
/*  26: 69 */   private static final char[] BOGUS_PW = { 'b', 'o', 'g', 'u', 's', 'p', 'w' };
/*  27: 71 */   private static SSLContext serverInstance = null;
/*  28: 73 */   private static SSLContext clientInstance = null;
/*  29:    */   
/*  30:    */   public static SSLContext getInstance(boolean server)
/*  31:    */     throws GeneralSecurityException
/*  32:    */   {
/*  33: 84 */     SSLContext retInstance = null;
/*  34: 85 */     if (server)
/*  35:    */     {
/*  36: 86 */       synchronized (BogusSslContextFactory.class)
/*  37:    */       {
/*  38: 87 */         if (serverInstance == null) {
/*  39:    */           try
/*  40:    */           {
/*  41: 89 */             serverInstance = createBougusServerSslContext();
/*  42:    */           }
/*  43:    */           catch (Exception ioe)
/*  44:    */           {
/*  45: 91 */             throw new GeneralSecurityException("Can't create Server SSLContext:" + ioe);
/*  46:    */           }
/*  47:    */         }
/*  48:    */       }
/*  49: 96 */       retInstance = serverInstance;
/*  50:    */     }
/*  51:    */     else
/*  52:    */     {
/*  53: 98 */       synchronized (BogusSslContextFactory.class)
/*  54:    */       {
/*  55: 99 */         if (clientInstance == null) {
/*  56:100 */           clientInstance = createBougusClientSslContext();
/*  57:    */         }
/*  58:    */       }
/*  59:103 */       retInstance = clientInstance;
/*  60:    */     }
/*  61:105 */     return retInstance;
/*  62:    */   }
/*  63:    */   
/*  64:    */   private static SSLContext createBougusServerSslContext()
/*  65:    */     throws GeneralSecurityException, IOException
/*  66:    */   {
/*  67:111 */     KeyStore ks = KeyStore.getInstance("JKS");
/*  68:112 */     InputStream in = null;
/*  69:    */     try
/*  70:    */     {
/*  71:114 */       in = BogusSslContextFactory.class.getResourceAsStream("bogus.cert");
/*  72:    */       
/*  73:116 */       ks.load(in, BOGUS_PW);
/*  74:118 */       if (in != null) {
/*  75:    */         try
/*  76:    */         {
/*  77:120 */           in.close();
/*  78:    */         }
/*  79:    */         catch (IOException ignored) {}
/*  80:    */       }
/*  81:127 */       kmf = KeyManagerFactory.getInstance(KEY_MANAGER_FACTORY_ALGORITHM);
/*  82:    */     }
/*  83:    */     finally
/*  84:    */     {
/*  85:118 */       if (in != null) {
/*  86:    */         try
/*  87:    */         {
/*  88:120 */           in.close();
/*  89:    */         }
/*  90:    */         catch (IOException ignored) {}
/*  91:    */       }
/*  92:    */     }
/*  93:    */     KeyManagerFactory kmf;
/*  94:129 */     kmf.init(ks, BOGUS_PW);
/*  95:    */     
/*  96:    */ 
/*  97:132 */     SSLContext sslContext = SSLContext.getInstance("TLS");
/*  98:133 */     sslContext.init(kmf.getKeyManagers(), BogusTrustManagerFactory.X509_MANAGERS, null);
/*  99:    */     
/* 100:    */ 
/* 101:136 */     return sslContext;
/* 102:    */   }
/* 103:    */   
/* 104:    */   private static SSLContext createBougusClientSslContext()
/* 105:    */     throws GeneralSecurityException
/* 106:    */   {
/* 107:141 */     SSLContext context = SSLContext.getInstance("TLS");
/* 108:142 */     context.init(null, BogusTrustManagerFactory.X509_MANAGERS, null);
/* 109:143 */     return context;
/* 110:    */   }
/* 111:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.echoserver.ssl.BogusSslContextFactory
 * JD-Core Version:    0.7.0.1
 */