/*  1:   */ package org.apache.mina.example.echoserver.ssl;
/*  2:   */ 
/*  3:   */ import java.security.InvalidAlgorithmParameterException;
/*  4:   */ import java.security.KeyStore;
/*  5:   */ import java.security.KeyStoreException;
/*  6:   */ import java.security.cert.CertificateException;
/*  7:   */ import java.security.cert.X509Certificate;
/*  8:   */ import javax.net.ssl.ManagerFactoryParameters;
/*  9:   */ import javax.net.ssl.TrustManager;
/* 10:   */ import javax.net.ssl.TrustManagerFactorySpi;
/* 11:   */ import javax.net.ssl.X509TrustManager;
/* 12:   */ 
/* 13:   */ class BogusTrustManagerFactory
/* 14:   */   extends TrustManagerFactorySpi
/* 15:   */ {
/* 16:40 */   static final X509TrustManager X509 = new X509TrustManager()
/* 17:   */   {
/* 18:   */     public void checkClientTrusted(X509Certificate[] x509Certificates, String s)
/* 19:   */       throws CertificateException
/* 20:   */     {}
/* 21:   */     
/* 22:   */     public void checkServerTrusted(X509Certificate[] x509Certificates, String s)
/* 23:   */       throws CertificateException
/* 24:   */     {}
/* 25:   */     
/* 26:   */     public X509Certificate[] getAcceptedIssuers()
/* 27:   */     {
/* 28:50 */       return new X509Certificate[0];
/* 29:   */     }
/* 30:   */   };
/* 31:54 */   static final TrustManager[] X509_MANAGERS = { X509 };
/* 32:   */   
/* 33:   */   protected TrustManager[] engineGetTrustManagers()
/* 34:   */   {
/* 35:61 */     return X509_MANAGERS;
/* 36:   */   }
/* 37:   */   
/* 38:   */   protected void engineInit(KeyStore keystore)
/* 39:   */     throws KeyStoreException
/* 40:   */   {}
/* 41:   */   
/* 42:   */   protected void engineInit(ManagerFactoryParameters managerFactoryParameters)
/* 43:   */     throws InvalidAlgorithmParameterException
/* 44:   */   {}
/* 45:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.echoserver.ssl.BogusTrustManagerFactory
 * JD-Core Version:    0.7.0.1
 */