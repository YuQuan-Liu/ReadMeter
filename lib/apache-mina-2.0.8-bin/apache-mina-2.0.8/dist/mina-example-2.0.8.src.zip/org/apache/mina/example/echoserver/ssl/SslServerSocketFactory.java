/*  1:   */ package org.apache.mina.example.echoserver.ssl;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.net.InetAddress;
/*  5:   */ import java.net.ServerSocket;
/*  6:   */ import java.security.GeneralSecurityException;
/*  7:   */ import javax.net.ServerSocketFactory;
/*  8:   */ import javax.net.ssl.SSLContext;
/*  9:   */ 
/* 10:   */ public class SslServerSocketFactory
/* 11:   */   extends ServerSocketFactory
/* 12:   */ {
/* 13:36 */   private static boolean sslEnabled = false;
/* 14:38 */   private static ServerSocketFactory sslFactory = null;
/* 15:40 */   private static ServerSocketFactory factory = null;
/* 16:   */   
/* 17:   */   public ServerSocket createServerSocket(int port)
/* 18:   */     throws IOException
/* 19:   */   {
/* 20:48 */     return new ServerSocket(port);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public ServerSocket createServerSocket(int port, int backlog)
/* 24:   */     throws IOException
/* 25:   */   {
/* 26:54 */     return new ServerSocket(port, backlog);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public ServerSocket createServerSocket(int port, int backlog, InetAddress ifAddress)
/* 30:   */     throws IOException
/* 31:   */   {
/* 32:60 */     return new ServerSocket(port, backlog, ifAddress);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public static ServerSocketFactory getServerSocketFactory()
/* 36:   */     throws IOException
/* 37:   */   {
/* 38:65 */     if (isSslEnabled())
/* 39:   */     {
/* 40:66 */       if (sslFactory == null) {
/* 41:   */         try
/* 42:   */         {
/* 43:68 */           sslFactory = BogusSslContextFactory.getInstance(true).getServerSocketFactory();
/* 44:   */         }
/* 45:   */         catch (GeneralSecurityException e)
/* 46:   */         {
/* 47:71 */           IOException ioe = new IOException("could not create SSL socket");
/* 48:   */           
/* 49:73 */           ioe.initCause(e);
/* 50:74 */           throw ioe;
/* 51:   */         }
/* 52:   */       }
/* 53:77 */       return sslFactory;
/* 54:   */     }
/* 55:79 */     if (factory == null) {
/* 56:80 */       factory = new SslServerSocketFactory();
/* 57:   */     }
/* 58:82 */     return factory;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public static boolean isSslEnabled()
/* 62:   */   {
/* 63:88 */     return sslEnabled;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public static void setSslEnabled(boolean newSslEnabled)
/* 67:   */   {
/* 68:92 */     sslEnabled = newSslEnabled;
/* 69:   */   }
/* 70:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.echoserver.ssl.SslServerSocketFactory
 * JD-Core Version:    0.7.0.1
 */