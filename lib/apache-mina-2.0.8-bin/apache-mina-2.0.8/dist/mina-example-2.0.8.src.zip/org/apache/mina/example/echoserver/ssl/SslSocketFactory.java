/*   1:    */ package org.apache.mina.example.echoserver.ssl;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.net.InetAddress;
/*   5:    */ import java.net.Socket;
/*   6:    */ import java.net.UnknownHostException;
/*   7:    */ import java.security.GeneralSecurityException;
/*   8:    */ import javax.net.SocketFactory;
/*   9:    */ import javax.net.ssl.SSLContext;
/*  10:    */ import javax.net.ssl.SSLSocketFactory;
/*  11:    */ 
/*  12:    */ public class SslSocketFactory
/*  13:    */   extends SocketFactory
/*  14:    */ {
/*  15: 37 */   private static boolean sslEnabled = false;
/*  16: 39 */   private static SSLSocketFactory sslFactory = null;
/*  17: 41 */   private static SocketFactory factory = null;
/*  18:    */   
/*  19:    */   public Socket createSocket(String arg1, int arg2)
/*  20:    */     throws IOException, UnknownHostException
/*  21:    */   {
/*  22: 50 */     if (isSslEnabled()) {
/*  23: 51 */       return getSSLFactory().createSocket(arg1, arg2);
/*  24:    */     }
/*  25: 53 */     return new Socket(arg1, arg2);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public Socket createSocket(String arg1, int arg2, InetAddress arg3, int arg4)
/*  29:    */     throws IOException, UnknownHostException
/*  30:    */   {
/*  31: 60 */     if (isSslEnabled()) {
/*  32: 61 */       return getSSLFactory().createSocket(arg1, arg2, arg3, arg4);
/*  33:    */     }
/*  34: 63 */     return new Socket(arg1, arg2, arg3, arg4);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public Socket createSocket(InetAddress arg1, int arg2)
/*  38:    */     throws IOException
/*  39:    */   {
/*  40: 69 */     if (isSslEnabled()) {
/*  41: 70 */       return getSSLFactory().createSocket(arg1, arg2);
/*  42:    */     }
/*  43: 72 */     return new Socket(arg1, arg2);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Socket createSocket(InetAddress arg1, int arg2, InetAddress arg3, int arg4)
/*  47:    */     throws IOException
/*  48:    */   {
/*  49: 79 */     if (isSslEnabled()) {
/*  50: 80 */       return getSSLFactory().createSocket(arg1, arg2, arg3, arg4);
/*  51:    */     }
/*  52: 82 */     return new Socket(arg1, arg2, arg3, arg4);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static SocketFactory getSocketFactory()
/*  56:    */   {
/*  57: 87 */     if (factory == null) {
/*  58: 88 */       factory = new SslSocketFactory();
/*  59:    */     }
/*  60: 90 */     return factory;
/*  61:    */   }
/*  62:    */   
/*  63:    */   private SSLSocketFactory getSSLFactory()
/*  64:    */   {
/*  65: 94 */     if (sslFactory == null) {
/*  66:    */       try
/*  67:    */       {
/*  68: 96 */         sslFactory = BogusSslContextFactory.getInstance(false).getSocketFactory();
/*  69:    */       }
/*  70:    */       catch (GeneralSecurityException e)
/*  71:    */       {
/*  72: 99 */         throw new RuntimeException("could not create SSL socket", e);
/*  73:    */       }
/*  74:    */     }
/*  75:102 */     return sslFactory;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static boolean isSslEnabled()
/*  79:    */   {
/*  80:106 */     return sslEnabled;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static void setSslEnabled(boolean newSslEnabled)
/*  84:    */   {
/*  85:110 */     sslEnabled = newSslEnabled;
/*  86:    */   }
/*  87:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.echoserver.ssl.SslSocketFactory
 * JD-Core Version:    0.7.0.1
 */