/*  1:   */ package org.apache.mina.example.gettingstarted.timeserver;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.net.InetSocketAddress;
/*  5:   */ import java.nio.charset.Charset;
/*  6:   */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*  7:   */ import org.apache.mina.core.service.IoAcceptor;
/*  8:   */ import org.apache.mina.core.session.IdleStatus;
/*  9:   */ import org.apache.mina.core.session.IoSessionConfig;
/* 10:   */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/* 11:   */ import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
/* 12:   */ import org.apache.mina.filter.logging.LoggingFilter;
/* 13:   */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
/* 14:   */ 
/* 15:   */ public class MinaTimeServer
/* 16:   */ {
/* 17:   */   private static final int PORT = 9123;
/* 18:   */   
/* 19:   */   public static void main(String[] args)
/* 20:   */     throws IOException
/* 21:   */   {
/* 22:52 */     IoAcceptor acceptor = new NioSocketAcceptor();
/* 23:   */     
/* 24:   */ 
/* 25:55 */     acceptor.getFilterChain().addLast("logger", new LoggingFilter());
/* 26:56 */     acceptor.getFilterChain().addLast("codec", new ProtocolCodecFilter(new TextLineCodecFactory(Charset.forName("UTF-8"))));
/* 27:   */     
/* 28:   */ 
/* 29:59 */     acceptor.setHandler(new TimeServerHandler());
/* 30:   */     
/* 31:   */ 
/* 32:62 */     acceptor.getSessionConfig().setReadBufferSize(2048);
/* 33:63 */     acceptor.getSessionConfig().setIdleTime(IdleStatus.BOTH_IDLE, 10);
/* 34:   */     
/* 35:   */ 
/* 36:66 */     acceptor.bind(new InetSocketAddress(9123));
/* 37:   */   }
/* 38:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.gettingstarted.timeserver.MinaTimeServer
 * JD-Core Version:    0.7.0.1
 */