/*  1:   */ package org.apache.mina.example.gettingstarted.timeserver;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import java.util.Date;
/*  5:   */ import org.apache.mina.core.service.IoHandlerAdapter;
/*  6:   */ import org.apache.mina.core.session.IdleStatus;
/*  7:   */ import org.apache.mina.core.session.IoSession;
/*  8:   */ 
/*  9:   */ public class TimeServerHandler
/* 10:   */   extends IoHandlerAdapter
/* 11:   */ {
/* 12:   */   public void exceptionCaught(IoSession session, Throwable cause)
/* 13:   */     throws Exception
/* 14:   */   {
/* 15:42 */     cause.printStackTrace();
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void messageReceived(IoSession session, Object message)
/* 19:   */     throws Exception
/* 20:   */   {
/* 21:52 */     String str = message.toString();
/* 22:54 */     if (str.trim().equalsIgnoreCase("quit"))
/* 23:   */     {
/* 24:56 */       session.close(true);
/* 25:57 */       return;
/* 26:   */     }
/* 27:61 */     Date date = new Date();
/* 28:62 */     session.write(date.toString());
/* 29:63 */     System.out.println("Message written...");
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void sessionIdle(IoSession session, IdleStatus status)
/* 33:   */     throws Exception
/* 34:   */   {
/* 35:72 */     System.out.println("IDLE " + session.getIdleCount(status));
/* 36:   */   }
/* 37:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.gettingstarted.timeserver.TimeServerHandler
 * JD-Core Version:    0.7.0.1
 */