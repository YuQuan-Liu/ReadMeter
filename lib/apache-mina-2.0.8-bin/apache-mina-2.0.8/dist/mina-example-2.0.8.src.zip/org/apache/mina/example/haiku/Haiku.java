/*  1:   */ package org.apache.mina.example.haiku;
/*  2:   */ 
/*  3:   */ import java.util.Arrays;
/*  4:   */ 
/*  5:   */ public class Haiku
/*  6:   */ {
/*  7:   */   private final String[] phrases;
/*  8:   */   
/*  9:   */   public Haiku(String... lines)
/* 10:   */   {
/* 11:30 */     this.phrases = lines;
/* 12:31 */     if ((null == lines) || (lines.length != 3)) {
/* 13:32 */       throw new IllegalArgumentException("Must pass in 3 phrases of text");
/* 14:   */     }
/* 15:   */   }
/* 16:   */   
/* 17:   */   public String[] getPhrases()
/* 18:   */   {
/* 19:37 */     return this.phrases;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean equals(Object o)
/* 23:   */   {
/* 24:42 */     if (this == o) {
/* 25:43 */       return true;
/* 26:   */     }
/* 27:44 */     if ((o == null) || (getClass() != o.getClass())) {
/* 28:45 */       return false;
/* 29:   */     }
/* 30:47 */     Haiku haiku = (Haiku)o;
/* 31:   */     
/* 32:49 */     return Arrays.equals(this.phrases, haiku.phrases);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public int hashCode()
/* 36:   */   {
/* 37:54 */     return Arrays.hashCode(this.phrases);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public String toString()
/* 41:   */   {
/* 42:59 */     return Arrays.toString(this.phrases);
/* 43:   */   }
/* 44:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.haiku.Haiku
 * JD-Core Version:    0.7.0.1
 */