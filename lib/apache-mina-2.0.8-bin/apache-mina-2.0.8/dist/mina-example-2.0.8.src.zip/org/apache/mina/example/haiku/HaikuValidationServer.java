/*  1:   */ package org.apache.mina.example.haiku;
/*  2:   */ 
/*  3:   */ import java.net.InetSocketAddress;
/*  4:   */ import java.nio.charset.Charset;
/*  5:   */ import java.util.concurrent.ExecutorService;
/*  6:   */ import java.util.concurrent.Executors;
/*  7:   */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*  8:   */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/*  9:   */ import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
/* 10:   */ import org.apache.mina.filter.executor.ExecutorFilter;
/* 11:   */ import org.apache.mina.transport.socket.SocketAcceptor;
/* 12:   */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
/* 13:   */ 
/* 14:   */ public class HaikuValidationServer
/* 15:   */ {
/* 16:   */   public static void main(String... args)
/* 17:   */     throws Exception
/* 18:   */   {
/* 19:38 */     ExecutorService executor = Executors.newCachedThreadPool();
/* 20:39 */     SocketAcceptor acceptor = new NioSocketAcceptor(Runtime.getRuntime().availableProcessors());
/* 21:   */     
/* 22:   */ 
/* 23:42 */     acceptor.getFilterChain().addLast("executor", new ExecutorFilter(executor));
/* 24:   */     
/* 25:44 */     acceptor.getFilterChain().addLast("to-string", new ProtocolCodecFilter(new TextLineCodecFactory(Charset.forName("US-ASCII"))));
/* 26:   */     
/* 27:   */ 
/* 28:   */ 
/* 29:48 */     acceptor.getFilterChain().addLast("to-haiki", new ToHaikuIoFilter());
/* 30:   */     
/* 31:50 */     acceptor.setHandler(new HaikuValidatorIoHandler());
/* 32:51 */     acceptor.bind(new InetSocketAddress(42458));
/* 33:   */   }
/* 34:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.haiku.HaikuValidationServer
 * JD-Core Version:    0.7.0.1
 */