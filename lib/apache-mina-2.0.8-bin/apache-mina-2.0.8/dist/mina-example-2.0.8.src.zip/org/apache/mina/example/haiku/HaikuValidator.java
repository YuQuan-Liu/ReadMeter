/*  1:   */ package org.apache.mina.example.haiku;
/*  2:   */ 
/*  3:   */ public class HaikuValidator
/*  4:   */ {
/*  5:25 */   private static final int[] SYLLABLE_COUNTS = { 5, 7, 5 };
/*  6:   */   
/*  7:   */   public void validate(Haiku haiku)
/*  8:   */     throws InvalidHaikuException
/*  9:   */   {
/* 10:28 */     String[] phrases = haiku.getPhrases();
/* 11:30 */     for (int i = 0; i < phrases.length; i++)
/* 12:   */     {
/* 13:31 */       String phrase = phrases[i];
/* 14:32 */       int count = PhraseUtilities.countSyllablesInPhrase(phrase);
/* 15:34 */       if (count != SYLLABLE_COUNTS[i]) {
/* 16:35 */         throw new InvalidHaikuException(i + 1, phrase, count, SYLLABLE_COUNTS[i]);
/* 17:   */       }
/* 18:   */     }
/* 19:   */   }
/* 20:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.haiku.HaikuValidator
 * JD-Core Version:    0.7.0.1
 */