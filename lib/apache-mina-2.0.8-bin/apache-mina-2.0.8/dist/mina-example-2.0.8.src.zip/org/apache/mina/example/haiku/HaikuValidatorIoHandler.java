/*  1:   */ package org.apache.mina.example.haiku;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.service.IoHandlerAdapter;
/*  4:   */ import org.apache.mina.core.session.IoSession;
/*  5:   */ 
/*  6:   */ public class HaikuValidatorIoHandler
/*  7:   */   extends IoHandlerAdapter
/*  8:   */ {
/*  9:30 */   private final HaikuValidator validator = new HaikuValidator();
/* 10:   */   
/* 11:   */   public void messageReceived(IoSession session, Object message)
/* 12:   */     throws Exception
/* 13:   */   {
/* 14:35 */     Haiku haiku = (Haiku)message;
/* 15:   */     try
/* 16:   */     {
/* 17:38 */       this.validator.validate(haiku);
/* 18:39 */       session.write("HAIKU!");
/* 19:   */     }
/* 20:   */     catch (InvalidHaikuException e)
/* 21:   */     {
/* 22:41 */       session.write("NOT A HAIKU: " + e.getMessage());
/* 23:   */     }
/* 24:   */   }
/* 25:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.haiku.HaikuValidatorIoHandler
 * JD-Core Version:    0.7.0.1
 */