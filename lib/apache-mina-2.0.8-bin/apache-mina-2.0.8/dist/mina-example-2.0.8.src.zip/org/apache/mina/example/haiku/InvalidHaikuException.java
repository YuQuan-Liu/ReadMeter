/*  1:   */ package org.apache.mina.example.haiku;
/*  2:   */ 
/*  3:   */ public class InvalidHaikuException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 34877739006797894L;
/*  7:   */   private final int position;
/*  8:   */   private final String phrase;
/*  9:   */   private final int syllableCount;
/* 10:   */   private final int expectedSyllableCount;
/* 11:   */   
/* 12:   */   public InvalidHaikuException(int position, String phrase, int syllableCount, int expectedSyllableCount)
/* 13:   */   {
/* 14:37 */     super("phrase " + position + ", '" + phrase + "' had " + syllableCount + " syllables, not " + expectedSyllableCount);
/* 15:   */     
/* 16:   */ 
/* 17:40 */     this.position = position;
/* 18:41 */     this.phrase = phrase;
/* 19:42 */     this.syllableCount = syllableCount;
/* 20:43 */     this.expectedSyllableCount = expectedSyllableCount;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public int getExpectedSyllableCount()
/* 24:   */   {
/* 25:47 */     return this.expectedSyllableCount;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String getPhrase()
/* 29:   */   {
/* 30:51 */     return this.phrase;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public int getSyllableCount()
/* 34:   */   {
/* 35:55 */     return this.syllableCount;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public int getPhrasePosition()
/* 39:   */   {
/* 40:59 */     return this.position;
/* 41:   */   }
/* 42:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.haiku.InvalidHaikuException
 * JD-Core Version:    0.7.0.1
 */