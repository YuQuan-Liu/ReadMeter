/*  1:   */ package org.apache.mina.example.haiku;
/*  2:   */ 
/*  3:   */ public class PhraseUtilities
/*  4:   */ {
/*  5:   */   static int countSyllablesInPhrase(String phrase)
/*  6:   */   {
/*  7:26 */     int syllables = 0;
/*  8:28 */     for (String word : phrase.split("[^\\w-]+")) {
/*  9:29 */       if (word.length() > 0) {
/* 10:30 */         syllables += countSyllablesInWord(word.toLowerCase());
/* 11:   */       }
/* 12:   */     }
/* 13:34 */     return syllables;
/* 14:   */   }
/* 15:   */   
/* 16:   */   static int countSyllablesInWord(String word)
/* 17:   */   {
/* 18:38 */     char[] chars = word.toCharArray();
/* 19:39 */     int syllables = 0;
/* 20:40 */     boolean lastWasVowel = false;
/* 21:42 */     for (int i = 0; i < chars.length; i++)
/* 22:   */     {
/* 23:43 */       char c = chars[i];
/* 24:44 */       if (isVowel(c))
/* 25:   */       {
/* 26:45 */         if ((!lastWasVowel) || ((i > 0) && (isE(chars, i - 1)) && (isO(chars, i))))
/* 27:   */         {
/* 28:47 */           syllables++;
/* 29:48 */           lastWasVowel = true;
/* 30:   */         }
/* 31:   */       }
/* 32:   */       else {
/* 33:51 */         lastWasVowel = false;
/* 34:   */       }
/* 35:   */     }
/* 36:55 */     if ((word.endsWith("oned")) || (word.endsWith("ne")) || (word.endsWith("ide")) || (word.endsWith("ve")) || (word.endsWith("fe")) || (word.endsWith("nes")) || (word.endsWith("mes"))) {
/* 37:59 */       syllables--;
/* 38:   */     }
/* 39:62 */     return syllables;
/* 40:   */   }
/* 41:   */   
/* 42:   */   static boolean isE(char[] chars, int position)
/* 43:   */   {
/* 44:66 */     return isCharacter(chars, position, 'e');
/* 45:   */   }
/* 46:   */   
/* 47:   */   static boolean isCharacter(char[] chars, int position, char c)
/* 48:   */   {
/* 49:70 */     return chars[position] == c;
/* 50:   */   }
/* 51:   */   
/* 52:   */   static boolean isO(char[] chars, int position)
/* 53:   */   {
/* 54:74 */     return isCharacter(chars, position, 'o');
/* 55:   */   }
/* 56:   */   
/* 57:   */   static boolean isVowel(char c)
/* 58:   */   {
/* 59:78 */     return (c == 'a') || (c == 'e') || (c == 'i') || (c == 'o') || (c == 'u') || (c == 'y');
/* 60:   */   }
/* 61:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.haiku.PhraseUtilities
 * JD-Core Version:    0.7.0.1
 */