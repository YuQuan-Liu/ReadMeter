/*  1:   */ package org.apache.mina.example.haiku;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ import org.apache.mina.core.filterchain.IoFilter.NextFilter;
/*  6:   */ import org.apache.mina.core.filterchain.IoFilterAdapter;
/*  7:   */ import org.apache.mina.core.session.IoSession;
/*  8:   */ 
/*  9:   */ public class ToHaikuIoFilter
/* 10:   */   extends IoFilterAdapter
/* 11:   */ {
/* 12:   */   public void messageReceived(IoFilter.NextFilter nextFilter, IoSession session, Object message)
/* 13:   */     throws Exception
/* 14:   */   {
/* 15:36 */     List<String> phrases = (List)session.getAttribute("phrases");
/* 16:38 */     if (null == phrases)
/* 17:   */     {
/* 18:39 */       phrases = new ArrayList();
/* 19:40 */       session.setAttribute("phrases", phrases);
/* 20:   */     }
/* 21:43 */     phrases.add((String)message);
/* 22:45 */     if (phrases.size() == 3)
/* 23:   */     {
/* 24:46 */       session.removeAttribute("phrases");
/* 25:   */       
/* 26:48 */       super.messageReceived(nextFilter, session, new Haiku((String[])phrases.toArray(new String[3])));
/* 27:   */     }
/* 28:   */   }
/* 29:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.haiku.ToHaikuIoFilter
 * JD-Core Version:    0.7.0.1
 */