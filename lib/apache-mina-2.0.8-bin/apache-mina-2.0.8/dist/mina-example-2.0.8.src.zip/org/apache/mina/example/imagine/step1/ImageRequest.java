/*  1:   */ package org.apache.mina.example.imagine.step1;
/*  2:   */ 
/*  3:   */ public class ImageRequest
/*  4:   */ {
/*  5:   */   private int width;
/*  6:   */   private int height;
/*  7:   */   private int numberOfCharacters;
/*  8:   */   
/*  9:   */   public ImageRequest(int width, int height, int numberOfCharacters)
/* 10:   */   {
/* 11:35 */     this.width = width;
/* 12:36 */     this.height = height;
/* 13:37 */     this.numberOfCharacters = numberOfCharacters;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getWidth()
/* 17:   */   {
/* 18:41 */     return this.width;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public int getHeight()
/* 22:   */   {
/* 23:45 */     return this.height;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public int getNumberOfCharacters()
/* 27:   */   {
/* 28:49 */     return this.numberOfCharacters;
/* 29:   */   }
/* 30:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.ImageRequest
 * JD-Core Version:    0.7.0.1
 */