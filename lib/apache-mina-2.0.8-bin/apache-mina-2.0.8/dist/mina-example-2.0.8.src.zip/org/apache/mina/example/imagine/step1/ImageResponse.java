/*  1:   */ package org.apache.mina.example.imagine.step1;
/*  2:   */ 
/*  3:   */ import java.awt.image.BufferedImage;
/*  4:   */ 
/*  5:   */ public class ImageResponse
/*  6:   */ {
/*  7:   */   private BufferedImage image1;
/*  8:   */   private BufferedImage image2;
/*  9:   */   
/* 10:   */   public ImageResponse(BufferedImage image1, BufferedImage image2)
/* 11:   */   {
/* 12:36 */     this.image1 = image1;
/* 13:37 */     this.image2 = image2;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public BufferedImage getImage1()
/* 17:   */   {
/* 18:41 */     return this.image1;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public BufferedImage getImage2()
/* 22:   */   {
/* 23:45 */     return this.image2;
/* 24:   */   }
/* 25:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.ImageResponse
 * JD-Core Version:    0.7.0.1
 */