/*   1:    */ package org.apache.mina.example.imagine.step1.client;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.awt.Container;
/*   6:    */ import java.awt.Dimension;
/*   7:    */ import java.awt.EventQueue;
/*   8:    */ import java.awt.GridBagConstraints;
/*   9:    */ import java.awt.GridBagLayout;
/*  10:    */ import java.awt.Insets;
/*  11:    */ import java.awt.Rectangle;
/*  12:    */ import java.awt.event.ActionEvent;
/*  13:    */ import java.awt.event.ActionListener;
/*  14:    */ import java.awt.image.BufferedImage;
/*  15:    */ import javax.swing.JButton;
/*  16:    */ import javax.swing.JCheckBox;
/*  17:    */ import javax.swing.JFrame;
/*  18:    */ import javax.swing.JLabel;
/*  19:    */ import javax.swing.JOptionPane;
/*  20:    */ import javax.swing.JSpinner;
/*  21:    */ import javax.swing.JTextField;
/*  22:    */ import javax.swing.SpinnerNumberModel;
/*  23:    */ import javax.swing.UIManager;
/*  24:    */ import org.apache.mina.example.imagine.step1.ImageRequest;
/*  25:    */ 
/*  26:    */ public class GraphicalCharGenClient
/*  27:    */   extends JFrame
/*  28:    */   implements ImageListener
/*  29:    */ {
/*  30:    */   private static final long serialVersionUID = 1L;
/*  31:    */   public static final int PORT = 33789;
/*  32:    */   public static final String HOST = "localhost";
/*  33:    */   private JTextField jTextFieldHost;
/*  34:    */   private JButton jButtonConnect;
/*  35:    */   private JSpinner jSpinnerWidth;
/*  36:    */   private JSpinner jSpinnerChars;
/*  37:    */   private JCheckBox checkBoxContinuous;
/*  38:    */   private JTextField jTextFieldPort;
/*  39:    */   private JButton jButtonDisconnect;
/*  40:    */   private JSpinner jSpinnerHeight;
/*  41:    */   private JButton jButtonSendRequest;
/*  42:    */   private ImagePanel imagePanel1;
/*  43:    */   
/*  44:    */   public GraphicalCharGenClient()
/*  45:    */   {
/*  46: 61 */     initComponents();
/*  47: 62 */     this.jSpinnerHeight.setModel(this.spinnerHeightModel);
/*  48: 63 */     this.jSpinnerWidth.setModel(this.spinnerWidthModel);
/*  49: 64 */     this.jSpinnerChars.setModel(this.spinnerCharsModel);
/*  50: 65 */     this.jTextFieldHost.setText("localhost");
/*  51: 66 */     this.jTextFieldPort.setText(String.valueOf(33789));
/*  52: 67 */     setTitle("");
/*  53:    */   }
/*  54:    */   
/*  55:    */   private void jButtonConnectActionPerformed()
/*  56:    */   {
/*  57:    */     try
/*  58:    */     {
/*  59: 72 */       setTitle("connecting...");
/*  60: 73 */       String host = this.jTextFieldHost.getText();
/*  61: 74 */       int port = Integer.valueOf(this.jTextFieldPort.getText()).intValue();
/*  62: 75 */       if (this.imageClient != null) {
/*  63: 76 */         this.imageClient.disconnect();
/*  64:    */       }
/*  65: 78 */       this.imageClient = new ImageClient(host, port, this);
/*  66: 79 */       this.imageClient.connect();
/*  67: 80 */       this.jButtonConnect.setEnabled(!this.imageClient.isConnected());
/*  68:    */     }
/*  69:    */     catch (NumberFormatException e)
/*  70:    */     {
/*  71: 82 */       onException(e);
/*  72:    */     }
/*  73:    */     catch (IllegalArgumentException e)
/*  74:    */     {
/*  75: 84 */       onException(e);
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:    */   private void jButtonDisconnectActionPerformed()
/*  80:    */   {
/*  81: 89 */     setTitle("disconnecting");
/*  82: 90 */     this.imageClient.disconnect();
/*  83:    */   }
/*  84:    */   
/*  85:    */   private void jButtonSendRequestActionPerformed()
/*  86:    */   {
/*  87: 94 */     sendRequest();
/*  88:    */   }
/*  89:    */   
/*  90:    */   private void sendRequest()
/*  91:    */   {
/*  92: 98 */     int chars = this.spinnerCharsModel.getNumber().intValue();
/*  93: 99 */     int height = this.spinnerHeightModel.getNumber().intValue();
/*  94:100 */     int width = this.spinnerWidthModel.getNumber().intValue();
/*  95:101 */     this.imageClient.sendRequest(new ImageRequest(width, height, chars));
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void onImages(BufferedImage image1, BufferedImage image2)
/*  99:    */   {
/* 100:105 */     if (this.checkBoxContinuous.isSelected()) {
/* 101:107 */       sendRequest();
/* 102:    */     }
/* 103:109 */     this.imagePanel1.setImages(image1, image2);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void onException(Throwable throwable)
/* 107:    */   {
/* 108:113 */     Throwable cause = throwable;
/* 109:114 */     while (cause.getCause() != null) {
/* 110:115 */       cause = cause.getCause();
/* 111:    */     }
/* 112:117 */     JOptionPane.showMessageDialog(this, cause.getMessage(), throwable.getMessage(), 0);
/* 113:    */     
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:122 */     setTitle("");
/* 118:123 */     this.jButtonConnect.setEnabled(!this.imageClient.isConnected());
/* 119:124 */     this.jButtonDisconnect.setEnabled(this.imageClient.isConnected());
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void sessionOpened()
/* 123:    */   {
/* 124:128 */     this.jButtonDisconnect.setEnabled(true);
/* 125:129 */     this.jButtonSendRequest.setEnabled(true);
/* 126:130 */     this.jButtonConnect.setEnabled(false);
/* 127:131 */     setTitle("connected");
/* 128:    */   }
/* 129:    */   
/* 130:    */   public void sessionClosed()
/* 131:    */   {
/* 132:135 */     this.jButtonDisconnect.setEnabled(false);
/* 133:136 */     this.jButtonSendRequest.setEnabled(false);
/* 134:137 */     this.jButtonConnect.setEnabled(true);
/* 135:138 */     setTitle("not connected");
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void setTitle(String title)
/* 139:    */   {
/* 140:143 */     super.setTitle("MINA - Chargen client - " + title);
/* 141:    */   }
/* 142:    */   
/* 143:    */   private void initComponents()
/* 144:    */   {
/* 145:148 */     JLabel jLabel1 = new JLabel();
/* 146:149 */     this.jTextFieldHost = new JTextField();
/* 147:150 */     this.jButtonConnect = new JButton();
/* 148:151 */     JLabel jLabel3 = new JLabel();
/* 149:152 */     this.jSpinnerWidth = new JSpinner();
/* 150:153 */     JLabel label5 = new JLabel();
/* 151:154 */     this.jSpinnerChars = new JSpinner();
/* 152:155 */     this.checkBoxContinuous = new JCheckBox();
/* 153:156 */     JLabel jLabel2 = new JLabel();
/* 154:157 */     this.jTextFieldPort = new JTextField();
/* 155:158 */     this.jButtonDisconnect = new JButton();
/* 156:159 */     JLabel jLabel4 = new JLabel();
/* 157:160 */     this.jSpinnerHeight = new JSpinner();
/* 158:161 */     this.jButtonSendRequest = new JButton();
/* 159:162 */     this.imagePanel1 = new ImagePanel();
/* 160:    */     
/* 161:    */ 
/* 162:165 */     setDefaultCloseOperation(3);
/* 163:166 */     setMinimumSize(new Dimension(700, 300));
/* 164:167 */     setPreferredSize(new Dimension(740, 600));
/* 165:168 */     Container contentPane = getContentPane();
/* 166:169 */     contentPane.setLayout(new GridBagLayout());
/* 167:170 */     ((GridBagLayout)contentPane.getLayout()).columnWidths = new int[] { 36, 167, 99, 41, 66, 75, 57, 96, 0, 0 };
/* 168:171 */     ((GridBagLayout)contentPane.getLayout()).rowHeights = new int[] { 10, 31, 31, 256, 0 };
/* 169:172 */     ((GridBagLayout)contentPane.getLayout()).columnWeights = new double[] { 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 0.0001D };
/* 170:173 */     ((GridBagLayout)contentPane.getLayout()).rowWeights = new double[] { 0.0D, 0.0D, 0.0D, 1.0D, 0.0001D };
/* 171:    */     
/* 172:    */ 
/* 173:176 */     jLabel1.setText("Host");
/* 174:177 */     contentPane.add(jLabel1, new GridBagConstraints(0, 1, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 5, 5, 5), 0, 0));
/* 175:    */     
/* 176:    */ 
/* 177:180 */     contentPane.add(this.jTextFieldHost, new GridBagConstraints(1, 1, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 5, 5, 10), 0, 0));
/* 178:    */     
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:185 */     this.jButtonConnect.setText("Connect");
/* 183:186 */     this.jButtonConnect.addActionListener(new ActionListener()
/* 184:    */     {
/* 185:    */       public void actionPerformed(ActionEvent e)
/* 186:    */       {
/* 187:188 */         GraphicalCharGenClient.this.jButtonConnectActionPerformed();
/* 188:    */       }
/* 189:190 */     });
/* 190:191 */     contentPane.add(this.jButtonConnect, new GridBagConstraints(2, 1, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 5, 5, 10), 0, 0));
/* 191:    */     
/* 192:    */ 
/* 193:    */ 
/* 194:    */ 
/* 195:196 */     jLabel3.setText("Width");
/* 196:197 */     contentPane.add(jLabel3, new GridBagConstraints(3, 1, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 0, 5, 5), 0, 0));
/* 197:    */     
/* 198:    */ 
/* 199:200 */     contentPane.add(this.jSpinnerWidth, new GridBagConstraints(4, 1, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 5, 5, 10), 0, 0));
/* 200:    */     
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:205 */     label5.setText("characters");
/* 205:206 */     contentPane.add(label5, new GridBagConstraints(5, 1, 1, 1, 0.0D, 0.0D, 13, 3, new Insets(0, 0, 5, 5), 0, 0));
/* 206:    */     
/* 207:    */ 
/* 208:209 */     contentPane.add(this.jSpinnerChars, new GridBagConstraints(6, 1, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 0, 5, 10), 0, 0));
/* 209:    */     
/* 210:    */ 
/* 211:    */ 
/* 212:    */ 
/* 213:214 */     this.checkBoxContinuous.setText("continuous");
/* 214:215 */     contentPane.add(this.checkBoxContinuous, new GridBagConstraints(7, 1, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 5, 5, 10), 0, 0));
/* 215:    */     
/* 216:    */ 
/* 217:    */ 
/* 218:    */ 
/* 219:220 */     jLabel2.setText("Port");
/* 220:221 */     contentPane.add(jLabel2, new GridBagConstraints(0, 2, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 5, 5, 5), 0, 0));
/* 221:    */     
/* 222:    */ 
/* 223:224 */     contentPane.add(this.jTextFieldPort, new GridBagConstraints(1, 2, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 5, 5, 10), 0, 0));
/* 224:    */     
/* 225:    */ 
/* 226:    */ 
/* 227:    */ 
/* 228:229 */     this.jButtonDisconnect.setText("Disconnect");
/* 229:230 */     this.jButtonDisconnect.setEnabled(false);
/* 230:231 */     this.jButtonDisconnect.addActionListener(new ActionListener()
/* 231:    */     {
/* 232:    */       public void actionPerformed(ActionEvent e)
/* 233:    */       {
/* 234:233 */         GraphicalCharGenClient.this.jButtonDisconnectActionPerformed();
/* 235:    */       }
/* 236:235 */     });
/* 237:236 */     contentPane.add(this.jButtonDisconnect, new GridBagConstraints(2, 2, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 5, 5, 10), 0, 0));
/* 238:    */     
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:241 */     jLabel4.setText("Height");
/* 243:242 */     contentPane.add(jLabel4, new GridBagConstraints(3, 2, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 0, 5, 5), 0, 0));
/* 244:    */     
/* 245:    */ 
/* 246:245 */     contentPane.add(this.jSpinnerHeight, new GridBagConstraints(4, 2, 1, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 5, 5, 10), 0, 0));
/* 247:    */     
/* 248:    */ 
/* 249:    */ 
/* 250:    */ 
/* 251:250 */     this.jButtonSendRequest.setText("Send Request");
/* 252:251 */     this.jButtonSendRequest.setEnabled(false);
/* 253:252 */     this.jButtonSendRequest.addActionListener(new ActionListener()
/* 254:    */     {
/* 255:    */       public void actionPerformed(ActionEvent e)
/* 256:    */       {
/* 257:254 */         GraphicalCharGenClient.this.jButtonSendRequestActionPerformed();
/* 258:    */       }
/* 259:256 */     });
/* 260:257 */     contentPane.add(this.jButtonSendRequest, new GridBagConstraints(5, 2, 2, 1, 0.0D, 0.0D, 10, 1, new Insets(0, 5, 5, 10), 0, 0));
/* 261:    */     
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:263 */     this.imagePanel1.setBackground(new Color(51, 153, 255));
/* 267:264 */     this.imagePanel1.setPreferredSize(new Dimension(500, 500));
/* 268:    */     
/* 269:    */ 
/* 270:267 */     Dimension preferredSize = new Dimension();
/* 271:268 */     for (int i = 0; i < this.imagePanel1.getComponentCount(); i++)
/* 272:    */     {
/* 273:269 */       Rectangle bounds = this.imagePanel1.getComponent(i).getBounds();
/* 274:270 */       preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
/* 275:271 */       preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
/* 276:    */     }
/* 277:273 */     Insets insets = this.imagePanel1.getInsets();
/* 278:274 */     preferredSize.width += insets.right;
/* 279:275 */     preferredSize.height += insets.bottom;
/* 280:276 */     this.imagePanel1.setMinimumSize(preferredSize);
/* 281:277 */     this.imagePanel1.setPreferredSize(preferredSize);
/* 282:    */     
/* 283:    */ 
/* 284:280 */     contentPane.add(this.imagePanel1, new GridBagConstraints(0, 3, 9, 1, 0.0D, 0.0D, 10, 1, new Insets(8, 5, 8, 5), 0, 0));
/* 285:    */     
/* 286:    */ 
/* 287:283 */     pack();
/* 288:284 */     setLocationRelativeTo(getOwner());
/* 289:    */   }
/* 290:    */   
/* 291:    */   public static void main(String[] args)
/* 292:    */   {
/* 293:    */     try
/* 294:    */     {
/* 295:292 */       UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/* 296:    */     }
/* 297:    */     catch (Exception e) {}
/* 298:296 */     EventQueue.invokeLater(new Runnable()
/* 299:    */     {
/* 300:    */       public void run()
/* 301:    */       {
/* 302:298 */         new GraphicalCharGenClient().setVisible(true);
/* 303:    */       }
/* 304:    */     });
/* 305:    */   }
/* 306:    */   
/* 307:314 */   private SpinnerNumberModel spinnerHeightModel = new SpinnerNumberModel(100, 50, 600, 25);
/* 308:315 */   private SpinnerNumberModel spinnerWidthModel = new SpinnerNumberModel(200, 50, 1000, 25);
/* 309:316 */   private SpinnerNumberModel spinnerCharsModel = new SpinnerNumberModel(10, 1, 60, 1);
/* 310:318 */   private ImageClient imageClient = new ImageClient("localhost", 33789, this);
/* 311:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.client.GraphicalCharGenClient
 * JD-Core Version:    0.7.0.1
 */