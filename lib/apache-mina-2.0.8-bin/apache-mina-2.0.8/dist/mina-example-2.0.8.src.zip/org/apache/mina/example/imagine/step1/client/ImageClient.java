/*   1:    */ package org.apache.mina.example.imagine.step1.client;
/*   2:    */ 
/*   3:    */ import java.net.InetSocketAddress;
/*   4:    */ import org.apache.mina.core.RuntimeIoException;
/*   5:    */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*   6:    */ import org.apache.mina.core.future.CloseFuture;
/*   7:    */ import org.apache.mina.core.future.ConnectFuture;
/*   8:    */ import org.apache.mina.core.service.IoHandlerAdapter;
/*   9:    */ import org.apache.mina.core.session.IoSession;
/*  10:    */ import org.apache.mina.example.imagine.step1.ImageRequest;
/*  11:    */ import org.apache.mina.example.imagine.step1.ImageResponse;
/*  12:    */ import org.apache.mina.example.imagine.step1.codec.ImageCodecFactory;
/*  13:    */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/*  14:    */ import org.apache.mina.transport.socket.SocketConnector;
/*  15:    */ import org.apache.mina.transport.socket.nio.NioSocketConnector;
/*  16:    */ 
/*  17:    */ public class ImageClient
/*  18:    */   extends IoHandlerAdapter
/*  19:    */ {
/*  20:    */   public static final int CONNECT_TIMEOUT = 3000;
/*  21:    */   private String host;
/*  22:    */   private int port;
/*  23:    */   private SocketConnector connector;
/*  24:    */   private IoSession session;
/*  25:    */   private ImageListener imageListener;
/*  26:    */   
/*  27:    */   public ImageClient(String host, int port, ImageListener imageListener)
/*  28:    */   {
/*  29: 51 */     this.host = host;
/*  30: 52 */     this.port = port;
/*  31: 53 */     this.imageListener = imageListener;
/*  32: 54 */     this.connector = new NioSocketConnector();
/*  33: 55 */     this.connector.getFilterChain().addLast("codec", new ProtocolCodecFilter(new ImageCodecFactory(true)));
/*  34: 56 */     this.connector.setHandler(this);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public boolean isConnected()
/*  38:    */   {
/*  39: 60 */     return (this.session != null) && (this.session.isConnected());
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void connect()
/*  43:    */   {
/*  44: 64 */     ConnectFuture connectFuture = this.connector.connect(new InetSocketAddress(this.host, this.port));
/*  45: 65 */     connectFuture.awaitUninterruptibly(3000L);
/*  46:    */     try
/*  47:    */     {
/*  48: 67 */       this.session = connectFuture.getSession();
/*  49:    */     }
/*  50:    */     catch (RuntimeIoException e)
/*  51:    */     {
/*  52: 70 */       this.imageListener.onException(e);
/*  53:    */     }
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void disconnect()
/*  57:    */   {
/*  58: 75 */     if (this.session != null)
/*  59:    */     {
/*  60: 76 */       this.session.close(true).awaitUninterruptibly(3000L);
/*  61: 77 */       this.session = null;
/*  62:    */     }
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void sessionOpened(IoSession session)
/*  66:    */     throws Exception
/*  67:    */   {
/*  68: 82 */     this.imageListener.sessionOpened();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void sessionClosed(IoSession session)
/*  72:    */     throws Exception
/*  73:    */   {
/*  74: 86 */     this.imageListener.sessionClosed();
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void sendRequest(ImageRequest imageRequest)
/*  78:    */   {
/*  79: 90 */     if (this.session == null) {
/*  80: 92 */       this.imageListener.onException(new Throwable("not connected"));
/*  81:    */     } else {
/*  82: 94 */       this.session.write(imageRequest);
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void messageReceived(IoSession session, Object message)
/*  87:    */     throws Exception
/*  88:    */   {
/*  89: 99 */     ImageResponse response = (ImageResponse)message;
/*  90:100 */     this.imageListener.onImages(response.getImage1(), response.getImage2());
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void exceptionCaught(IoSession session, Throwable cause)
/*  94:    */     throws Exception
/*  95:    */   {
/*  96:104 */     this.imageListener.onException(cause);
/*  97:    */   }
/*  98:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.client.ImageClient
 * JD-Core Version:    0.7.0.1
 */