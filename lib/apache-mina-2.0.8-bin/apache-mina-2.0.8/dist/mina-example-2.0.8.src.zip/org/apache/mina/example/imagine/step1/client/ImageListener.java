package org.apache.mina.example.imagine.step1.client;

import java.awt.image.BufferedImage;

public abstract interface ImageListener
{
  public abstract void onImages(BufferedImage paramBufferedImage1, BufferedImage paramBufferedImage2);
  
  public abstract void onException(Throwable paramThrowable);
  
  public abstract void sessionOpened();
  
  public abstract void sessionClosed();
}


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.client.ImageListener
 * JD-Core Version:    0.7.0.1
 */