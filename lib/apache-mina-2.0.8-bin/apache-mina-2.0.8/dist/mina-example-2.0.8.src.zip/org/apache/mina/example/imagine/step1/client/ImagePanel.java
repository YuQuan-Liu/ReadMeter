/*  1:   */ package org.apache.mina.example.imagine.step1.client;
/*  2:   */ 
/*  3:   */ import java.awt.Graphics;
/*  4:   */ import java.awt.image.BufferedImage;
/*  5:   */ import javax.swing.JPanel;
/*  6:   */ 
/*  7:   */ public class ImagePanel
/*  8:   */   extends JPanel
/*  9:   */ {
/* 10:   */   private static final long serialVersionUID = 1L;
/* 11:   */   private BufferedImage image1;
/* 12:   */   private BufferedImage image2;
/* 13:   */   
/* 14:   */   public void paintComponent(Graphics g)
/* 15:   */   {
/* 16:41 */     super.paintComponent(g);
/* 17:42 */     if (this.image1 != null)
/* 18:   */     {
/* 19:43 */       g.drawImage(this.image1, 20, 20, null);
/* 20:44 */       if (this.image2 != null) {
/* 21:45 */         g.drawImage(this.image2, 20, this.image1.getHeight() + 80, null);
/* 22:   */       }
/* 23:   */     }
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void setImages(BufferedImage image1, BufferedImage image2)
/* 27:   */   {
/* 28:51 */     this.image1 = image1;
/* 29:52 */     this.image2 = image2;
/* 30:53 */     repaint();
/* 31:   */   }
/* 32:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.client.ImagePanel
 * JD-Core Version:    0.7.0.1
 */