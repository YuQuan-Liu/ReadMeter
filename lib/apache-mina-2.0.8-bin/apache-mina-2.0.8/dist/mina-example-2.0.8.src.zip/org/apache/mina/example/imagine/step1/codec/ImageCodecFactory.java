/*  1:   */ package org.apache.mina.example.imagine.step1.codec;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.session.IoSession;
/*  4:   */ import org.apache.mina.filter.codec.ProtocolCodecFactory;
/*  5:   */ import org.apache.mina.filter.codec.ProtocolDecoder;
/*  6:   */ import org.apache.mina.filter.codec.ProtocolEncoder;
/*  7:   */ 
/*  8:   */ public class ImageCodecFactory
/*  9:   */   implements ProtocolCodecFactory
/* 10:   */ {
/* 11:   */   private ProtocolEncoder encoder;
/* 12:   */   private ProtocolDecoder decoder;
/* 13:   */   
/* 14:   */   public ImageCodecFactory(boolean client)
/* 15:   */   {
/* 16:38 */     if (client)
/* 17:   */     {
/* 18:39 */       this.encoder = new ImageRequestEncoder();
/* 19:40 */       this.decoder = new ImageResponseDecoder();
/* 20:   */     }
/* 21:   */     else
/* 22:   */     {
/* 23:42 */       this.encoder = new ImageResponseEncoder();
/* 24:43 */       this.decoder = new ImageRequestDecoder();
/* 25:   */     }
/* 26:   */   }
/* 27:   */   
/* 28:   */   public ProtocolEncoder getEncoder(IoSession ioSession)
/* 29:   */     throws Exception
/* 30:   */   {
/* 31:48 */     return this.encoder;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public ProtocolDecoder getDecoder(IoSession ioSession)
/* 35:   */     throws Exception
/* 36:   */   {
/* 37:52 */     return this.decoder;
/* 38:   */   }
/* 39:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.codec.ImageCodecFactory
 * JD-Core Version:    0.7.0.1
 */