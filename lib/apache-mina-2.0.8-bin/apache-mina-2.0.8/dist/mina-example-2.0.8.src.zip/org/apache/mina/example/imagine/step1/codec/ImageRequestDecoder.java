/*  1:   */ package org.apache.mina.example.imagine.step1.codec;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  4:   */ import org.apache.mina.core.session.IoSession;
/*  5:   */ import org.apache.mina.example.imagine.step1.ImageRequest;
/*  6:   */ import org.apache.mina.filter.codec.CumulativeProtocolDecoder;
/*  7:   */ import org.apache.mina.filter.codec.ProtocolDecoderOutput;
/*  8:   */ 
/*  9:   */ public class ImageRequestDecoder
/* 10:   */   extends CumulativeProtocolDecoder
/* 11:   */ {
/* 12:   */   protected boolean doDecode(IoSession session, IoBuffer in, ProtocolDecoderOutput out)
/* 13:   */     throws Exception
/* 14:   */   {
/* 15:37 */     if (in.remaining() >= 12)
/* 16:   */     {
/* 17:38 */       int width = in.getInt();
/* 18:39 */       int height = in.getInt();
/* 19:40 */       int numberOfCharachters = in.getInt();
/* 20:41 */       ImageRequest request = new ImageRequest(width, height, numberOfCharachters);
/* 21:42 */       out.write(request);
/* 22:43 */       return true;
/* 23:   */     }
/* 24:45 */     return false;
/* 25:   */   }
/* 26:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.codec.ImageRequestDecoder
 * JD-Core Version:    0.7.0.1
 */