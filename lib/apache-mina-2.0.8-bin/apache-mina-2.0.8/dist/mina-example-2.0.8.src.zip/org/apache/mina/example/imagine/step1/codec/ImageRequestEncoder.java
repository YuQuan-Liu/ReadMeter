/*  1:   */ package org.apache.mina.example.imagine.step1.codec;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  4:   */ import org.apache.mina.core.session.IoSession;
/*  5:   */ import org.apache.mina.example.imagine.step1.ImageRequest;
/*  6:   */ import org.apache.mina.filter.codec.ProtocolEncoder;
/*  7:   */ import org.apache.mina.filter.codec.ProtocolEncoderOutput;
/*  8:   */ 
/*  9:   */ public class ImageRequestEncoder
/* 10:   */   implements ProtocolEncoder
/* 11:   */ {
/* 12:   */   public void encode(IoSession session, Object message, ProtocolEncoderOutput out)
/* 13:   */     throws Exception
/* 14:   */   {
/* 15:37 */     ImageRequest request = (ImageRequest)message;
/* 16:38 */     IoBuffer buffer = IoBuffer.allocate(12, false);
/* 17:39 */     buffer.putInt(request.getWidth());
/* 18:40 */     buffer.putInt(request.getHeight());
/* 19:41 */     buffer.putInt(request.getNumberOfCharacters());
/* 20:42 */     buffer.flip();
/* 21:43 */     out.write(buffer);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void dispose(IoSession session)
/* 25:   */     throws Exception
/* 26:   */   {}
/* 27:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.codec.ImageRequestEncoder
 * JD-Core Version:    0.7.0.1
 */