/*  1:   */ package org.apache.mina.example.imagine.step1.codec;
/*  2:   */ 
/*  3:   */ import java.awt.image.BufferedImage;
/*  4:   */ import java.io.ByteArrayInputStream;
/*  5:   */ import java.io.IOException;
/*  6:   */ import javax.imageio.ImageIO;
/*  7:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  8:   */ import org.apache.mina.core.session.IoSession;
/*  9:   */ import org.apache.mina.example.imagine.step1.ImageResponse;
/* 10:   */ import org.apache.mina.filter.codec.CumulativeProtocolDecoder;
/* 11:   */ import org.apache.mina.filter.codec.ProtocolDecoderOutput;
/* 12:   */ 
/* 13:   */ public class ImageResponseDecoder
/* 14:   */   extends CumulativeProtocolDecoder
/* 15:   */ {
/* 16:41 */   private static final String DECODER_STATE_KEY = ImageResponseDecoder.class.getName() + ".STATE";
/* 17:   */   public static final int MAX_IMAGE_SIZE = 5242880;
/* 18:   */   
/* 19:   */   protected boolean doDecode(IoSession session, IoBuffer in, ProtocolDecoderOutput out)
/* 20:   */     throws Exception
/* 21:   */   {
/* 22:50 */     DecoderState decoderState = (DecoderState)session.getAttribute(DECODER_STATE_KEY);
/* 23:51 */     if (decoderState == null)
/* 24:   */     {
/* 25:52 */       decoderState = new DecoderState(null);
/* 26:53 */       session.setAttribute(DECODER_STATE_KEY, decoderState);
/* 27:   */     }
/* 28:55 */     if (decoderState.image1 == null) {
/* 29:57 */       if (in.prefixedDataAvailable(4, 5242880)) {
/* 30:58 */         decoderState.image1 = readImage(in);
/* 31:   */       } else {
/* 32:61 */         return false;
/* 33:   */       }
/* 34:   */     }
/* 35:64 */     if (decoderState.image1 != null)
/* 36:   */     {
/* 37:66 */       if (in.prefixedDataAvailable(4, 5242880))
/* 38:   */       {
/* 39:67 */         BufferedImage image2 = readImage(in);
/* 40:68 */         ImageResponse imageResponse = new ImageResponse(decoderState.image1, image2);
/* 41:69 */         out.write(imageResponse);
/* 42:70 */         decoderState.image1 = null;
/* 43:71 */         return true;
/* 44:   */       }
/* 45:74 */       return false;
/* 46:   */     }
/* 47:77 */     return false;
/* 48:   */   }
/* 49:   */   
/* 50:   */   private BufferedImage readImage(IoBuffer in)
/* 51:   */     throws IOException
/* 52:   */   {
/* 53:81 */     int length = in.getInt();
/* 54:82 */     byte[] bytes = new byte[length];
/* 55:83 */     in.get(bytes);
/* 56:84 */     ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
/* 57:85 */     return ImageIO.read(bais);
/* 58:   */   }
/* 59:   */   
/* 60:   */   private static class DecoderState
/* 61:   */   {
/* 62:   */     private BufferedImage image1;
/* 63:   */   }
/* 64:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.codec.ImageResponseDecoder
 * JD-Core Version:    0.7.0.1
 */