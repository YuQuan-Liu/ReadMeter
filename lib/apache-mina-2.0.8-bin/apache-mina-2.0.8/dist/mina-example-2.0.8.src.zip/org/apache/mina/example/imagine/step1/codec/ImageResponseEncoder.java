/*  1:   */ package org.apache.mina.example.imagine.step1.codec;
/*  2:   */ 
/*  3:   */ import java.awt.image.BufferedImage;
/*  4:   */ import java.io.ByteArrayOutputStream;
/*  5:   */ import java.io.IOException;
/*  6:   */ import javax.imageio.ImageIO;
/*  7:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  8:   */ import org.apache.mina.core.session.IoSession;
/*  9:   */ import org.apache.mina.example.imagine.step1.ImageResponse;
/* 10:   */ import org.apache.mina.filter.codec.ProtocolEncoderAdapter;
/* 11:   */ import org.apache.mina.filter.codec.ProtocolEncoderOutput;
/* 12:   */ 
/* 13:   */ public class ImageResponseEncoder
/* 14:   */   extends ProtocolEncoderAdapter
/* 15:   */ {
/* 16:   */   public void encode(IoSession session, Object message, ProtocolEncoderOutput out)
/* 17:   */     throws Exception
/* 18:   */   {
/* 19:41 */     ImageResponse imageResponse = (ImageResponse)message;
/* 20:42 */     byte[] bytes1 = getBytes(imageResponse.getImage1());
/* 21:43 */     byte[] bytes2 = getBytes(imageResponse.getImage2());
/* 22:44 */     int capacity = bytes1.length + bytes2.length + 8;
/* 23:45 */     IoBuffer buffer = IoBuffer.allocate(capacity, false);
/* 24:46 */     buffer.putInt(bytes1.length);
/* 25:47 */     buffer.put(bytes1);
/* 26:48 */     buffer.putInt(bytes2.length);
/* 27:49 */     buffer.put(bytes2);
/* 28:50 */     buffer.flip();
/* 29:51 */     out.write(buffer);
/* 30:   */   }
/* 31:   */   
/* 32:   */   private byte[] getBytes(BufferedImage image)
/* 33:   */     throws IOException
/* 34:   */   {
/* 35:55 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 36:56 */     ImageIO.write(image, "PNG", baos);
/* 37:57 */     return baos.toByteArray();
/* 38:   */   }
/* 39:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.codec.ImageResponseEncoder
 * JD-Core Version:    0.7.0.1
 */