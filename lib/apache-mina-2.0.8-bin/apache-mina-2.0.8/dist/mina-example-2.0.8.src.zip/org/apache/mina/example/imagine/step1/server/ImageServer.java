/*  1:   */ package org.apache.mina.example.imagine.step1.server;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.io.PrintStream;
/*  5:   */ import java.net.InetSocketAddress;
/*  6:   */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*  7:   */ import org.apache.mina.example.imagine.step1.codec.ImageCodecFactory;
/*  8:   */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/*  9:   */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
/* 10:   */ 
/* 11:   */ public class ImageServer
/* 12:   */ {
/* 13:   */   public static final int PORT = 33789;
/* 14:   */   
/* 15:   */   public static void main(String[] args)
/* 16:   */     throws IOException
/* 17:   */   {
/* 18:41 */     ImageServerIoHandler handler = new ImageServerIoHandler();
/* 19:   */     
/* 20:   */ 
/* 21:44 */     NioSocketAcceptor acceptor = new NioSocketAcceptor();
/* 22:   */     
/* 23:   */ 
/* 24:   */ 
/* 25:48 */     acceptor.getFilterChain().addLast("protocol", new ProtocolCodecFilter(new ImageCodecFactory(false)));
/* 26:   */     
/* 27:   */ 
/* 28:51 */     acceptor.setHandler(handler);
/* 29:   */     
/* 30:   */ 
/* 31:   */ 
/* 32:55 */     acceptor.bind(new InetSocketAddress(33789));
/* 33:56 */     System.out.println("Step 1 server is listenig at port 33789");
/* 34:   */   }
/* 35:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.server.ImageServer
 * JD-Core Version:    0.7.0.1
 */