/*   1:    */ package org.apache.mina.example.imagine.step1.server;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Font;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import java.awt.image.BufferedImage;
/*   7:    */ import org.apache.mina.core.service.IoHandlerAdapter;
/*   8:    */ import org.apache.mina.core.session.IoSession;
/*   9:    */ import org.apache.mina.example.imagine.step1.ImageRequest;
/*  10:    */ import org.apache.mina.example.imagine.step1.ImageResponse;
/*  11:    */ import org.slf4j.Logger;
/*  12:    */ import org.slf4j.LoggerFactory;
/*  13:    */ 
/*  14:    */ public class ImageServerIoHandler
/*  15:    */   extends IoHandlerAdapter
/*  16:    */ {
/*  17:    */   private static final String characters = "mina rocks abcdefghijklmnopqrstuvwxyz0123456789";
/*  18: 44 */   public static final String INDEX_KEY = ImageServerIoHandler.class.getName() + ".INDEX";
/*  19: 46 */   private static Logger LOGGER = LoggerFactory.getLogger(ImageServerIoHandler.class);
/*  20:    */   
/*  21:    */   public void sessionOpened(IoSession session)
/*  22:    */     throws Exception
/*  23:    */   {
/*  24: 54 */     session.setAttribute(INDEX_KEY, Integer.valueOf(0));
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void exceptionCaught(IoSession session, Throwable cause)
/*  28:    */     throws Exception
/*  29:    */   {
/*  30: 64 */     LOGGER.warn(cause.getMessage(), cause);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void messageReceived(IoSession session, Object message)
/*  34:    */     throws Exception
/*  35:    */   {
/*  36: 73 */     ImageRequest request = (ImageRequest)message;
/*  37: 74 */     String text1 = generateString(session, request.getNumberOfCharacters());
/*  38: 75 */     String text2 = generateString(session, request.getNumberOfCharacters());
/*  39: 76 */     BufferedImage image1 = createImage(request, text1);
/*  40: 77 */     BufferedImage image2 = createImage(request, text2);
/*  41: 78 */     ImageResponse response = new ImageResponse(image1, image2);
/*  42: 79 */     session.write(response);
/*  43:    */   }
/*  44:    */   
/*  45:    */   private BufferedImage createImage(ImageRequest request, String text)
/*  46:    */   {
/*  47: 93 */     BufferedImage image = new BufferedImage(request.getWidth(), request.getHeight(), 13);
/*  48: 94 */     Graphics graphics = image.createGraphics();
/*  49: 95 */     graphics.setColor(Color.YELLOW);
/*  50: 96 */     graphics.fillRect(0, 0, image.getWidth(), image.getHeight());
/*  51: 97 */     Font serif = new Font("serif", 0, 30);
/*  52: 98 */     graphics.setFont(serif);
/*  53: 99 */     graphics.setColor(Color.BLUE);
/*  54:100 */     graphics.drawString(text, 10, 50);
/*  55:101 */     return image;
/*  56:    */   }
/*  57:    */   
/*  58:    */   private String generateString(IoSession session, int length)
/*  59:    */   {
/*  60:117 */     Integer index = (Integer)session.getAttribute(INDEX_KEY);
/*  61:118 */     StringBuffer buffer = new StringBuffer(length);
/*  62:119 */     while (buffer.length() < length)
/*  63:    */     {
/*  64:120 */       buffer.append("mina rocks abcdefghijklmnopqrstuvwxyz0123456789".charAt(index.intValue()));
/*  65:121 */       Integer localInteger1 = index;Integer localInteger2 = index = Integer.valueOf(index.intValue() + 1);
/*  66:122 */       if (index.intValue() >= "mina rocks abcdefghijklmnopqrstuvwxyz0123456789".length()) {
/*  67:123 */         index = Integer.valueOf(0);
/*  68:    */       }
/*  69:    */     }
/*  70:126 */     session.setAttribute(INDEX_KEY, index);
/*  71:127 */     return buffer.toString();
/*  72:    */   }
/*  73:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step1.server.ImageServerIoHandler
 * JD-Core Version:    0.7.0.1
 */