/*  1:   */ package org.apache.mina.example.imagine.step2.server;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.io.PrintStream;
/*  5:   */ import java.net.InetSocketAddress;
/*  6:   */ import java.util.concurrent.Executors;
/*  7:   */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*  8:   */ import org.apache.mina.example.imagine.step1.codec.ImageCodecFactory;
/*  9:   */ import org.apache.mina.example.imagine.step1.server.ImageServerIoHandler;
/* 10:   */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/* 11:   */ import org.apache.mina.filter.executor.ExecutorFilter;
/* 12:   */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
/* 13:   */ 
/* 14:   */ public class ImageServer
/* 15:   */ {
/* 16:   */   public static final int PORT = 33789;
/* 17:   */   
/* 18:   */   public static void main(String[] args)
/* 19:   */     throws IOException
/* 20:   */   {
/* 21:44 */     ImageServerIoHandler handler = new ImageServerIoHandler();
/* 22:   */     
/* 23:   */ 
/* 24:47 */     NioSocketAcceptor acceptor = new NioSocketAcceptor();
/* 25:   */     
/* 26:   */ 
/* 27:   */ 
/* 28:51 */     acceptor.getFilterChain().addLast("protocol", new ProtocolCodecFilter(new ImageCodecFactory(false)));
/* 29:   */     
/* 30:   */ 
/* 31:54 */     DefaultIoFilterChainBuilder filterChainBuilder = acceptor.getFilterChain();
/* 32:   */     
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:59 */     filterChainBuilder.addLast("threadPool", new ExecutorFilter(Executors.newCachedThreadPool()));
/* 37:   */     
/* 38:   */ 
/* 39:62 */     acceptor.setHandler(handler);
/* 40:   */     
/* 41:   */ 
/* 42:   */ 
/* 43:66 */     acceptor.bind(new InetSocketAddress(33789));
/* 44:67 */     System.out.println("Step 2 server is listenig at port 33789");
/* 45:   */   }
/* 46:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step2.server.ImageServer
 * JD-Core Version:    0.7.0.1
 */