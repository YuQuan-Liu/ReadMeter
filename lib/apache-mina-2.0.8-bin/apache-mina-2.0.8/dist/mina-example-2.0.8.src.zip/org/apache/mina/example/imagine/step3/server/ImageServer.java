/*   1:    */ package org.apache.mina.example.imagine.step3.server;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.lang.management.ManagementFactory;
/*   5:    */ import java.net.InetSocketAddress;
/*   6:    */ import java.util.concurrent.Executors;
/*   7:    */ import javax.management.MBeanServer;
/*   8:    */ import javax.management.ObjectName;
/*   9:    */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*  10:    */ import org.apache.mina.example.imagine.step1.codec.ImageCodecFactory;
/*  11:    */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/*  12:    */ import org.apache.mina.filter.executor.ExecutorFilter;
/*  13:    */ import org.apache.mina.integration.jmx.IoFilterMBean;
/*  14:    */ import org.apache.mina.integration.jmx.IoServiceMBean;
/*  15:    */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
/*  16:    */ 
/*  17:    */ public class ImageServer
/*  18:    */ {
/*  19:    */   public static final int PORT = 33789;
/*  20:    */   
/*  21:    */   public static void main(String[] args)
/*  22:    */     throws Exception
/*  23:    */   {
/*  24: 49 */     MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*  25:    */     
/*  26:    */ 
/*  27:    */ 
/*  28:    */ 
/*  29: 54 */     ImageServerIoHandler handler = new ImageServerIoHandler(mBeanServer);
/*  30:    */     
/*  31:    */ 
/*  32: 57 */     NioSocketAcceptor acceptor = new NioSocketAcceptor();
/*  33:    */     
/*  34:    */ 
/*  35:    */ 
/*  36: 61 */     IoServiceMBean acceptorMBean = new IoServiceMBean(acceptor);
/*  37:    */     
/*  38:    */ 
/*  39: 64 */     ObjectName acceptorName = new ObjectName(acceptor.getClass().getPackage().getName() + ":type=acceptor,name=" + acceptor.getClass().getSimpleName());
/*  40:    */     
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44: 69 */     mBeanServer.registerMBean(acceptorMBean, acceptorName);
/*  45:    */     
/*  46:    */ 
/*  47:    */ 
/*  48: 73 */     ProtocolCodecFilter protocolFilter = new ProtocolCodecFilter(new ImageCodecFactory(false));
/*  49:    */     
/*  50:    */ 
/*  51:    */ 
/*  52: 77 */     IoFilterMBean protocolFilterMBean = new IoFilterMBean(protocolFilter);
/*  53:    */     
/*  54:    */ 
/*  55: 80 */     ObjectName protocolFilterName = new ObjectName(protocolFilter.getClass().getPackage().getName() + ":type=protocolfilter,name=" + protocolFilter.getClass().getSimpleName());
/*  56:    */     
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60: 85 */     mBeanServer.registerMBean(protocolFilterMBean, protocolFilterName);
/*  61:    */     
/*  62:    */ 
/*  63: 88 */     acceptor.getFilterChain().addLast("protocol", protocolFilter);
/*  64:    */     
/*  65:    */ 
/*  66: 91 */     DefaultIoFilterChainBuilder filterChainBuilder = acceptor.getFilterChain();
/*  67:    */     
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71: 96 */     filterChainBuilder.addLast("threadPool", new ExecutorFilter(Executors.newCachedThreadPool()));
/*  72:    */     
/*  73:    */ 
/*  74: 99 */     acceptor.setHandler(handler);
/*  75:    */     
/*  76:    */ 
/*  77:    */ 
/*  78:103 */     acceptor.bind(new InetSocketAddress(33789));
/*  79:104 */     System.out.println("Step 3 server is listenig at port 33789");
/*  80:    */   }
/*  81:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step3.server.ImageServer
 * JD-Core Version:    0.7.0.1
 */