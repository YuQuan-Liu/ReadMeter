/*   1:    */ package org.apache.mina.example.imagine.step3.server;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Font;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import java.awt.image.BufferedImage;
/*   7:    */ import javax.management.MBeanServer;
/*   8:    */ import javax.management.ObjectName;
/*   9:    */ import org.apache.mina.core.service.IoHandlerAdapter;
/*  10:    */ import org.apache.mina.core.session.IoSession;
/*  11:    */ import org.apache.mina.example.imagine.step1.ImageRequest;
/*  12:    */ import org.apache.mina.example.imagine.step1.ImageResponse;
/*  13:    */ import org.apache.mina.integration.jmx.IoSessionMBean;
/*  14:    */ import org.slf4j.Logger;
/*  15:    */ import org.slf4j.LoggerFactory;
/*  16:    */ 
/*  17:    */ public class ImageServerIoHandler
/*  18:    */   extends IoHandlerAdapter
/*  19:    */ {
/*  20:    */   private static final String characters = "mina rocks abcdefghijklmnopqrstuvwxyz0123456789";
/*  21: 48 */   public static final String INDEX_KEY = ImageServerIoHandler.class.getName() + ".INDEX";
/*  22: 50 */   private static Logger LOGGER = LoggerFactory.getLogger(ImageServerIoHandler.class);
/*  23:    */   private MBeanServer mBeanServer;
/*  24:    */   
/*  25:    */   public ImageServerIoHandler(MBeanServer mBeanServer)
/*  26:    */   {
/*  27: 63 */     this.mBeanServer = mBeanServer;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void sessionCreated(IoSession session)
/*  31:    */     throws Exception
/*  32:    */   {
/*  33: 76 */     IoSessionMBean sessionMBean = new IoSessionMBean(session);
/*  34:    */     
/*  35:    */ 
/*  36: 79 */     ObjectName sessionName = new ObjectName(session.getClass().getPackage().getName() + ":type=session,name=" + session.getClass().getSimpleName() + "-" + session.getId());
/*  37:    */     
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41: 84 */     this.mBeanServer.registerMBean(sessionMBean, sessionName);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void sessionOpened(IoSession session)
/*  45:    */     throws Exception
/*  46:    */   {
/*  47: 96 */     session.setAttribute(INDEX_KEY, Integer.valueOf(0));
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void exceptionCaught(IoSession session, Throwable cause)
/*  51:    */     throws Exception
/*  52:    */   {
/*  53:106 */     LOGGER.warn(cause.getMessage(), cause);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void messageReceived(IoSession session, Object message)
/*  57:    */     throws Exception
/*  58:    */   {
/*  59:115 */     ImageRequest request = (ImageRequest)message;
/*  60:116 */     String text1 = generateString(session, request.getNumberOfCharacters());
/*  61:117 */     String text2 = generateString(session, request.getNumberOfCharacters());
/*  62:118 */     BufferedImage image1 = createImage(request, text1);
/*  63:119 */     BufferedImage image2 = createImage(request, text2);
/*  64:120 */     ImageResponse response = new ImageResponse(image1, image2);
/*  65:121 */     session.write(response);
/*  66:    */   }
/*  67:    */   
/*  68:    */   private BufferedImage createImage(ImageRequest request, String text)
/*  69:    */   {
/*  70:135 */     BufferedImage image = new BufferedImage(request.getWidth(), request.getHeight(), 13);
/*  71:136 */     Graphics graphics = image.createGraphics();
/*  72:137 */     graphics.setColor(Color.YELLOW);
/*  73:138 */     graphics.fillRect(0, 0, image.getWidth(), image.getHeight());
/*  74:139 */     Font serif = new Font("serif", 0, 30);
/*  75:140 */     graphics.setFont(serif);
/*  76:141 */     graphics.setColor(Color.BLUE);
/*  77:142 */     graphics.drawString(text, 10, 50);
/*  78:143 */     return image;
/*  79:    */   }
/*  80:    */   
/*  81:    */   private String generateString(IoSession session, int length)
/*  82:    */   {
/*  83:159 */     Integer index = (Integer)session.getAttribute(INDEX_KEY);
/*  84:160 */     StringBuilder buffer = new StringBuilder(length);
/*  85:161 */     while (buffer.length() < length)
/*  86:    */     {
/*  87:162 */       buffer.append("mina rocks abcdefghijklmnopqrstuvwxyz0123456789".charAt(index.intValue()));
/*  88:163 */       Integer localInteger1 = index;Integer localInteger2 = index = Integer.valueOf(index.intValue() + 1);
/*  89:164 */       if (index.intValue() >= "mina rocks abcdefghijklmnopqrstuvwxyz0123456789".length()) {
/*  90:165 */         index = Integer.valueOf(0);
/*  91:    */       }
/*  92:    */     }
/*  93:168 */     session.setAttribute(INDEX_KEY, index);
/*  94:169 */     return buffer.toString();
/*  95:    */   }
/*  96:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.imagine.step3.server.ImageServerIoHandler
 * JD-Core Version:    0.7.0.1
 */