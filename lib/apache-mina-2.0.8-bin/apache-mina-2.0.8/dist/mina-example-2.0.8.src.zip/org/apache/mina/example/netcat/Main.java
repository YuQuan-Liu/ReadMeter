/*  1:   */ package org.apache.mina.example.netcat;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import java.net.InetSocketAddress;
/*  5:   */ import org.apache.mina.core.future.CloseFuture;
/*  6:   */ import org.apache.mina.core.future.ConnectFuture;
/*  7:   */ import org.apache.mina.core.session.IoSession;
/*  8:   */ import org.apache.mina.transport.socket.nio.NioSocketConnector;
/*  9:   */ 
/* 10:   */ public class Main
/* 11:   */ {
/* 12:   */   public static void main(String[] args)
/* 13:   */     throws Exception
/* 14:   */   {
/* 15:36 */     if (args.length != 2)
/* 16:   */     {
/* 17:37 */       System.out.println(Main.class.getName() + " <hostname> <port>");
/* 18:38 */       return;
/* 19:   */     }
/* 20:42 */     NioSocketConnector connector = new NioSocketConnector();
/* 21:   */     
/* 22:   */ 
/* 23:45 */     connector.setConnectTimeoutMillis(30000L);
/* 24:   */     
/* 25:   */ 
/* 26:48 */     connector.setHandler(new NetCatProtocolHandler());
/* 27:49 */     ConnectFuture cf = connector.connect(new InetSocketAddress(args[0], Integer.parseInt(args[1])));
/* 28:   */     
/* 29:   */ 
/* 30:   */ 
/* 31:53 */     cf.awaitUninterruptibly();
/* 32:54 */     cf.getSession().getCloseFuture().awaitUninterruptibly();
/* 33:   */     
/* 34:56 */     connector.dispose();
/* 35:   */   }
/* 36:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.netcat.Main
 * JD-Core Version:    0.7.0.1
 */