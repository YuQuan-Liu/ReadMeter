/*  1:   */ package org.apache.mina.example.netcat;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  5:   */ import org.apache.mina.core.service.IoHandlerAdapter;
/*  6:   */ import org.apache.mina.core.session.IdleStatus;
/*  7:   */ import org.apache.mina.core.session.IoSession;
/*  8:   */ import org.apache.mina.core.session.IoSessionConfig;
/*  9:   */ 
/* 10:   */ public class NetCatProtocolHandler
/* 11:   */   extends IoHandlerAdapter
/* 12:   */ {
/* 13:   */   public void sessionOpened(IoSession session)
/* 14:   */   {
/* 15:40 */     session.getConfig().setIdleTime(IdleStatus.READER_IDLE, 10);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void sessionClosed(IoSession session)
/* 19:   */   {
/* 20:46 */     System.err.println("Total " + session.getReadBytes() + " byte(s)");
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void sessionIdle(IoSession session, IdleStatus status)
/* 24:   */   {
/* 25:52 */     if (status == IdleStatus.READER_IDLE) {
/* 26:53 */       session.close(true);
/* 27:   */     }
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void messageReceived(IoSession session, Object message)
/* 31:   */   {
/* 32:59 */     IoBuffer buf = (IoBuffer)message;
/* 33:61 */     while (buf.hasRemaining()) {
/* 34:62 */       System.out.print((char)buf.get());
/* 35:   */     }
/* 36:64 */     System.out.flush();
/* 37:   */   }
/* 38:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.netcat.NetCatProtocolHandler
 * JD-Core Version:    0.7.0.1
 */