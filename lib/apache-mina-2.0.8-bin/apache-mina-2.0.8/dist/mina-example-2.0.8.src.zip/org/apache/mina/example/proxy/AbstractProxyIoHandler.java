/*  1:   */ package org.apache.mina.example.proxy;
/*  2:   */ 
/*  3:   */ import java.nio.charset.Charset;
/*  4:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  5:   */ import org.apache.mina.core.service.IoHandlerAdapter;
/*  6:   */ import org.apache.mina.core.session.IoSession;
/*  7:   */ import org.slf4j.Logger;
/*  8:   */ import org.slf4j.LoggerFactory;
/*  9:   */ 
/* 10:   */ public abstract class AbstractProxyIoHandler
/* 11:   */   extends IoHandlerAdapter
/* 12:   */ {
/* 13:37 */   private static final Charset CHARSET = Charset.forName("iso8859-1");
/* 14:38 */   public static final String OTHER_IO_SESSION = AbstractProxyIoHandler.class.getName() + ".OtherIoSession";
/* 15:40 */   private static final Logger LOGGER = LoggerFactory.getLogger(AbstractProxyIoHandler.class);
/* 16:   */   
/* 17:   */   public void sessionCreated(IoSession session)
/* 18:   */     throws Exception
/* 19:   */   {
/* 20:44 */     session.suspendRead();
/* 21:45 */     session.suspendWrite();
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void sessionClosed(IoSession session)
/* 25:   */     throws Exception
/* 26:   */   {
/* 27:50 */     if (session.getAttribute(OTHER_IO_SESSION) != null)
/* 28:   */     {
/* 29:51 */       IoSession sess = (IoSession)session.getAttribute(OTHER_IO_SESSION);
/* 30:52 */       sess.setAttribute(OTHER_IO_SESSION, null);
/* 31:53 */       sess.close(false);
/* 32:54 */       session.setAttribute(OTHER_IO_SESSION, null);
/* 33:   */     }
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void messageReceived(IoSession session, Object message)
/* 37:   */     throws Exception
/* 38:   */   {
/* 39:61 */     IoBuffer rb = (IoBuffer)message;
/* 40:62 */     IoBuffer wb = IoBuffer.allocate(rb.remaining());
/* 41:63 */     rb.mark();
/* 42:64 */     wb.put(rb);
/* 43:65 */     wb.flip();
/* 44:66 */     ((IoSession)session.getAttribute(OTHER_IO_SESSION)).write(wb);
/* 45:67 */     rb.reset();
/* 46:68 */     LOGGER.info(rb.getString(CHARSET.newDecoder()));
/* 47:   */   }
/* 48:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.proxy.AbstractProxyIoHandler
 * JD-Core Version:    0.7.0.1
 */