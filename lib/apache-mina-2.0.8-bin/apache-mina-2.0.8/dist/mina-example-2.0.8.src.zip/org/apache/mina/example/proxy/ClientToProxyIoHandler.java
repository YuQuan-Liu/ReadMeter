/*  1:   */ package org.apache.mina.example.proxy;
/*  2:   */ 
/*  3:   */ import java.net.SocketAddress;
/*  4:   */ import org.apache.mina.core.RuntimeIoException;
/*  5:   */ import org.apache.mina.core.future.ConnectFuture;
/*  6:   */ import org.apache.mina.core.future.IoFutureListener;
/*  7:   */ import org.apache.mina.core.service.IoConnector;
/*  8:   */ import org.apache.mina.core.session.IoSession;
/*  9:   */ 
/* 10:   */ public class ClientToProxyIoHandler
/* 11:   */   extends AbstractProxyIoHandler
/* 12:   */ {
/* 13:36 */   private final ServerToProxyIoHandler connectorHandler = new ServerToProxyIoHandler();
/* 14:   */   private final IoConnector connector;
/* 15:   */   private final SocketAddress remoteAddress;
/* 16:   */   
/* 17:   */   public ClientToProxyIoHandler(IoConnector connector, SocketAddress remoteAddress)
/* 18:   */   {
/* 19:44 */     this.connector = connector;
/* 20:45 */     this.remoteAddress = remoteAddress;
/* 21:46 */     connector.setHandler(this.connectorHandler);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void sessionOpened(final IoSession session)
/* 25:   */     throws Exception
/* 26:   */   {
/* 27:52 */     this.connector.connect(this.remoteAddress).addListener(new IoFutureListener()
/* 28:   */     {
/* 29:   */       public void operationComplete(ConnectFuture future)
/* 30:   */       {
/* 31:   */         try
/* 32:   */         {
/* 33:55 */           future.getSession().setAttribute(AbstractProxyIoHandler.OTHER_IO_SESSION, session);
/* 34:56 */           session.setAttribute(AbstractProxyIoHandler.OTHER_IO_SESSION, future.getSession());
/* 35:57 */           IoSession session2 = future.getSession();
/* 36:58 */           session2.resumeRead();
/* 37:59 */           session2.resumeWrite();
/* 38:   */         }
/* 39:   */         catch (RuntimeIoException e)
/* 40:   */         {
/* 41:62 */           session.close(true);
/* 42:   */         }
/* 43:   */         finally
/* 44:   */         {
/* 45:64 */           session.resumeRead();
/* 46:65 */           session.resumeWrite();
/* 47:   */         }
/* 48:   */       }
/* 49:   */     });
/* 50:   */   }
/* 51:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.proxy.ClientToProxyIoHandler
 * JD-Core Version:    0.7.0.1
 */