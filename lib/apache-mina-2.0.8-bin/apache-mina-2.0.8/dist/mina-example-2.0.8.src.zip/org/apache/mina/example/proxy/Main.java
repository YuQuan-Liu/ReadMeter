/*  1:   */ package org.apache.mina.example.proxy;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import java.net.InetSocketAddress;
/*  5:   */ import org.apache.mina.core.service.IoConnector;
/*  6:   */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
/*  7:   */ import org.apache.mina.transport.socket.nio.NioSocketConnector;
/*  8:   */ 
/*  9:   */ public class Main
/* 10:   */ {
/* 11:   */   public static void main(String[] args)
/* 12:   */     throws Exception
/* 13:   */   {
/* 14:45 */     if (args.length != 3)
/* 15:   */     {
/* 16:46 */       System.out.println(Main.class.getName() + " <proxy-port> <server-hostname> <server-port>");
/* 17:   */       
/* 18:48 */       return;
/* 19:   */     }
/* 20:52 */     NioSocketAcceptor acceptor = new NioSocketAcceptor();
/* 21:   */     
/* 22:   */ 
/* 23:55 */     IoConnector connector = new NioSocketConnector();
/* 24:   */     
/* 25:   */ 
/* 26:58 */     connector.setConnectTimeoutMillis(30000L);
/* 27:   */     
/* 28:60 */     ClientToProxyIoHandler handler = new ClientToProxyIoHandler(connector, new InetSocketAddress(args[1], Integer.parseInt(args[2])));
/* 29:   */     
/* 30:   */ 
/* 31:   */ 
/* 32:64 */     acceptor.setHandler(handler);
/* 33:65 */     acceptor.bind(new InetSocketAddress(Integer.parseInt(args[0])));
/* 34:   */     
/* 35:67 */     System.out.println("Listening on port " + Integer.parseInt(args[0]));
/* 36:   */   }
/* 37:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.proxy.Main
 * JD-Core Version:    0.7.0.1
 */