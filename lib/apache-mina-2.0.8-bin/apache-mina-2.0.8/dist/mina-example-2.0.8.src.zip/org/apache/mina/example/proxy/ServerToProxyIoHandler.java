package org.apache.mina.example.proxy;

public class ServerToProxyIoHandler
  extends AbstractProxyIoHandler
{}


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.proxy.ServerToProxyIoHandler
 * JD-Core Version:    0.7.0.1
 */