/*  1:   */ package org.apache.mina.example.reverser;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import java.net.InetSocketAddress;
/*  5:   */ import java.nio.charset.Charset;
/*  6:   */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*  7:   */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/*  8:   */ import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
/*  9:   */ import org.apache.mina.filter.logging.LoggingFilter;
/* 10:   */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
/* 11:   */ 
/* 12:   */ public class Main
/* 13:   */ {
/* 14:   */   private static final int PORT = 8080;
/* 15:   */   
/* 16:   */   public static void main(String[] args)
/* 17:   */     throws Exception
/* 18:   */   {
/* 19:40 */     NioSocketAcceptor acceptor = new NioSocketAcceptor();
/* 20:   */     
/* 21:   */ 
/* 22:43 */     acceptor.getFilterChain().addLast("logger", new LoggingFilter());
/* 23:44 */     acceptor.getFilterChain().addLast("codec", new ProtocolCodecFilter(new TextLineCodecFactory(Charset.forName("UTF-8"))));
/* 24:   */     
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:50 */     acceptor.setHandler(new ReverseProtocolHandler());
/* 30:51 */     acceptor.bind(new InetSocketAddress(8080));
/* 31:   */     
/* 32:53 */     System.out.println("Listening on port 8080");
/* 33:   */   }
/* 34:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.reverser.Main
 * JD-Core Version:    0.7.0.1
 */