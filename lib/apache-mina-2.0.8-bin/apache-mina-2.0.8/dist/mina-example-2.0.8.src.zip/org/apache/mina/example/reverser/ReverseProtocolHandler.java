/*  1:   */ package org.apache.mina.example.reverser;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.service.IoHandlerAdapter;
/*  4:   */ import org.apache.mina.core.session.IoSession;
/*  5:   */ 
/*  6:   */ public class ReverseProtocolHandler
/*  7:   */   extends IoHandlerAdapter
/*  8:   */ {
/*  9:   */   public void exceptionCaught(IoSession session, Throwable cause)
/* 10:   */   {
/* 11:35 */     session.close(true);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public void messageReceived(IoSession session, Object message)
/* 15:   */   {
/* 16:41 */     String str = message.toString();
/* 17:42 */     StringBuilder buf = new StringBuilder(str.length());
/* 18:43 */     for (int i = str.length() - 1; i >= 0; i--) {
/* 19:44 */       buf.append(str.charAt(i));
/* 20:   */     }
/* 21:48 */     session.write(buf.toString());
/* 22:   */   }
/* 23:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.reverser.ReverseProtocolHandler
 * JD-Core Version:    0.7.0.1
 */