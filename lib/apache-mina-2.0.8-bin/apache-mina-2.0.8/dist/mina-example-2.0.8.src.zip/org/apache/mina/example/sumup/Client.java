/*  1:   */ package org.apache.mina.example.sumup;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import java.net.InetSocketAddress;
/*  5:   */ import org.apache.mina.core.RuntimeIoException;
/*  6:   */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*  7:   */ import org.apache.mina.core.future.CloseFuture;
/*  8:   */ import org.apache.mina.core.future.ConnectFuture;
/*  9:   */ import org.apache.mina.core.session.IoSession;
/* 10:   */ import org.apache.mina.example.sumup.codec.SumUpProtocolCodecFactory;
/* 11:   */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/* 12:   */ import org.apache.mina.filter.logging.LoggingFilter;
/* 13:   */ import org.apache.mina.transport.socket.nio.NioSocketConnector;
/* 14:   */ 
/* 15:   */ public class Client
/* 16:   */ {
/* 17:   */   private static final String HOSTNAME = "localhost";
/* 18:   */   private static final int PORT = 8080;
/* 19:   */   private static final long CONNECT_TIMEOUT = 30000L;
/* 20:   */   private static final boolean USE_CUSTOM_CODEC = true;
/* 21:   */   
/* 22:   */   public static void main(String[] args)
/* 23:   */     throws Throwable
/* 24:   */   {
/* 25:49 */     if (args.length == 0)
/* 26:   */     {
/* 27:50 */       System.out.println("Please specify the list of any integers");
/* 28:51 */       return;
/* 29:   */     }
/* 30:55 */     int[] values = new int[args.length];
/* 31:56 */     for (int i = 0; i < args.length; i++) {
/* 32:57 */       values[i] = Integer.parseInt(args[i]);
/* 33:   */     }
/* 34:60 */     NioSocketConnector connector = new NioSocketConnector();
/* 35:   */     
/* 36:   */ 
/* 37:63 */     connector.setConnectTimeoutMillis(30000L);
/* 38:   */     
/* 39:65 */     connector.getFilterChain().addLast("codec", new ProtocolCodecFilter(new SumUpProtocolCodecFactory(false)));
/* 40:   */     
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:75 */     connector.getFilterChain().addLast("logger", new LoggingFilter());
/* 50:   */     
/* 51:77 */     connector.setHandler(new ClientSessionHandler(values));
/* 52:   */     IoSession session;
/* 53:   */     for (;;)
/* 54:   */     {
/* 55:   */       try
/* 56:   */       {
/* 57:82 */         ConnectFuture future = connector.connect(new InetSocketAddress("localhost", 8080));
/* 58:   */         
/* 59:84 */         future.awaitUninterruptibly();
/* 60:85 */         session = future.getSession();
/* 61:   */       }
/* 62:   */       catch (RuntimeIoException e)
/* 63:   */       {
/* 64:88 */         System.err.println("Failed to connect.");
/* 65:89 */         e.printStackTrace();
/* 66:90 */         Thread.sleep(5000L);
/* 67:   */       }
/* 68:   */     }
/* 69:95 */     session.getCloseFuture().awaitUninterruptibly();
/* 70:   */     
/* 71:97 */     connector.dispose();
/* 72:   */   }
/* 73:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.Client
 * JD-Core Version:    0.7.0.1
 */