/*  1:   */ package org.apache.mina.example.sumup;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.service.IoHandlerAdapter;
/*  4:   */ import org.apache.mina.core.session.IoSession;
/*  5:   */ import org.apache.mina.example.sumup.message.AddMessage;
/*  6:   */ import org.apache.mina.example.sumup.message.ResultMessage;
/*  7:   */ import org.slf4j.Logger;
/*  8:   */ import org.slf4j.LoggerFactory;
/*  9:   */ 
/* 10:   */ public class ClientSessionHandler
/* 11:   */   extends IoHandlerAdapter
/* 12:   */ {
/* 13:37 */   private static final Logger LOGGER = LoggerFactory.getLogger(ClientSessionHandler.class);
/* 14:   */   private final int[] values;
/* 15:   */   private boolean finished;
/* 16:   */   
/* 17:   */   public ClientSessionHandler(int[] values)
/* 18:   */   {
/* 19:44 */     this.values = values;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean isFinished()
/* 23:   */   {
/* 24:48 */     return this.finished;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void sessionOpened(IoSession session)
/* 28:   */   {
/* 29:54 */     for (int i = 0; i < this.values.length; i++)
/* 30:   */     {
/* 31:55 */       AddMessage m = new AddMessage();
/* 32:56 */       m.setSequence(i);
/* 33:57 */       m.setValue(this.values[i]);
/* 34:58 */       session.write(m);
/* 35:   */     }
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void messageReceived(IoSession session, Object message)
/* 39:   */   {
/* 40:66 */     ResultMessage rm = (ResultMessage)message;
/* 41:67 */     if (rm.isOk())
/* 42:   */     {
/* 43:72 */       if (rm.getSequence() == this.values.length - 1)
/* 44:   */       {
/* 45:74 */         LOGGER.info("The sum: " + rm.getValue());
/* 46:75 */         session.close(true);
/* 47:76 */         this.finished = true;
/* 48:   */       }
/* 49:   */     }
/* 50:   */     else
/* 51:   */     {
/* 52:80 */       LOGGER.warn("Server error, disconnecting...");
/* 53:81 */       session.close(true);
/* 54:82 */       this.finished = true;
/* 55:   */     }
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void exceptionCaught(IoSession session, Throwable cause)
/* 59:   */   {
/* 60:88 */     session.close(true);
/* 61:   */   }
/* 62:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.ClientSessionHandler
 * JD-Core Version:    0.7.0.1
 */