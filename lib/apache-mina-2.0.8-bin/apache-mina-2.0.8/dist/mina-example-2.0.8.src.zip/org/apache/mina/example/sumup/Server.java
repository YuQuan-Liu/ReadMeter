/*  1:   */ package org.apache.mina.example.sumup;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import java.net.InetSocketAddress;
/*  5:   */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*  6:   */ import org.apache.mina.example.sumup.codec.SumUpProtocolCodecFactory;
/*  7:   */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/*  8:   */ import org.apache.mina.filter.logging.LoggingFilter;
/*  9:   */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
/* 10:   */ 
/* 11:   */ public class Server
/* 12:   */ {
/* 13:   */   private static final int SERVER_PORT = 8080;
/* 14:   */   private static final boolean USE_CUSTOM_CODEC = true;
/* 15:   */   
/* 16:   */   public static void main(String[] args)
/* 17:   */     throws Throwable
/* 18:   */   {
/* 19:42 */     NioSocketAcceptor acceptor = new NioSocketAcceptor();
/* 20:   */     
/* 21:   */ 
/* 22:   */ 
/* 23:46 */     acceptor.getFilterChain().addLast("codec", new ProtocolCodecFilter(new SumUpProtocolCodecFactory(true)));
/* 24:   */     
/* 25:   */ 
/* 26:   */ 
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:   */ 
/* 34:57 */     acceptor.getFilterChain().addLast("logger", new LoggingFilter());
/* 35:   */     
/* 36:59 */     acceptor.setHandler(new ServerSessionHandler());
/* 37:60 */     acceptor.bind(new InetSocketAddress(8080));
/* 38:   */     
/* 39:62 */     System.out.println("Listening on port 8080");
/* 40:   */   }
/* 41:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.Server
 * JD-Core Version:    0.7.0.1
 */