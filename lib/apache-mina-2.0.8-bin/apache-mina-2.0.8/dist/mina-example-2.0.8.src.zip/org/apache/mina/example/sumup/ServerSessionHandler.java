/*  1:   */ package org.apache.mina.example.sumup;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.service.IoHandlerAdapter;
/*  4:   */ import org.apache.mina.core.session.IdleStatus;
/*  5:   */ import org.apache.mina.core.session.IoSession;
/*  6:   */ import org.apache.mina.core.session.IoSessionConfig;
/*  7:   */ import org.apache.mina.example.sumup.message.AddMessage;
/*  8:   */ import org.apache.mina.example.sumup.message.ResultMessage;
/*  9:   */ import org.slf4j.Logger;
/* 10:   */ import org.slf4j.LoggerFactory;
/* 11:   */ 
/* 12:   */ public class ServerSessionHandler
/* 13:   */   extends IoHandlerAdapter
/* 14:   */ {
/* 15:   */   private static final String SUM_KEY = "sum";
/* 16:40 */   private static final Logger LOGGER = LoggerFactory.getLogger(ServerSessionHandler.class);
/* 17:   */   
/* 18:   */   public void sessionOpened(IoSession session)
/* 19:   */   {
/* 20:45 */     session.getConfig().setIdleTime(IdleStatus.BOTH_IDLE, 60);
/* 21:   */     
/* 22:   */ 
/* 23:48 */     session.setAttribute("sum", Integer.valueOf(0));
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void messageReceived(IoSession session, Object message)
/* 27:   */   {
/* 28:55 */     AddMessage am = (AddMessage)message;
/* 29:   */     
/* 30:   */ 
/* 31:58 */     int sum = ((Integer)session.getAttribute("sum")).intValue();
/* 32:59 */     int value = am.getValue();
/* 33:60 */     long expectedSum = sum + value;
/* 34:61 */     if ((expectedSum > 2147483647L) || (expectedSum < -2147483648L))
/* 35:   */     {
/* 36:63 */       ResultMessage rm = new ResultMessage();
/* 37:64 */       rm.setSequence(am.getSequence());
/* 38:65 */       rm.setOk(false);
/* 39:66 */       session.write(rm);
/* 40:   */     }
/* 41:   */     else
/* 42:   */     {
/* 43:69 */       sum = (int)expectedSum;
/* 44:70 */       session.setAttribute("sum", Integer.valueOf(sum));
/* 45:   */       
/* 46:   */ 
/* 47:73 */       ResultMessage rm = new ResultMessage();
/* 48:74 */       rm.setSequence(am.getSequence());
/* 49:75 */       rm.setOk(true);
/* 50:76 */       rm.setValue(sum);
/* 51:77 */       session.write(rm);
/* 52:   */     }
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void sessionIdle(IoSession session, IdleStatus status)
/* 56:   */   {
/* 57:83 */     LOGGER.info("Disconnecting the idle.");
/* 58:   */     
/* 59:85 */     session.close(true);
/* 60:   */   }
/* 61:   */   
/* 62:   */   public void exceptionCaught(IoSession session, Throwable cause)
/* 63:   */   {
/* 64:91 */     session.close(true);
/* 65:   */   }
/* 66:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.ServerSessionHandler
 * JD-Core Version:    0.7.0.1
 */