/*  1:   */ package org.apache.mina.example.sumup.codec;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  4:   */ import org.apache.mina.core.session.IoSession;
/*  5:   */ import org.apache.mina.example.sumup.message.AbstractMessage;
/*  6:   */ import org.apache.mina.filter.codec.ProtocolDecoderOutput;
/*  7:   */ import org.apache.mina.filter.codec.demux.MessageDecoder;
/*  8:   */ import org.apache.mina.filter.codec.demux.MessageDecoderResult;
/*  9:   */ 
/* 10:   */ public abstract class AbstractMessageDecoder
/* 11:   */   implements MessageDecoder
/* 12:   */ {
/* 13:   */   private final int type;
/* 14:   */   private int sequence;
/* 15:   */   private boolean readHeader;
/* 16:   */   
/* 17:   */   protected AbstractMessageDecoder(int type)
/* 18:   */   {
/* 19:43 */     this.type = type;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public MessageDecoderResult decodable(IoSession session, IoBuffer in)
/* 23:   */   {
/* 24:48 */     if (in.remaining() < 6) {
/* 25:49 */       return MessageDecoderResult.NEED_DATA;
/* 26:   */     }
/* 27:53 */     if (this.type == in.getShort()) {
/* 28:54 */       return MessageDecoderResult.OK;
/* 29:   */     }
/* 30:58 */     return MessageDecoderResult.NOT_OK;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public MessageDecoderResult decode(IoSession session, IoBuffer in, ProtocolDecoderOutput out)
/* 34:   */     throws Exception
/* 35:   */   {
/* 36:64 */     if (!this.readHeader)
/* 37:   */     {
/* 38:65 */       in.getShort();
/* 39:66 */       this.sequence = in.getInt();
/* 40:67 */       this.readHeader = true;
/* 41:   */     }
/* 42:71 */     AbstractMessage m = decodeBody(session, in);
/* 43:73 */     if (m == null) {
/* 44:74 */       return MessageDecoderResult.NEED_DATA;
/* 45:   */     }
/* 46:76 */     this.readHeader = false;
/* 47:   */     
/* 48:78 */     m.setSequence(this.sequence);
/* 49:79 */     out.write(m);
/* 50:   */     
/* 51:81 */     return MessageDecoderResult.OK;
/* 52:   */   }
/* 53:   */   
/* 54:   */   protected abstract AbstractMessage decodeBody(IoSession paramIoSession, IoBuffer paramIoBuffer);
/* 55:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.codec.AbstractMessageDecoder
 * JD-Core Version:    0.7.0.1
 */