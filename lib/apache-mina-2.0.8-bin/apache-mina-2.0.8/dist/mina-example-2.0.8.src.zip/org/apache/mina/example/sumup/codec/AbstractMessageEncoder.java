/*  1:   */ package org.apache.mina.example.sumup.codec;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  4:   */ import org.apache.mina.core.session.IoSession;
/*  5:   */ import org.apache.mina.example.sumup.message.AbstractMessage;
/*  6:   */ import org.apache.mina.filter.codec.ProtocolEncoderOutput;
/*  7:   */ import org.apache.mina.filter.codec.demux.MessageEncoder;
/*  8:   */ 
/*  9:   */ public abstract class AbstractMessageEncoder<T extends AbstractMessage>
/* 10:   */   implements MessageEncoder<T>
/* 11:   */ {
/* 12:   */   private final int type;
/* 13:   */   
/* 14:   */   protected AbstractMessageEncoder(int type)
/* 15:   */   {
/* 16:38 */     this.type = type;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void encode(IoSession session, T message, ProtocolEncoderOutput out)
/* 20:   */     throws Exception
/* 21:   */   {
/* 22:42 */     IoBuffer buf = IoBuffer.allocate(16);
/* 23:43 */     buf.setAutoExpand(true);
/* 24:   */     
/* 25:   */ 
/* 26:46 */     buf.putShort((short)this.type);
/* 27:47 */     buf.putInt(message.getSequence());
/* 28:   */     
/* 29:   */ 
/* 30:50 */     encodeBody(session, message, buf);
/* 31:51 */     buf.flip();
/* 32:52 */     out.write(buf);
/* 33:   */   }
/* 34:   */   
/* 35:   */   protected abstract void encodeBody(IoSession paramIoSession, T paramT, IoBuffer paramIoBuffer);
/* 36:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.codec.AbstractMessageEncoder
 * JD-Core Version:    0.7.0.1
 */