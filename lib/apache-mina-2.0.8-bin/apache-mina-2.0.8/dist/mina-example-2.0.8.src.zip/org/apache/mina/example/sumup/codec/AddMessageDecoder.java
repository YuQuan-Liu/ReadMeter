/*  1:   */ package org.apache.mina.example.sumup.codec;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  4:   */ import org.apache.mina.core.session.IoSession;
/*  5:   */ import org.apache.mina.example.sumup.message.AbstractMessage;
/*  6:   */ import org.apache.mina.example.sumup.message.AddMessage;
/*  7:   */ import org.apache.mina.filter.codec.ProtocolDecoderOutput;
/*  8:   */ 
/*  9:   */ public class AddMessageDecoder
/* 10:   */   extends AbstractMessageDecoder
/* 11:   */ {
/* 12:   */   public AddMessageDecoder()
/* 13:   */   {
/* 14:37 */     super(1);
/* 15:   */   }
/* 16:   */   
/* 17:   */   protected AbstractMessage decodeBody(IoSession session, IoBuffer in)
/* 18:   */   {
/* 19:42 */     if (in.remaining() < 4) {
/* 20:43 */       return null;
/* 21:   */     }
/* 22:46 */     AddMessage m = new AddMessage();
/* 23:47 */     m.setValue(in.getInt());
/* 24:48 */     return m;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void finishDecode(IoSession session, ProtocolDecoderOutput out)
/* 28:   */     throws Exception
/* 29:   */   {}
/* 30:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.codec.AddMessageDecoder
 * JD-Core Version:    0.7.0.1
 */