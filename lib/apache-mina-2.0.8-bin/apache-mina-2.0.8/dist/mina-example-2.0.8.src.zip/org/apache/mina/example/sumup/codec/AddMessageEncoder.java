/*  1:   */ package org.apache.mina.example.sumup.codec;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  4:   */ import org.apache.mina.core.session.IoSession;
/*  5:   */ import org.apache.mina.example.sumup.message.AddMessage;
/*  6:   */ 
/*  7:   */ public class AddMessageEncoder<T extends AddMessage>
/*  8:   */   extends AbstractMessageEncoder<T>
/*  9:   */ {
/* 10:   */   public AddMessageEncoder()
/* 11:   */   {
/* 12:34 */     super(1);
/* 13:   */   }
/* 14:   */   
/* 15:   */   protected void encodeBody(IoSession session, T message, IoBuffer out)
/* 16:   */   {
/* 17:39 */     out.putInt(message.getValue());
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void dispose()
/* 21:   */     throws Exception
/* 22:   */   {}
/* 23:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.codec.AddMessageEncoder
 * JD-Core Version:    0.7.0.1
 */