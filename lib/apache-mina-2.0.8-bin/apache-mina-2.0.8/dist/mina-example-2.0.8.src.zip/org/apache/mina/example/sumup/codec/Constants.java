package org.apache.mina.example.sumup.codec;

public class Constants
{
  public static final int TYPE_LEN = 2;
  public static final int SEQUENCE_LEN = 4;
  public static final int HEADER_LEN = 6;
  public static final int BODY_LEN = 12;
  public static final int RESULT = 0;
  public static final int ADD = 1;
  public static final int RESULT_CODE_LEN = 2;
  public static final int RESULT_VALUE_LEN = 4;
  public static final int ADD_BODY_LEN = 4;
  public static final int RESULT_OK = 0;
  public static final int RESULT_ERROR = 1;
}


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.codec.Constants
 * JD-Core Version:    0.7.0.1
 */