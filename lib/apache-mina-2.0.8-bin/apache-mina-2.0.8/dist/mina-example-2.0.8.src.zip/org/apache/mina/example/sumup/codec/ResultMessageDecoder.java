/*  1:   */ package org.apache.mina.example.sumup.codec;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  4:   */ import org.apache.mina.core.session.IoSession;
/*  5:   */ import org.apache.mina.example.sumup.message.AbstractMessage;
/*  6:   */ import org.apache.mina.example.sumup.message.ResultMessage;
/*  7:   */ import org.apache.mina.filter.codec.ProtocolDecoderOutput;
/*  8:   */ 
/*  9:   */ public class ResultMessageDecoder
/* 10:   */   extends AbstractMessageDecoder
/* 11:   */ {
/* 12:   */   private int code;
/* 13:   */   private boolean readCode;
/* 14:   */   
/* 15:   */   public ResultMessageDecoder()
/* 16:   */   {
/* 17:40 */     super(0);
/* 18:   */   }
/* 19:   */   
/* 20:   */   protected AbstractMessage decodeBody(IoSession session, IoBuffer in)
/* 21:   */   {
/* 22:45 */     if (!this.readCode)
/* 23:   */     {
/* 24:46 */       if (in.remaining() < 2) {
/* 25:47 */         return null;
/* 26:   */       }
/* 27:50 */       this.code = in.getShort();
/* 28:51 */       this.readCode = true;
/* 29:   */     }
/* 30:54 */     if (this.code == 0)
/* 31:   */     {
/* 32:55 */       if (in.remaining() < 4) {
/* 33:56 */         return null;
/* 34:   */       }
/* 35:59 */       ResultMessage m = new ResultMessage();
/* 36:60 */       m.setOk(true);
/* 37:61 */       m.setValue(in.getInt());
/* 38:62 */       this.readCode = false;
/* 39:63 */       return m;
/* 40:   */     }
/* 41:65 */     ResultMessage m = new ResultMessage();
/* 42:66 */     m.setOk(false);
/* 43:67 */     this.readCode = false;
/* 44:68 */     return m;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void finishDecode(IoSession session, ProtocolDecoderOutput out)
/* 48:   */     throws Exception
/* 49:   */   {}
/* 50:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.codec.ResultMessageDecoder
 * JD-Core Version:    0.7.0.1
 */