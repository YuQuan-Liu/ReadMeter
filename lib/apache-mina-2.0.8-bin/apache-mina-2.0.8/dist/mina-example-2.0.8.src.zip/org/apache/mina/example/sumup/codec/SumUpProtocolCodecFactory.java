/*  1:   */ package org.apache.mina.example.sumup.codec;
/*  2:   */ 
/*  3:   */ import org.apache.mina.example.sumup.message.AddMessage;
/*  4:   */ import org.apache.mina.example.sumup.message.ResultMessage;
/*  5:   */ import org.apache.mina.filter.codec.demux.DemuxingProtocolCodecFactory;
/*  6:   */ 
/*  7:   */ public class SumUpProtocolCodecFactory
/*  8:   */   extends DemuxingProtocolCodecFactory
/*  9:   */ {
/* 10:   */   public SumUpProtocolCodecFactory(boolean server)
/* 11:   */   {
/* 12:36 */     if (server)
/* 13:   */     {
/* 14:37 */       super.addMessageDecoder(AddMessageDecoder.class);
/* 15:38 */       super.addMessageEncoder(ResultMessage.class, ResultMessageEncoder.class);
/* 16:   */     }
/* 17:   */     else
/* 18:   */     {
/* 19:41 */       super.addMessageEncoder(AddMessage.class, AddMessageEncoder.class);
/* 20:42 */       super.addMessageDecoder(ResultMessageDecoder.class);
/* 21:   */     }
/* 22:   */   }
/* 23:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.codec.SumUpProtocolCodecFactory
 * JD-Core Version:    0.7.0.1
 */