/*  1:   */ package org.apache.mina.example.sumup.message;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ 
/*  5:   */ public abstract class AbstractMessage
/*  6:   */   implements Serializable
/*  7:   */ {
/*  8:   */   private int sequence;
/*  9:   */   
/* 10:   */   public int getSequence()
/* 11:   */   {
/* 12:33 */     return this.sequence;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setSequence(int sequence)
/* 16:   */   {
/* 17:37 */     this.sequence = sequence;
/* 18:   */   }
/* 19:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.message.AbstractMessage
 * JD-Core Version:    0.7.0.1
 */