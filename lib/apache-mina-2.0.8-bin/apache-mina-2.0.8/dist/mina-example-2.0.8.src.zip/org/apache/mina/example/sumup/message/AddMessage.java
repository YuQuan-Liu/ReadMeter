/*  1:   */ package org.apache.mina.example.sumup.message;
/*  2:   */ 
/*  3:   */ public class AddMessage
/*  4:   */   extends AbstractMessage
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = -940833727168119141L;
/*  7:   */   private int value;
/*  8:   */   
/*  9:   */   public int getValue()
/* 10:   */   {
/* 11:36 */     return this.value;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public void setValue(int value)
/* 15:   */   {
/* 16:40 */     this.value = value;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String toString()
/* 20:   */   {
/* 21:46 */     return getSequence() + ":ADD(" + this.value + ')';
/* 22:   */   }
/* 23:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.message.AddMessage
 * JD-Core Version:    0.7.0.1
 */