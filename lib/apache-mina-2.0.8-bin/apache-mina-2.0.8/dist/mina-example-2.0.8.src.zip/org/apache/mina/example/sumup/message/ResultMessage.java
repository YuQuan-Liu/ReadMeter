/*  1:   */ package org.apache.mina.example.sumup.message;
/*  2:   */ 
/*  3:   */ public class ResultMessage
/*  4:   */   extends AbstractMessage
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 7371210248110219946L;
/*  7:   */   private boolean ok;
/*  8:   */   private int value;
/*  9:   */   
/* 10:   */   public boolean isOk()
/* 11:   */   {
/* 12:38 */     return this.ok;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setOk(boolean ok)
/* 16:   */   {
/* 17:42 */     this.ok = ok;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int getValue()
/* 21:   */   {
/* 22:46 */     return this.value;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setValue(int value)
/* 26:   */   {
/* 27:50 */     this.value = value;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String toString()
/* 31:   */   {
/* 32:55 */     if (this.ok) {
/* 33:56 */       return getSequence() + ":RESULT(" + this.value + ')';
/* 34:   */     }
/* 35:58 */     return getSequence() + ":RESULT(ERROR)";
/* 36:   */   }
/* 37:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.sumup.message.ResultMessage
 * JD-Core Version:    0.7.0.1
 */