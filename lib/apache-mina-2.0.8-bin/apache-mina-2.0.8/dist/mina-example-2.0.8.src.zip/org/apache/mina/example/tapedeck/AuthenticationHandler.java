/*   1:    */ package org.apache.mina.example.tapedeck;
/*   2:    */ 
/*   3:    */ import org.apache.mina.core.filterchain.IoFilter.NextFilter;
/*   4:    */ import org.apache.mina.core.future.IoFutureListener;
/*   5:    */ import org.apache.mina.core.future.WriteFuture;
/*   6:    */ import org.apache.mina.core.session.IoSession;
/*   7:    */ import org.apache.mina.core.write.WriteRequest;
/*   8:    */ import org.apache.mina.statemachine.StateControl;
/*   9:    */ import org.apache.mina.statemachine.annotation.IoFilterTransition;
/*  10:    */ import org.apache.mina.statemachine.annotation.State;
/*  11:    */ import org.apache.mina.statemachine.context.AbstractStateContext;
/*  12:    */ 
/*  13:    */ public class AuthenticationHandler
/*  14:    */ {
/*  15:    */   @State
/*  16:    */   public static final String ROOT = "Root";
/*  17:    */   @State("Root")
/*  18:    */   public static final String START = "Start";
/*  19:    */   @State("Root")
/*  20:    */   public static final String WAIT_USER = "WaitUser";
/*  21:    */   @State("Root")
/*  22:    */   public static final String WAIT_PASSWORD = "WaitPassword";
/*  23:    */   @State("Root")
/*  24:    */   public static final String DONE = "Done";
/*  25:    */   @State("Root")
/*  26:    */   public static final String FAILED = "Failed";
/*  27:    */   
/*  28:    */   static class AuthenticationContext
/*  29:    */     extends AbstractStateContext
/*  30:    */   {
/*  31:    */     private String user;
/*  32:    */     private String password;
/*  33: 50 */     private int tries = 0;
/*  34:    */   }
/*  35:    */   
/*  36:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.SESSION_OPENED}, in={"Start"}, next="WaitUser")
/*  37:    */   public void sendAuthRequest(IoFilter.NextFilter nextFilter, IoSession session)
/*  38:    */   {
/*  39: 55 */     session.write("+ Greetings from your tape deck!. Please authenticate yourself.");
/*  40:    */   }
/*  41:    */   
/*  42:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.MESSAGE_RECEIVED}, in={"WaitUser"}, next="WaitPassword")
/*  43:    */   public void user(AuthenticationContext context, IoFilter.NextFilter nextFilter, IoSession session, UserCommand cmd)
/*  44:    */   {
/*  45: 60 */     context.user = cmd.getUsername();
/*  46: 61 */     session.write("+ Give me your password (hint: try your username backwards)");
/*  47:    */   }
/*  48:    */   
/*  49:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.MESSAGE_RECEIVED}, in={"WaitPassword"}, next="Done")
/*  50:    */   public void password(AuthenticationContext context, IoFilter.NextFilter nextFilter, IoSession session, PasswordCommand cmd)
/*  51:    */   {
/*  52: 66 */     context.password = cmd.getPassword();
/*  53: 67 */     if (context.password.equals(reverse(context.user)))
/*  54:    */     {
/*  55: 68 */       session.write("+ Authentication succeeded! Your tape deck has been unlocked.");
/*  56:    */     }
/*  57:    */     else
/*  58:    */     {
/*  59: 70 */       AuthenticationContext.access$208(context);
/*  60: 71 */       if (context.tries < 3)
/*  61:    */       {
/*  62: 72 */         session.write("- Authentication failed! Please try again.");
/*  63: 73 */         StateControl.breakAndGotoNext("WaitUser");
/*  64:    */       }
/*  65:    */       else
/*  66:    */       {
/*  67: 75 */         session.write("- Authentication failed too many times! Bye bye.").addListener(IoFutureListener.CLOSE);
/*  68: 76 */         StateControl.breakAndGotoNext("Failed");
/*  69:    */       }
/*  70:    */     }
/*  71:    */   }
/*  72:    */   
/*  73:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.MESSAGE_RECEIVED}, in={"Root"})
/*  74:    */   public void quit(TapeDeckServer.TapeDeckContext context, IoSession session, QuitCommand cmd)
/*  75:    */   {
/*  76: 84 */     session.write("+ Bye! Please come back!").addListener(IoFutureListener.CLOSE);
/*  77:    */   }
/*  78:    */   
/*  79:    */   private String reverse(String s)
/*  80:    */   {
/*  81: 88 */     char[] expectedPassword = new char[s.length()];
/*  82: 89 */     for (int i = 0; i < expectedPassword.length; i++) {
/*  83: 90 */       expectedPassword[i] = s.charAt(s.length() - i - 1);
/*  84:    */     }
/*  85: 92 */     return new String(expectedPassword);
/*  86:    */   }
/*  87:    */   
/*  88:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.MESSAGE_RECEIVED}, in={"WaitUser"}, weight=10)
/*  89:    */   public void errorWaitingForUser(IoSession session, Command cmd)
/*  90:    */   {
/*  91: 97 */     if ((cmd instanceof QuitCommand)) {
/*  92: 98 */       StateControl.breakAndContinue();
/*  93:    */     }
/*  94:100 */     session.write("Unexpected command '" + cmd.getName() + "'. Expected 'user <username>'.");
/*  95:    */   }
/*  96:    */   
/*  97:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.MESSAGE_RECEIVED}, in={"WaitPassword"}, weight=10)
/*  98:    */   public void errorWaitingForPassword(IoSession session, Command cmd)
/*  99:    */   {
/* 100:105 */     if ((cmd instanceof QuitCommand)) {
/* 101:106 */       StateControl.breakAndContinue();
/* 102:    */     }
/* 103:108 */     session.write("Unexpected command '" + cmd.getName() + "'. Expected 'password <password>'.");
/* 104:    */   }
/* 105:    */   
/* 106:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.EXCEPTION_CAUGHT}, in={"Root"})
/* 107:    */   public void commandSyntaxError(IoSession session, CommandSyntaxException e)
/* 108:    */   {
/* 109:113 */     session.write("- " + e.getMessage());
/* 110:    */   }
/* 111:    */   
/* 112:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.EXCEPTION_CAUGHT}, in={"Root"}, weight=10)
/* 113:    */   public void exceptionCaught(IoSession session, Exception e)
/* 114:    */   {
/* 115:118 */     e.printStackTrace();
/* 116:119 */     session.close(true);
/* 117:    */   }
/* 118:    */   
/* 119:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.SESSION_CLOSED}, in={"Done"})
/* 120:    */   public void sessionClosed(IoFilter.NextFilter nextFilter, IoSession session)
/* 121:    */   {
/* 122:124 */     nextFilter.sessionClosed(session);
/* 123:    */   }
/* 124:    */   
/* 125:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.EXCEPTION_CAUGHT}, in={"Done"})
/* 126:    */   public void exceptionCaught(IoFilter.NextFilter nextFilter, IoSession session, Throwable cause)
/* 127:    */   {
/* 128:128 */     nextFilter.exceptionCaught(session, cause);
/* 129:    */   }
/* 130:    */   
/* 131:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.MESSAGE_RECEIVED}, in={"Done"})
/* 132:    */   public void messageReceived(IoFilter.NextFilter nextFilter, IoSession session, Object message)
/* 133:    */   {
/* 134:132 */     nextFilter.messageReceived(session, message);
/* 135:    */   }
/* 136:    */   
/* 137:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.MESSAGE_SENT}, in={"Done"})
/* 138:    */   public void messageSent(IoFilter.NextFilter nextFilter, IoSession session, WriteRequest writeRequest)
/* 139:    */   {
/* 140:136 */     nextFilter.messageSent(session, writeRequest);
/* 141:    */   }
/* 142:    */   
/* 143:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.CLOSE}, in={"Root"})
/* 144:    */   public void filterClose(IoFilter.NextFilter nextFilter, IoSession session)
/* 145:    */   {
/* 146:141 */     nextFilter.filterClose(session);
/* 147:    */   }
/* 148:    */   
/* 149:    */   @IoFilterTransition(on={org.apache.mina.statemachine.event.IoFilterEvents.WRITE}, in={"Root"})
/* 150:    */   public void filterWrite(IoFilter.NextFilter nextFilter, IoSession session, WriteRequest writeRequest)
/* 151:    */   {
/* 152:145 */     nextFilter.filterWrite(session, writeRequest);
/* 153:    */   }
/* 154:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tapedeck.AuthenticationHandler
 * JD-Core Version:    0.7.0.1
 */