/*   1:    */ package org.apache.mina.example.tapedeck;
/*   2:    */ 
/*   3:    */ import java.nio.charset.Charset;
/*   4:    */ import java.util.LinkedList;
/*   5:    */ import org.apache.mina.core.buffer.IoBuffer;
/*   6:    */ import org.apache.mina.core.filterchain.IoFilter.NextFilter;
/*   7:    */ import org.apache.mina.core.session.IoSession;
/*   8:    */ import org.apache.mina.filter.codec.ProtocolDecoderOutput;
/*   9:    */ import org.apache.mina.filter.codec.textline.LineDelimiter;
/*  10:    */ import org.apache.mina.filter.codec.textline.TextLineDecoder;
/*  11:    */ 
/*  12:    */ public class CommandDecoder
/*  13:    */   extends TextLineDecoder
/*  14:    */ {
/*  15:    */   public CommandDecoder()
/*  16:    */   {
/*  17: 42 */     super(Charset.forName("UTF8"), LineDelimiter.WINDOWS);
/*  18:    */   }
/*  19:    */   
/*  20:    */   private Object parseCommand(String line)
/*  21:    */     throws CommandSyntaxException
/*  22:    */   {
/*  23: 46 */     String[] temp = line.split(" +", 2);
/*  24: 47 */     String cmd = temp[0].toLowerCase();
/*  25: 48 */     String arg = temp.length > 1 ? temp[1] : null;
/*  26: 50 */     if ("load".equals(cmd))
/*  27:    */     {
/*  28: 51 */       if (arg == null) {
/*  29: 52 */         throw new CommandSyntaxException("No tape number specified");
/*  30:    */       }
/*  31:    */       try
/*  32:    */       {
/*  33: 55 */         return new LoadCommand(Integer.parseInt(arg));
/*  34:    */       }
/*  35:    */       catch (NumberFormatException nfe)
/*  36:    */       {
/*  37: 57 */         throw new CommandSyntaxException("Illegal tape number: " + arg);
/*  38:    */       }
/*  39:    */     }
/*  40: 59 */     if ("play".equals(cmd)) {
/*  41: 60 */       return new PlayCommand();
/*  42:    */     }
/*  43: 61 */     if ("pause".equals(cmd)) {
/*  44: 62 */       return new PauseCommand();
/*  45:    */     }
/*  46: 63 */     if ("stop".equals(cmd)) {
/*  47: 64 */       return new StopCommand();
/*  48:    */     }
/*  49: 65 */     if ("list".equals(cmd)) {
/*  50: 66 */       return new ListCommand();
/*  51:    */     }
/*  52: 67 */     if ("eject".equals(cmd)) {
/*  53: 68 */       return new EjectCommand();
/*  54:    */     }
/*  55: 69 */     if ("quit".equals(cmd)) {
/*  56: 70 */       return new QuitCommand();
/*  57:    */     }
/*  58: 71 */     if ("info".equals(cmd)) {
/*  59: 72 */       return new InfoCommand();
/*  60:    */     }
/*  61: 73 */     if ("user".equals(cmd))
/*  62:    */     {
/*  63: 74 */       if (arg == null) {
/*  64: 75 */         throw new CommandSyntaxException("No username specified");
/*  65:    */       }
/*  66: 77 */       return new UserCommand(arg);
/*  67:    */     }
/*  68: 78 */     if ("password".equals(cmd))
/*  69:    */     {
/*  70: 79 */       if (arg == null) {
/*  71: 80 */         throw new CommandSyntaxException("No password specified");
/*  72:    */       }
/*  73: 82 */       return new PasswordCommand(arg);
/*  74:    */     }
/*  75: 85 */     throw new CommandSyntaxException("Unknown command: " + cmd);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void decode(IoSession session, IoBuffer in, ProtocolDecoderOutput out)
/*  79:    */     throws Exception
/*  80:    */   {
/*  81: 92 */     final LinkedList<String> lines = new LinkedList();
/*  82: 93 */     super.decode(session, in, new ProtocolDecoderOutput()
/*  83:    */     {
/*  84:    */       public void write(Object message)
/*  85:    */       {
/*  86: 95 */         lines.add((String)message);
/*  87:    */       }
/*  88:    */       
/*  89:    */       public void flush(IoFilter.NextFilter nextFilter, IoSession session) {}
/*  90:    */     });
/*  91:100 */     for (String s : lines) {
/*  92:101 */       out.write(parseCommand(s));
/*  93:    */     }
/*  94:    */   }
/*  95:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tapedeck.CommandDecoder
 * JD-Core Version:    0.7.0.1
 */