/*  1:   */ package org.apache.mina.example.tapedeck;
/*  2:   */ 
/*  3:   */ import org.apache.mina.filter.codec.ProtocolDecoderException;
/*  4:   */ 
/*  5:   */ public class CommandSyntaxException
/*  6:   */   extends ProtocolDecoderException
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = 4903547501059093765L;
/*  9:   */   private final String message;
/* 10:   */   
/* 11:   */   public CommandSyntaxException(String message)
/* 12:   */   {
/* 13:36 */     super(message);
/* 14:37 */     this.message = message;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public String getMessage()
/* 18:   */   {
/* 19:42 */     return this.message;
/* 20:   */   }
/* 21:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tapedeck.CommandSyntaxException
 * JD-Core Version:    0.7.0.1
 */