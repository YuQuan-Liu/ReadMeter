/*  1:   */ package org.apache.mina.example.tapedeck;
/*  2:   */ 
/*  3:   */ public class InfoCommand
/*  4:   */   extends Command
/*  5:   */ {
/*  6:   */   public static final String NAME = "info";
/*  7:   */   
/*  8:   */   public String getName()
/*  9:   */   {
/* 10:32 */     return "info";
/* 11:   */   }
/* 12:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tapedeck.InfoCommand
 * JD-Core Version:    0.7.0.1
 */