/*  1:   */ package org.apache.mina.example.tapedeck;
/*  2:   */ 
/*  3:   */ public class LoadCommand
/*  4:   */   extends Command
/*  5:   */ {
/*  6:   */   public static final String NAME = "load";
/*  7:   */   private final int tapeNumber;
/*  8:   */   
/*  9:   */   public LoadCommand(int tapeNumber)
/* 10:   */   {
/* 11:33 */     this.tapeNumber = tapeNumber;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public int getTapeNumber()
/* 15:   */   {
/* 16:37 */     return this.tapeNumber;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getName()
/* 20:   */   {
/* 21:42 */     return "load";
/* 22:   */   }
/* 23:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tapedeck.LoadCommand
 * JD-Core Version:    0.7.0.1
 */