/*  1:   */ package org.apache.mina.example.tapedeck;
/*  2:   */ 
/*  3:   */ import java.net.InetSocketAddress;
/*  4:   */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*  5:   */ import org.apache.mina.core.service.IoHandler;
/*  6:   */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/*  7:   */ import org.apache.mina.filter.codec.textline.TextLineEncoder;
/*  8:   */ import org.apache.mina.filter.logging.LoggingFilter;
/*  9:   */ import org.apache.mina.statemachine.StateMachine;
/* 10:   */ import org.apache.mina.statemachine.StateMachineFactory;
/* 11:   */ import org.apache.mina.statemachine.StateMachineProxyBuilder;
/* 12:   */ import org.apache.mina.statemachine.annotation.IoHandlerTransition;
/* 13:   */ import org.apache.mina.statemachine.context.IoSessionStateContextLookup;
/* 14:   */ import org.apache.mina.statemachine.context.StateContext;
/* 15:   */ import org.apache.mina.statemachine.context.StateContextFactory;
/* 16:   */ import org.apache.mina.transport.socket.SocketAcceptor;
/* 17:   */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
/* 18:   */ 
/* 19:   */ public class Main
/* 20:   */ {
/* 21:   */   private static final int PORT = 12345;
/* 22:   */   
/* 23:   */   private static IoHandler createIoHandler()
/* 24:   */   {
/* 25:51 */     StateMachine sm = StateMachineFactory.getInstance(IoHandlerTransition.class).create("Empty", new TapeDeckServer());
/* 26:   */     
/* 27:   */ 
/* 28:   */ 
/* 29:55 */     (IoHandler)new StateMachineProxyBuilder().setStateContextLookup(new IoSessionStateContextLookup(new StateContextFactory()
/* 30:   */     {
/* 31:   */       public StateContext create()
/* 32:   */       {
/* 33:58 */         return new TapeDeckServer.TapeDeckContext();
/* 34:   */       }
/* 35:58 */     })).create(IoHandler.class, sm);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public static void main(String[] args)
/* 39:   */     throws Exception
/* 40:   */   {
/* 41:64 */     SocketAcceptor acceptor = new NioSocketAcceptor();
/* 42:65 */     acceptor.setReuseAddress(true);
/* 43:66 */     ProtocolCodecFilter pcf = new ProtocolCodecFilter(new TextLineEncoder(), new CommandDecoder());
/* 44:   */     
/* 45:68 */     acceptor.getFilterChain().addLast("log1", new LoggingFilter("log1"));
/* 46:69 */     acceptor.getFilterChain().addLast("codec", pcf);
/* 47:70 */     acceptor.getFilterChain().addLast("log2", new LoggingFilter("log2"));
/* 48:71 */     acceptor.setHandler(createIoHandler());
/* 49:72 */     acceptor.bind(new InetSocketAddress(12345));
/* 50:   */   }
/* 51:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tapedeck.Main
 * JD-Core Version:    0.7.0.1
 */