/*  1:   */ package org.apache.mina.example.tapedeck;
/*  2:   */ 
/*  3:   */ public class PasswordCommand
/*  4:   */   extends Command
/*  5:   */ {
/*  6:   */   public static final String NAME = "password";
/*  7:   */   private final String password;
/*  8:   */   
/*  9:   */   public PasswordCommand(String password)
/* 10:   */   {
/* 11:33 */     this.password = password;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String getPassword()
/* 15:   */   {
/* 16:37 */     return this.password;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public String getName()
/* 20:   */   {
/* 21:42 */     return "password";
/* 22:   */   }
/* 23:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tapedeck.PasswordCommand
 * JD-Core Version:    0.7.0.1
 */