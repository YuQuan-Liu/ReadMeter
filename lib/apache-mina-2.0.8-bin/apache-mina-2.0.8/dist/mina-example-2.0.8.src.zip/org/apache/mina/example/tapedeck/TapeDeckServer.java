/*   1:    */ package org.apache.mina.example.tapedeck;
/*   2:    */ 
/*   3:    */ import org.apache.mina.core.future.IoFutureListener;
/*   4:    */ import org.apache.mina.core.future.WriteFuture;
/*   5:    */ import org.apache.mina.core.session.IoSession;
/*   6:    */ import org.apache.mina.statemachine.StateControl;
/*   7:    */ import org.apache.mina.statemachine.annotation.IoHandlerTransition;
/*   8:    */ import org.apache.mina.statemachine.annotation.IoHandlerTransitions;
/*   9:    */ import org.apache.mina.statemachine.context.AbstractStateContext;
/*  10:    */ import org.apache.mina.statemachine.context.StateContext;
/*  11:    */ import org.apache.mina.statemachine.event.Event;
/*  12:    */ 
/*  13:    */ public class TapeDeckServer
/*  14:    */ {
/*  15:    */   @org.apache.mina.statemachine.annotation.State
/*  16:    */   public static final String ROOT = "Root";
/*  17:    */   @org.apache.mina.statemachine.annotation.State("Root")
/*  18:    */   public static final String EMPTY = "Empty";
/*  19:    */   @org.apache.mina.statemachine.annotation.State("Root")
/*  20:    */   public static final String LOADED = "Loaded";
/*  21:    */   @org.apache.mina.statemachine.annotation.State("Root")
/*  22:    */   public static final String PLAYING = "Playing";
/*  23:    */   @org.apache.mina.statemachine.annotation.State("Root")
/*  24:    */   public static final String PAUSED = "Paused";
/*  25:    */   private final String[] tapes;
/*  26:    */   
/*  27:    */   public TapeDeckServer()
/*  28:    */   {
/*  29: 46 */     this.tapes = new String[] { "The Knife - Silent Shout", "Kings of convenience - Riot on an empty street" };
/*  30:    */   }
/*  31:    */   
/*  32:    */   @IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.SESSION_OPENED}, in={"Empty"})
/*  33:    */   public void connect(IoSession session)
/*  34:    */   {
/*  35: 57 */     session.write("+ Greetings from your tape deck!");
/*  36:    */   }
/*  37:    */   
/*  38:    */   @IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.MESSAGE_RECEIVED}, in={"Empty"}, next="Loaded")
/*  39:    */   public void loadTape(TapeDeckContext context, IoSession session, LoadCommand cmd)
/*  40:    */   {
/*  41: 62 */     if ((cmd.getTapeNumber() < 1) || (cmd.getTapeNumber() > this.tapes.length))
/*  42:    */     {
/*  43: 63 */       session.write("- Unknown tape number: " + cmd.getTapeNumber());
/*  44: 64 */       StateControl.breakAndGotoNext("Empty");
/*  45:    */     }
/*  46:    */     else
/*  47:    */     {
/*  48: 66 */       context.tapeName = this.tapes[(cmd.getTapeNumber() - 1)];
/*  49: 67 */       session.write("+ \"" + context.tapeName + "\" loaded");
/*  50:    */     }
/*  51:    */   }
/*  52:    */   
/*  53:    */   @IoHandlerTransitions({@IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.MESSAGE_RECEIVED}, in={"Loaded"}, next="Playing"), @IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.MESSAGE_RECEIVED}, in={"Paused"}, next="Playing")})
/*  54:    */   public void playTape(TapeDeckContext context, IoSession session, PlayCommand cmd)
/*  55:    */   {
/*  56: 76 */     session.write("+ Playing \"" + context.tapeName + "\"");
/*  57:    */   }
/*  58:    */   
/*  59:    */   @IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.MESSAGE_RECEIVED}, in={"Playing"}, next="Paused")
/*  60:    */   public void pauseTape(TapeDeckContext context, IoSession session, PauseCommand cmd)
/*  61:    */   {
/*  62: 81 */     session.write("+ \"" + context.tapeName + "\" paused");
/*  63:    */   }
/*  64:    */   
/*  65:    */   @IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.MESSAGE_RECEIVED}, in={"Playing"}, next="Loaded")
/*  66:    */   public void stopTape(TapeDeckContext context, IoSession session, StopCommand cmd)
/*  67:    */   {
/*  68: 86 */     session.write("+ \"" + context.tapeName + "\" stopped");
/*  69:    */   }
/*  70:    */   
/*  71:    */   @IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.MESSAGE_RECEIVED}, in={"Loaded"}, next="Empty")
/*  72:    */   public void ejectTape(TapeDeckContext context, IoSession session, EjectCommand cmd)
/*  73:    */   {
/*  74: 91 */     session.write("+ \"" + context.tapeName + "\" ejected");
/*  75: 92 */     context.tapeName = null;
/*  76:    */   }
/*  77:    */   
/*  78:    */   @IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.MESSAGE_RECEIVED}, in={"Root"})
/*  79:    */   public void listTapes(IoSession session, ListCommand cmd)
/*  80:    */   {
/*  81: 97 */     StringBuilder response = new StringBuilder("+ (");
/*  82: 98 */     for (int i = 0; i < this.tapes.length; i++)
/*  83:    */     {
/*  84: 99 */       response.append(i + 1).append(": ");
/*  85:100 */       response.append('"').append(this.tapes[i]).append('"');
/*  86:101 */       if (i < this.tapes.length - 1) {
/*  87:102 */         response.append(", ");
/*  88:    */       }
/*  89:    */     }
/*  90:105 */     response.append(')');
/*  91:106 */     session.write(response);
/*  92:    */   }
/*  93:    */   
/*  94:    */   @IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.MESSAGE_RECEIVED}, in={"Root"})
/*  95:    */   public void info(TapeDeckContext context, IoSession session, InfoCommand cmd)
/*  96:    */   {
/*  97:111 */     String state = context.getCurrentState().getId().toLowerCase();
/*  98:112 */     if (context.tapeName == null) {
/*  99:113 */       session.write("+ Tape deck is " + state + "");
/* 100:    */     } else {
/* 101:115 */       session.write("+ Tape deck is " + state + ". Current tape: \"" + context.tapeName + "\"");
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   @IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.MESSAGE_RECEIVED}, in={"Root"})
/* 106:    */   public void quit(TapeDeckContext context, IoSession session, QuitCommand cmd)
/* 107:    */   {
/* 108:122 */     session.write("+ Bye! Please come back!").addListener(IoFutureListener.CLOSE);
/* 109:    */   }
/* 110:    */   
/* 111:    */   @IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.MESSAGE_RECEIVED}, in={"Root"}, weight=10)
/* 112:    */   public void error(Event event, StateContext context, IoSession session, Command cmd)
/* 113:    */   {
/* 114:127 */     session.write("- Cannot " + cmd.getName() + " while " + context.getCurrentState().getId().toLowerCase());
/* 115:    */   }
/* 116:    */   
/* 117:    */   @IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.EXCEPTION_CAUGHT}, in={"Root"})
/* 118:    */   public void commandSyntaxError(IoSession session, CommandSyntaxException e)
/* 119:    */   {
/* 120:133 */     session.write("- " + e.getMessage());
/* 121:    */   }
/* 122:    */   
/* 123:    */   @IoHandlerTransition(on={org.apache.mina.statemachine.event.IoHandlerEvents.EXCEPTION_CAUGHT}, in={"Root"}, weight=10)
/* 124:    */   public void exceptionCaught(IoSession session, Exception e)
/* 125:    */   {
/* 126:138 */     e.printStackTrace();
/* 127:139 */     session.close(true);
/* 128:    */   }
/* 129:    */   
/* 130:    */   @IoHandlerTransition(in={"Root"}, weight=100)
/* 131:    */   public void unhandledEvent() {}
/* 132:    */   
/* 133:    */   static class TapeDeckContext
/* 134:    */     extends AbstractStateContext
/* 135:    */   {
/* 136:    */     private String tapeName;
/* 137:    */   }
/* 138:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tapedeck.TapeDeckServer
 * JD-Core Version:    0.7.0.1
 */