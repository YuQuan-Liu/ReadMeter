/*   1:    */ package org.apache.mina.example.tcp.perf;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.net.InetSocketAddress;
/*   5:    */ import org.apache.mina.core.buffer.IoBuffer;
/*   6:    */ import org.apache.mina.core.future.ConnectFuture;
/*   7:    */ import org.apache.mina.core.service.IoConnector;
/*   8:    */ import org.apache.mina.core.service.IoHandlerAdapter;
/*   9:    */ import org.apache.mina.core.session.IdleStatus;
/*  10:    */ import org.apache.mina.core.session.IoSession;
/*  11:    */ import org.apache.mina.transport.socket.nio.NioSocketConnector;
/*  12:    */ 
/*  13:    */ public class TcpClient
/*  14:    */   extends IoHandlerAdapter
/*  15:    */ {
/*  16:    */   private IoConnector connector;
/*  17:    */   private static IoSession session;
/*  18: 47 */   private boolean received = false;
/*  19:    */   
/*  20:    */   public TcpClient()
/*  21:    */   {
/*  22: 53 */     this.connector = new NioSocketConnector();
/*  23:    */     
/*  24: 55 */     this.connector.setHandler(this);
/*  25: 56 */     ConnectFuture connFuture = this.connector.connect(new InetSocketAddress("localhost", 18567));
/*  26:    */     
/*  27: 58 */     connFuture.awaitUninterruptibly();
/*  28:    */     
/*  29: 60 */     session = connFuture.getSession();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void exceptionCaught(IoSession session, Throwable cause)
/*  33:    */     throws Exception
/*  34:    */   {
/*  35: 68 */     cause.printStackTrace();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void messageReceived(IoSession session, Object message)
/*  39:    */     throws Exception
/*  40:    */   {
/*  41: 76 */     this.received = true;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void messageSent(IoSession session, Object message)
/*  45:    */     throws Exception
/*  46:    */   {}
/*  47:    */   
/*  48:    */   public void sessionClosed(IoSession session)
/*  49:    */     throws Exception
/*  50:    */   {}
/*  51:    */   
/*  52:    */   public void sessionCreated(IoSession session)
/*  53:    */     throws Exception
/*  54:    */   {}
/*  55:    */   
/*  56:    */   public void sessionIdle(IoSession session, IdleStatus status)
/*  57:    */     throws Exception
/*  58:    */   {}
/*  59:    */   
/*  60:    */   public void sessionOpened(IoSession session)
/*  61:    */     throws Exception
/*  62:    */   {}
/*  63:    */   
/*  64:    */   public static void main(String[] args)
/*  65:    */     throws Exception
/*  66:    */   {
/*  67:121 */     TcpClient client = new TcpClient();
/*  68:    */     
/*  69:123 */     long t0 = System.currentTimeMillis();
/*  70:125 */     for (int i = 0; i <= 100000; i++)
/*  71:    */     {
/*  72:126 */       IoBuffer buffer = IoBuffer.allocate(4);
/*  73:127 */       buffer.putInt(i);
/*  74:128 */       buffer.flip();
/*  75:129 */       session.write(buffer);
/*  76:131 */       while (!client.received) {
/*  77:132 */         Thread.sleep(1L);
/*  78:    */       }
/*  79:135 */       client.received = false;
/*  80:137 */       if (i % 10000 == 0) {
/*  81:138 */         System.out.println("Sent " + i + " messages");
/*  82:    */       }
/*  83:    */     }
/*  84:142 */     long t1 = System.currentTimeMillis();
/*  85:    */     
/*  86:144 */     System.out.println("Sent messages delay : " + (t1 - t0));
/*  87:    */     
/*  88:146 */     Thread.sleep(100000L);
/*  89:    */     
/*  90:148 */     client.connector.dispose(true);
/*  91:    */   }
/*  92:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tcp.perf.TcpClient
 * JD-Core Version:    0.7.0.1
 */