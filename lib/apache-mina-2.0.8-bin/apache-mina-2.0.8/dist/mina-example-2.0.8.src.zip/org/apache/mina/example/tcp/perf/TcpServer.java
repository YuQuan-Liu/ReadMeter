/*   1:    */ package org.apache.mina.example.tcp.perf;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.PrintStream;
/*   5:    */ import java.net.InetSocketAddress;
/*   6:    */ import java.util.concurrent.atomic.AtomicInteger;
/*   7:    */ import org.apache.mina.core.service.IoHandlerAdapter;
/*   8:    */ import org.apache.mina.core.session.IdleStatus;
/*   9:    */ import org.apache.mina.core.session.IoSession;
/*  10:    */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
/*  11:    */ 
/*  12:    */ public class TcpServer
/*  13:    */   extends IoHandlerAdapter
/*  14:    */ {
/*  15:    */   public static final int PORT = 18567;
/*  16:    */   public static final int MAX_RECEIVED = 100000;
/*  17:    */   private static long t0;
/*  18: 51 */   private AtomicInteger nbReceived = new AtomicInteger(0);
/*  19:    */   
/*  20:    */   public void exceptionCaught(IoSession session, Throwable cause)
/*  21:    */     throws Exception
/*  22:    */   {
/*  23: 58 */     cause.printStackTrace();
/*  24: 59 */     session.close(true);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void messageReceived(IoSession session, Object message)
/*  28:    */     throws Exception
/*  29:    */   {
/*  30: 68 */     int nb = this.nbReceived.incrementAndGet();
/*  31: 70 */     if (nb == 1) {
/*  32: 71 */       t0 = System.currentTimeMillis();
/*  33:    */     }
/*  34: 74 */     if (nb == 100000)
/*  35:    */     {
/*  36: 75 */       long t1 = System.currentTimeMillis();
/*  37: 76 */       System.out.println("-------------> end " + (t1 - t0));
/*  38:    */     }
/*  39: 79 */     if (nb % 10000 == 0) {
/*  40: 80 */       System.out.println("Received " + nb + " messages");
/*  41:    */     }
/*  42: 84 */     session.write(message);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void sessionClosed(IoSession session)
/*  46:    */     throws Exception
/*  47:    */   {
/*  48: 92 */     System.out.println("Session closed...");
/*  49:    */     
/*  50:    */ 
/*  51: 95 */     System.out.println("Nb message received : " + this.nbReceived.get());
/*  52: 96 */     this.nbReceived.set(0);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void sessionCreated(IoSession session)
/*  56:    */     throws Exception
/*  57:    */   {
/*  58:104 */     System.out.println("Session created...");
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void sessionIdle(IoSession session, IdleStatus status)
/*  62:    */     throws Exception
/*  63:    */   {
/*  64:112 */     System.out.println("Session idle...");
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void sessionOpened(IoSession session)
/*  68:    */     throws Exception
/*  69:    */   {
/*  70:120 */     System.out.println("Session Opened...");
/*  71:    */   }
/*  72:    */   
/*  73:    */   public TcpServer()
/*  74:    */     throws IOException
/*  75:    */   {
/*  76:127 */     NioSocketAcceptor acceptor = new NioSocketAcceptor();
/*  77:128 */     acceptor.setHandler(this);
/*  78:    */     
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:134 */     acceptor.bind(new InetSocketAddress(18567));
/*  84:    */     
/*  85:136 */     System.out.println("Server started...");
/*  86:    */   }
/*  87:    */   
/*  88:    */   public static void main(String[] args)
/*  89:    */     throws IOException
/*  90:    */   {
/*  91:143 */     new TcpServer();
/*  92:    */   }
/*  93:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tcp.perf.TcpServer
 * JD-Core Version:    0.7.0.1
 */