/*  1:   */ package org.apache.mina.example.tennis;
/*  2:   */ 
/*  3:   */ import org.apache.mina.core.future.CloseFuture;
/*  4:   */ import org.apache.mina.core.future.ConnectFuture;
/*  5:   */ import org.apache.mina.core.service.IoAcceptor;
/*  6:   */ import org.apache.mina.core.session.IoSession;
/*  7:   */ import org.apache.mina.transport.vmpipe.VmPipeAcceptor;
/*  8:   */ import org.apache.mina.transport.vmpipe.VmPipeAddress;
/*  9:   */ import org.apache.mina.transport.vmpipe.VmPipeConnector;
/* 10:   */ 
/* 11:   */ public class Main
/* 12:   */ {
/* 13:   */   public static void main(String[] args)
/* 14:   */     throws Exception
/* 15:   */   {
/* 16:45 */     IoAcceptor acceptor = new VmPipeAcceptor();
/* 17:46 */     VmPipeAddress address = new VmPipeAddress(8080);
/* 18:   */     
/* 19:   */ 
/* 20:49 */     acceptor.setHandler(new TennisPlayer());
/* 21:50 */     acceptor.bind(address);
/* 22:   */     
/* 23:   */ 
/* 24:53 */     VmPipeConnector connector = new VmPipeConnector();
/* 25:54 */     connector.setHandler(new TennisPlayer());
/* 26:55 */     ConnectFuture future = connector.connect(address);
/* 27:56 */     future.awaitUninterruptibly();
/* 28:57 */     IoSession session = future.getSession();
/* 29:   */     
/* 30:   */ 
/* 31:60 */     session.write(new TennisBall(10));
/* 32:   */     
/* 33:   */ 
/* 34:63 */     session.getCloseFuture().awaitUninterruptibly();
/* 35:   */     
/* 36:65 */     acceptor.unbind();
/* 37:   */   }
/* 38:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tennis.Main
 * JD-Core Version:    0.7.0.1
 */