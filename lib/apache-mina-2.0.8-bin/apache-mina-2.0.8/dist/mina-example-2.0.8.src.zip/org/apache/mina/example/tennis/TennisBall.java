/*  1:   */ package org.apache.mina.example.tennis;
/*  2:   */ 
/*  3:   */ public class TennisBall
/*  4:   */ {
/*  5:   */   private final boolean ping;
/*  6:   */   private final int ttl;
/*  7:   */   
/*  8:   */   public TennisBall(int ttl)
/*  9:   */   {
/* 10:37 */     this(ttl, true);
/* 11:   */   }
/* 12:   */   
/* 13:   */   private TennisBall(int ttl, boolean ping)
/* 14:   */   {
/* 15:44 */     this.ttl = ttl;
/* 16:45 */     this.ping = ping;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getTTL()
/* 20:   */   {
/* 21:52 */     return this.ttl;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public TennisBall stroke()
/* 25:   */   {
/* 26:60 */     return new TennisBall(this.ttl - 1, !this.ping);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String toString()
/* 30:   */   {
/* 31:69 */     if (this.ping) {
/* 32:70 */       return "PING (" + this.ttl + ")";
/* 33:   */     }
/* 34:72 */     return "PONG (" + this.ttl + ")";
/* 35:   */   }
/* 36:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tennis.TennisBall
 * JD-Core Version:    0.7.0.1
 */