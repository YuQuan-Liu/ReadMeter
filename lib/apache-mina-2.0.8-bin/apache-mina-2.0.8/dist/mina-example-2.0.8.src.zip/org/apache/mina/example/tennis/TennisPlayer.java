/*  1:   */ package org.apache.mina.example.tennis;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import org.apache.mina.core.service.IoHandlerAdapter;
/*  5:   */ import org.apache.mina.core.session.IoSession;
/*  6:   */ 
/*  7:   */ public class TennisPlayer
/*  8:   */   extends IoHandlerAdapter
/*  9:   */ {
/* 10:32 */   private static int nextId = 0;
/* 11:35 */   private final int id = nextId++;
/* 12:   */   
/* 13:   */   public void sessionOpened(IoSession session)
/* 14:   */   {
/* 15:39 */     System.out.println("Player-" + this.id + ": READY");
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void sessionClosed(IoSession session)
/* 19:   */   {
/* 20:44 */     System.out.println("Player-" + this.id + ": QUIT");
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void messageReceived(IoSession session, Object message)
/* 24:   */   {
/* 25:49 */     System.out.println("Player-" + this.id + ": RCVD " + message);
/* 26:   */     
/* 27:51 */     TennisBall ball = (TennisBall)message;
/* 28:   */     
/* 29:   */ 
/* 30:54 */     ball = ball.stroke();
/* 31:56 */     if (ball.getTTL() > 0)
/* 32:   */     {
/* 33:58 */       session.write(ball);
/* 34:   */     }
/* 35:   */     else
/* 36:   */     {
/* 37:61 */       System.out.println("Player-" + this.id + ": LOSE");
/* 38:62 */       session.close(true);
/* 39:   */     }
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void messageSent(IoSession session, Object message)
/* 43:   */   {
/* 44:68 */     System.out.println("Player-" + this.id + ": SENT " + message);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void exceptionCaught(IoSession session, Throwable cause)
/* 48:   */   {
/* 49:73 */     cause.printStackTrace();
/* 50:74 */     session.close(true);
/* 51:   */   }
/* 52:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.tennis.TennisPlayer
 * JD-Core Version:    0.7.0.1
 */