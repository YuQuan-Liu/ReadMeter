/*  1:   */ package org.apache.mina.example.udp;
/*  2:   */ 
/*  3:   */ import java.awt.GridBagConstraints;
/*  4:   */ import java.awt.GridBagLayout;
/*  5:   */ import java.awt.Insets;
/*  6:   */ import java.io.PrintStream;
/*  7:   */ import javax.swing.JLabel;
/*  8:   */ import javax.swing.JPanel;
/*  9:   */ import javax.swing.JTextField;
/* 10:   */ import javax.swing.SwingUtilities;
/* 11:   */ 
/* 12:   */ public class ClientPanel
/* 13:   */   extends JPanel
/* 14:   */ {
/* 15:   */   private static final long serialVersionUID = 1L;
/* 16:   */   private JTextField textField;
/* 17:   */   
/* 18:   */   public ClientPanel(String label)
/* 19:   */   {
/* 20:45 */     setPreferredSize(MemoryMonitor.PANEL_SIZE);
/* 21:   */     
/* 22:47 */     setLayout(new GridBagLayout());
/* 23:48 */     GridBagConstraints c = new GridBagConstraints();
/* 24:   */     
/* 25:50 */     c.insets = new Insets(5, 5, 5, 5);
/* 26:51 */     c.anchor = 10;
/* 27:   */     
/* 28:53 */     c.gridwidth = 0;
/* 29:54 */     add(new JLabel(label), c);
/* 30:   */     
/* 31:56 */     c.gridwidth = 1;
/* 32:57 */     add(new JLabel("Memory Used : "));
/* 33:58 */     this.textField = new JTextField(10);
/* 34:59 */     this.textField.setEditable(false);
/* 35:60 */     add(this.textField, c);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void updateTextField(final long val)
/* 39:   */   {
/* 40:64 */     System.out.println("New value for textfield - " + val);
/* 41:65 */     SwingUtilities.invokeLater(new Runnable()
/* 42:   */     {
/* 43:   */       public void run()
/* 44:   */       {
/* 45:67 */         ClientPanel.this.textField.setText(String.valueOf(val));
/* 46:   */       }
/* 47:   */     });
/* 48:   */   }
/* 49:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.udp.ClientPanel
 * JD-Core Version:    0.7.0.1
 */