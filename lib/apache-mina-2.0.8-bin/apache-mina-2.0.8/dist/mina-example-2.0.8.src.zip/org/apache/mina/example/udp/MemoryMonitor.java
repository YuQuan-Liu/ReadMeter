/*   1:    */ package org.apache.mina.example.udp;
/*   2:    */ 
/*   3:    */ import java.awt.Dimension;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.PrintStream;
/*   6:    */ import java.net.InetSocketAddress;
/*   7:    */ import java.net.SocketAddress;
/*   8:    */ import java.util.concurrent.ConcurrentHashMap;
/*   9:    */ import javax.swing.JFrame;
/*  10:    */ import javax.swing.JLabel;
/*  11:    */ import javax.swing.JPanel;
/*  12:    */ import javax.swing.JTabbedPane;
/*  13:    */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*  14:    */ import org.apache.mina.filter.logging.LoggingFilter;
/*  15:    */ import org.apache.mina.transport.socket.DatagramSessionConfig;
/*  16:    */ import org.apache.mina.transport.socket.nio.NioDatagramAcceptor;
/*  17:    */ 
/*  18:    */ public class MemoryMonitor
/*  19:    */ {
/*  20:    */   private static final long serialVersionUID = 1L;
/*  21:    */   public static final int PORT = 18567;
/*  22: 51 */   protected static final Dimension PANEL_SIZE = new Dimension(300, 200);
/*  23:    */   private JFrame frame;
/*  24:    */   private JTabbedPane tabbedPane;
/*  25:    */   private ConcurrentHashMap<SocketAddress, ClientPanel> clients;
/*  26:    */   
/*  27:    */   public MemoryMonitor()
/*  28:    */     throws IOException
/*  29:    */   {
/*  30: 61 */     NioDatagramAcceptor acceptor = new NioDatagramAcceptor();
/*  31: 62 */     acceptor.setHandler(new MemoryMonitorHandler(this));
/*  32:    */     
/*  33: 64 */     DefaultIoFilterChainBuilder chain = acceptor.getFilterChain();
/*  34: 65 */     chain.addLast("logger", new LoggingFilter());
/*  35:    */     
/*  36: 67 */     DatagramSessionConfig dcfg = acceptor.getSessionConfig();
/*  37: 68 */     dcfg.setReuseAddress(true);
/*  38:    */     
/*  39: 70 */     this.frame = new JFrame("Memory monitor");
/*  40: 71 */     this.tabbedPane = new JTabbedPane();
/*  41: 72 */     this.tabbedPane.add("Welcome", createWelcomePanel());
/*  42: 73 */     this.frame.add(this.tabbedPane, "Center");
/*  43: 74 */     this.clients = new ConcurrentHashMap();
/*  44: 75 */     this.frame.pack();
/*  45: 76 */     this.frame.setLocation(300, 300);
/*  46: 77 */     this.frame.setVisible(true);
/*  47:    */     
/*  48: 79 */     acceptor.bind(new InetSocketAddress(18567));
/*  49: 80 */     System.out.println("UDPServer listening on port 18567");
/*  50:    */   }
/*  51:    */   
/*  52:    */   private JPanel createWelcomePanel()
/*  53:    */   {
/*  54: 84 */     JPanel panel = new JPanel();
/*  55: 85 */     panel.setPreferredSize(PANEL_SIZE);
/*  56: 86 */     panel.add(new JLabel("Welcome to the Memory Monitor"));
/*  57: 87 */     return panel;
/*  58:    */   }
/*  59:    */   
/*  60:    */   protected void recvUpdate(SocketAddress clientAddr, long update)
/*  61:    */   {
/*  62: 91 */     ClientPanel clientPanel = (ClientPanel)this.clients.get(clientAddr);
/*  63: 92 */     if (clientPanel != null) {
/*  64: 93 */       clientPanel.updateTextField(update);
/*  65:    */     } else {
/*  66: 95 */       System.err.println("Received update from unknown client");
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   protected void addClient(SocketAddress clientAddr)
/*  71:    */   {
/*  72:100 */     if (!containsClient(clientAddr))
/*  73:    */     {
/*  74:101 */       ClientPanel clientPanel = new ClientPanel(clientAddr.toString());
/*  75:102 */       this.tabbedPane.add(clientAddr.toString(), clientPanel);
/*  76:103 */       this.clients.put(clientAddr, clientPanel);
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   protected boolean containsClient(SocketAddress clientAddr)
/*  81:    */   {
/*  82:108 */     return this.clients.contains(clientAddr);
/*  83:    */   }
/*  84:    */   
/*  85:    */   protected void removeClient(SocketAddress clientAddr)
/*  86:    */   {
/*  87:112 */     this.clients.remove(clientAddr);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static void main(String[] args)
/*  91:    */     throws IOException
/*  92:    */   {
/*  93:116 */     new MemoryMonitor();
/*  94:    */   }
/*  95:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.udp.MemoryMonitor
 * JD-Core Version:    0.7.0.1
 */