/*  1:   */ package org.apache.mina.example.udp;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import java.net.SocketAddress;
/*  5:   */ import org.apache.mina.core.buffer.IoBuffer;
/*  6:   */ import org.apache.mina.core.service.IoHandlerAdapter;
/*  7:   */ import org.apache.mina.core.session.IdleStatus;
/*  8:   */ import org.apache.mina.core.session.IoSession;
/*  9:   */ 
/* 10:   */ public class MemoryMonitorHandler
/* 11:   */   extends IoHandlerAdapter
/* 12:   */ {
/* 13:   */   private MemoryMonitor server;
/* 14:   */   
/* 15:   */   public MemoryMonitorHandler(MemoryMonitor server)
/* 16:   */   {
/* 17:40 */     this.server = server;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void exceptionCaught(IoSession session, Throwable cause)
/* 21:   */     throws Exception
/* 22:   */   {
/* 23:46 */     cause.printStackTrace();
/* 24:47 */     session.close(true);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void messageReceived(IoSession session, Object message)
/* 28:   */     throws Exception
/* 29:   */   {
/* 30:54 */     if ((message instanceof IoBuffer))
/* 31:   */     {
/* 32:55 */       IoBuffer buffer = (IoBuffer)message;
/* 33:56 */       SocketAddress remoteAddress = session.getRemoteAddress();
/* 34:57 */       this.server.recvUpdate(remoteAddress, buffer.getLong());
/* 35:   */     }
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void sessionClosed(IoSession session)
/* 39:   */     throws Exception
/* 40:   */   {
/* 41:63 */     System.out.println("Session closed...");
/* 42:64 */     SocketAddress remoteAddress = session.getRemoteAddress();
/* 43:65 */     this.server.removeClient(remoteAddress);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void sessionCreated(IoSession session)
/* 47:   */     throws Exception
/* 48:   */   {
/* 49:71 */     System.out.println("Session created...");
/* 50:   */     
/* 51:73 */     SocketAddress remoteAddress = session.getRemoteAddress();
/* 52:74 */     this.server.addClient(remoteAddress);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void sessionIdle(IoSession session, IdleStatus status)
/* 56:   */     throws Exception
/* 57:   */   {
/* 58:80 */     System.out.println("Session idle...");
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void sessionOpened(IoSession session)
/* 62:   */     throws Exception
/* 63:   */   {
/* 64:85 */     System.out.println("Session Opened...");
/* 65:   */   }
/* 66:   */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.udp.MemoryMonitorHandler
 * JD-Core Version:    0.7.0.1
 */