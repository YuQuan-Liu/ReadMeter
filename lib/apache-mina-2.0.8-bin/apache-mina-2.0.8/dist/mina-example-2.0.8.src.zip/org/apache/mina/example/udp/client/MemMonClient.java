/*   1:    */ package org.apache.mina.example.udp.client;
/*   2:    */ 
/*   3:    */ import java.net.InetSocketAddress;
/*   4:    */ import org.apache.mina.core.buffer.IoBuffer;
/*   5:    */ import org.apache.mina.core.future.ConnectFuture;
/*   6:    */ import org.apache.mina.core.future.IoFutureListener;
/*   7:    */ import org.apache.mina.core.service.IoConnector;
/*   8:    */ import org.apache.mina.core.service.IoHandlerAdapter;
/*   9:    */ import org.apache.mina.core.session.IdleStatus;
/*  10:    */ import org.apache.mina.core.session.IoSession;
/*  11:    */ import org.apache.mina.transport.socket.nio.NioDatagramConnector;
/*  12:    */ import org.slf4j.Logger;
/*  13:    */ import org.slf4j.LoggerFactory;
/*  14:    */ 
/*  15:    */ public class MemMonClient
/*  16:    */   extends IoHandlerAdapter
/*  17:    */ {
/*  18: 43 */   private static final Logger LOGGER = LoggerFactory.getLogger(MemMonClient.class);
/*  19:    */   private IoSession session;
/*  20:    */   private IoConnector connector;
/*  21:    */   
/*  22:    */   public MemMonClient()
/*  23:    */   {
/*  24: 54 */     LOGGER.debug("UDPClient::UDPClient");
/*  25: 55 */     LOGGER.debug("Created a datagram connector");
/*  26: 56 */     this.connector = new NioDatagramConnector();
/*  27:    */     
/*  28: 58 */     LOGGER.debug("Setting the handler");
/*  29: 59 */     this.connector.setHandler(this);
/*  30:    */     
/*  31: 61 */     LOGGER.debug("About to connect to the server...");
/*  32: 62 */     ConnectFuture connFuture = this.connector.connect(new InetSocketAddress("localhost", 18567));
/*  33:    */     
/*  34:    */ 
/*  35: 65 */     LOGGER.debug("About to wait.");
/*  36: 66 */     connFuture.awaitUninterruptibly();
/*  37:    */     
/*  38: 68 */     LOGGER.debug("Adding a future listener.");
/*  39: 69 */     connFuture.addListener(new IoFutureListener()
/*  40:    */     {
/*  41:    */       public void operationComplete(ConnectFuture future)
/*  42:    */       {
/*  43: 71 */         if (future.isConnected())
/*  44:    */         {
/*  45: 72 */           MemMonClient.LOGGER.debug("...connected");
/*  46: 73 */           MemMonClient.this.session = future.getSession();
/*  47:    */           try
/*  48:    */           {
/*  49: 75 */             MemMonClient.this.sendData();
/*  50:    */           }
/*  51:    */           catch (InterruptedException e)
/*  52:    */           {
/*  53: 77 */             e.printStackTrace();
/*  54:    */           }
/*  55:    */         }
/*  56:    */         else
/*  57:    */         {
/*  58: 80 */           MemMonClient.LOGGER.error("Not connected...exiting");
/*  59:    */         }
/*  60:    */       }
/*  61:    */     });
/*  62:    */   }
/*  63:    */   
/*  64:    */   private void sendData()
/*  65:    */     throws InterruptedException
/*  66:    */   {
/*  67: 87 */     for (int i = 0; i < 30; i++)
/*  68:    */     {
/*  69: 88 */       long free = Runtime.getRuntime().freeMemory();
/*  70: 89 */       IoBuffer buffer = IoBuffer.allocate(8);
/*  71: 90 */       buffer.putLong(free);
/*  72: 91 */       buffer.flip();
/*  73: 92 */       this.session.write(buffer);
/*  74:    */       try
/*  75:    */       {
/*  76: 95 */         Thread.sleep(1000L);
/*  77:    */       }
/*  78:    */       catch (InterruptedException e)
/*  79:    */       {
/*  80: 97 */         e.printStackTrace();
/*  81: 98 */         throw new InterruptedException(e.getMessage());
/*  82:    */       }
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void exceptionCaught(IoSession session, Throwable cause)
/*  87:    */     throws Exception
/*  88:    */   {
/*  89:106 */     cause.printStackTrace();
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void messageReceived(IoSession session, Object message)
/*  93:    */     throws Exception
/*  94:    */   {
/*  95:112 */     LOGGER.debug("Session recv...");
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void messageSent(IoSession session, Object message)
/*  99:    */     throws Exception
/* 100:    */   {
/* 101:117 */     LOGGER.debug("Message sent...");
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void sessionClosed(IoSession session)
/* 105:    */     throws Exception
/* 106:    */   {
/* 107:122 */     LOGGER.debug("Session closed...");
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void sessionCreated(IoSession session)
/* 111:    */     throws Exception
/* 112:    */   {
/* 113:127 */     LOGGER.debug("Session created...");
/* 114:    */   }
/* 115:    */   
/* 116:    */   public void sessionIdle(IoSession session, IdleStatus status)
/* 117:    */     throws Exception
/* 118:    */   {
/* 119:133 */     LOGGER.debug("Session idle...");
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void sessionOpened(IoSession session)
/* 123:    */     throws Exception
/* 124:    */   {
/* 125:138 */     LOGGER.debug("Session opened...");
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static void main(String[] args)
/* 129:    */   {
/* 130:142 */     new MemMonClient();
/* 131:    */   }
/* 132:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.udp.client.MemMonClient
 * JD-Core Version:    0.7.0.1
 */