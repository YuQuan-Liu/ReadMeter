/*   1:    */ package org.apache.mina.example.udp.perf;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.net.InetSocketAddress;
/*   5:    */ import org.apache.mina.core.buffer.IoBuffer;
/*   6:    */ import org.apache.mina.core.future.ConnectFuture;
/*   7:    */ import org.apache.mina.core.service.IoConnector;
/*   8:    */ import org.apache.mina.core.service.IoHandlerAdapter;
/*   9:    */ import org.apache.mina.core.session.IdleStatus;
/*  10:    */ import org.apache.mina.core.session.IoSession;
/*  11:    */ import org.apache.mina.transport.socket.nio.NioDatagramConnector;
/*  12:    */ 
/*  13:    */ public class UdpClient
/*  14:    */   extends IoHandlerAdapter
/*  15:    */ {
/*  16:    */   private IoConnector connector;
/*  17:    */   private static IoSession session;
/*  18:    */   
/*  19:    */   public UdpClient()
/*  20:    */   {
/*  21: 52 */     this.connector = new NioDatagramConnector();
/*  22:    */     
/*  23: 54 */     this.connector.setHandler(this);
/*  24:    */     
/*  25: 56 */     ConnectFuture connFuture = this.connector.connect(new InetSocketAddress("localhost", 18567));
/*  26:    */     
/*  27: 58 */     connFuture.awaitUninterruptibly();
/*  28:    */     
/*  29: 60 */     session = connFuture.getSession();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void exceptionCaught(IoSession session, Throwable cause)
/*  33:    */     throws Exception
/*  34:    */   {
/*  35: 68 */     cause.printStackTrace();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void messageReceived(IoSession session, Object message)
/*  39:    */     throws Exception
/*  40:    */   {}
/*  41:    */   
/*  42:    */   public void messageSent(IoSession session, Object message)
/*  43:    */     throws Exception
/*  44:    */   {}
/*  45:    */   
/*  46:    */   public void sessionClosed(IoSession session)
/*  47:    */     throws Exception
/*  48:    */   {}
/*  49:    */   
/*  50:    */   public void sessionCreated(IoSession session)
/*  51:    */     throws Exception
/*  52:    */   {}
/*  53:    */   
/*  54:    */   public void sessionIdle(IoSession session, IdleStatus status)
/*  55:    */     throws Exception
/*  56:    */   {}
/*  57:    */   
/*  58:    */   public void sessionOpened(IoSession session)
/*  59:    */     throws Exception
/*  60:    */   {}
/*  61:    */   
/*  62:    */   public static void main(String[] args)
/*  63:    */     throws Exception
/*  64:    */   {
/*  65:120 */     UdpClient client = new UdpClient();
/*  66:    */     
/*  67:122 */     long t0 = System.currentTimeMillis();
/*  68:124 */     for (int i = 0; i <= 100000; i++)
/*  69:    */     {
/*  70:125 */       Thread.sleep(1L);
/*  71:    */       
/*  72:127 */       String str = Integer.toString(i);
/*  73:128 */       byte[] data = str.getBytes();
/*  74:129 */       IoBuffer buffer = IoBuffer.allocate(data.length);
/*  75:130 */       buffer.put(data);
/*  76:131 */       buffer.flip();
/*  77:132 */       session.write(buffer);
/*  78:134 */       if (i % 10000 == 0) {
/*  79:135 */         System.out.println("Sent " + i + " messages");
/*  80:    */       }
/*  81:    */     }
/*  82:139 */     long t1 = System.currentTimeMillis();
/*  83:    */     
/*  84:141 */     System.out.println("Sent messages delay : " + (t1 - t0));
/*  85:    */     
/*  86:143 */     Thread.sleep(100000L);
/*  87:    */     
/*  88:145 */     client.connector.dispose(true);
/*  89:    */   }
/*  90:    */ }


/* Location:           D:\Java_Workspace\HDListener\apache-mina-2.0.8-bin\apache-mina-2.0.8\dist\mina-example-2.0.8.jar
 * Qualified Name:     org.apache.mina.example.udp.perf.UdpClient
 * JD-Core Version:    0.7.0.1
 */